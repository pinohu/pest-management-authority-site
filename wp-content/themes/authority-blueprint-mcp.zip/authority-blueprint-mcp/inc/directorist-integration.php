<?php
// Enqueue Directorist integration styles
add_action('wp_enqueue_scripts', function() {
    if (function_exists('directorist_setup')) {
        wp_enqueue_style('ab-mcp-directorist-integration', get_template_directory_uri() . '/css/directorist-integration.css', ['ab-mcp-style'], AB_MCP_VERSION);
    }
});

// Directorist customization for pest management science
define('AB_MCP_DIRECTORY_TYPES', [
    'pest_control_services' => [
        'name' => 'Pest Control Services',
        'slug' => 'pest-control-services',
        'icon' => 'fas fa-bug',
        'description' => 'Professional pest control service providers'
    ],
    'research_institutions' => [
        'name' => 'Research Institutions',
        'slug' => 'research-institutions',
        'icon' => 'fas fa-microscope',
        'description' => 'Pest management research facilities'
    ],
    'product_suppliers' => [
        'name' => 'Product Suppliers',
        'slug' => 'product-suppliers',
        'icon' => 'fas fa-industry',
        'description' => 'Pest management product suppliers'
    ],
]);

add_action('init', function() {
    if (function_exists('directorist_setup')) {
        add_filter('directorist_listing_types', function($types) {
            return array_merge($types, AB_MCP_DIRECTORY_TYPES);
        });
        add_filter('directorist_custom_fields', function($fields) {
            $fields['pest_specialization'] = [
                'type' => 'select',
                'label' => 'Pest Specialization',
                'options' => [
                    'agricultural' => 'Agricultural Pests',
                    'urban' => 'Urban Pest Control',
                    'stored_product' => 'Stored Product Pests',
                    'structural' => 'Structural Pests',
                    'public_health' => 'Public Health Pests'
                ]
            ];
            $fields['control_methods'] = [
                'type' => 'checkbox',
                'label' => 'Control Methods',
                'options' => [
                    'biological' => 'Biological Control',
                    'chemical' => 'Chemical Control',
                    'mechanical' => 'Mechanical Control',
                    'cultural' => 'Cultural Control',
                    'integrated' => 'Integrated Pest Management'
                ]
            ];
            $fields['certifications'] = [
                'type' => 'text',
                'label' => 'Certifications',
                'placeholder' => 'e.g., Licensed Pest Control Operator, IPM Certified'
            ];
            return $fields;
        });
    }
}); 