<?php
defined('ABSPATH') || die('Direct access is not allowed.');
/**
 * @since 1.1.6
 * @package Directorist
 */
if (!class_exists('PYN_Settings')) :

    class PYN_Settings
    {
        public function __construct()
        {
             // add settings
             
        }


    }
endif;
