<?php
/**
 * @since 1.1.6
 * @package Directorist
 */
defined('ABSPATH') || die('Direct access is not allowed.');