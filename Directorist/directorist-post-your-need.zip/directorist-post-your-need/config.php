<?php
// Plugin version.
if ( ! defined( 'PYN_VERSION' ) ) {define( 'PYN_VERSION', pyn_get_version_from_file_content( PYN_FILE ) );}
// Plugin Folder Path.
if ( ! defined( 'PYN_DIR' ) ) { define( 'PYN_DIR', plugin_dir_path( PYN_FILE ) ); }
// Plugin Folder URL.
if ( ! defined( 'PYN_URL' ) ) { define( 'PYN_URL', plugin_dir_url( PYN_FILE ) ); }
// Plugin Root File.
if ( ! defined( 'PYN_BASE' ) ) { define( 'PYN_BASE', plugin_basename( PYN_FILE ) ); }
// Plugin Includes Path
if ( !defined('PYN_INC_DIR') ) { define('PYN_INC_DIR', PYN_DIR.'inc/'); }
// Plugin Assets Path
if ( !defined('PYN_ASSETS') ) { define('PYN_ASSETS', PYN_URL.'assets/'); }
if ( !defined('PYN_PUBLIC_ASSETS') ) { define('PYN_PUBLIC_ASSETS', PYN_URL.'assets/public'); }
// Plugin Language File Path
if ( !defined('PYN_LANG_DIR') ) { define('PYN_LANG_DIR', dirname(plugin_basename( PYN_FILE ) ) . '/languages'); }
