<?php
/**
 * @author  wpWax
 * @since   1.5.0
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ){
	exit;
}

extract( $field_data );
$value = isset( $_REQUEST['guest'] ) ? $_REQUEST['guest'] : '';
?>

<div class="directorist-search-field directorist-form-group directorist-guest-number">

	<?php if ( ! empty( $label ) ) {
		printf( '<label class="directorist-search-field__label">%s</label>', esc_html( $label ) );
	} ?>

	<input class="directorist-form-element directorist-search-field__input" min="0" type="number" name="custom_field[guest]" value="<?php echo esc_html( $value ); ?>" placeholder="<?php echo esc_html( $placeholder ); ?>" step="1" <?php required( $required ); ?> />

	<div class="directorist-search-field__btn directorist-search-field__btn--clear">
		<?php directorist_icon( 'fas fa-times-circle' ); ?>
	</div>

</div>