<?php if ( isset( $form_fields ) && is_array( $form_fields ) ):?>

    <?php foreach ( $form_fields as $id => $field ): ?>

        <div data-repeater-item class="directorist-apply-form-item dirjob_apply_form_field_wrapper" draggable="true" id="FormField-<?php echo $id; ?>">
            <div class="directorist-apply-form-input">
                <div class="directorist-form-group directorist-form-label-field">
                    <input type="number" name="dirjob_apply_form[<?php echo $id; ?>][refund-days]" class="directorist-form-element refund-days" value="<?php echo $field['refund-days'] ?>" placeholder="Days">
                </div>
                <div class="directorist-form-group directorist-form-placeholder-field">
                    <input type="number" name="dirjob_apply_form[<?php echo $id; ?>][refund-amount]" class="directorist-form-element refund-amount" value="<?php echo $field['refund-amount'] ?>" placeholder="Amount">
                </div>
            </div>
            <div class="directorist-apply-form-action">
                <button data-repeater-delete data-id="<?php echo $id; ?>" type="button" value="Delete" class="directorist-apply-form-delete directorist-form-element dashicons dashicons-trash removeFormFieldField"></button>
            </div>
        </div>

    <?php endforeach;?>

<?php else: ?>

    <div data-repeater-item class="directorist-apply-form-item directorist-apply-form-draggable dirjob_apply_form_field_wrapper" draggable="true" id="FormField-<?php echo $id; ?>">
        <div class="directorist-apply-form-input">
            <div class="directorist-form-group directorist-form-label-field">
                <input type="number" name="dirjob_apply_form[<?php echo $id; ?>][refund-days]" class="directorist-form-element" value="" placeholder="Days">
            </div>
            <div class="directorist-form-group directorist-form-placeholder-field">
                <input type="number" name="dirjob_apply_form[<?php echo $id; ?>][refund-amount]" class="directorist-form-element" value="" placeholder="Amount">
            </div>
        </div>
        <div class="directorist-apply-form-action">
            <button data-repeater-delete data-id="<?php echo $id; ?>" type="button" class="directorist-apply-form-delete directorist-form-element dashicons dashicons-trash removeFormFieldField"></button>
        </div>
    </div>

<?php endif;?>