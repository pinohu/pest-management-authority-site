<?php
/**
 * @author  wpWax
 * @since   6.6
 * @version 7.4.0
 */

use Directorist\Directorist_Listing_Dashboard;

if ( ! defined( 'ABSPATH' ) ) exit;

$dashboard = Directorist_Listing_Dashboard::instance();
?>

<div class="directorist-dashboard-mylistings" id="directorist-dashboard-mylistings-js" data-paged="1" data-search="">

	<div id="directorist-dashboard-preloader">
		<div></div><div></div><div></div><div></div>
	</div>

	<div class="directorist-user-dashboard-area">

		<div class="directorist-user-dashboard-tab">

			<div class="directorist-user-dashboard-tabcontent">

				<div class="directorist-listing-table directorist-table-responsive">

					<table class="directorist-table">

						<thead>
							<tr>

								<th class="directorist-table-listing">
									<?php esc_html_e( 'Listings', 'directorist' ); ?>
								</th>

								<th class="directorist-table-listing-type">
									<?php esc_html_e( 'Username', 'directorist' ); ?>
								</th>

								<th class="directorist-table-listing-booked">
									<?php esc_html_e( 'Booked On', 'directorist' ); ?>
								</th>

								<th class="directorist-table-listing-refunded">
									<?php esc_html_e( 'Refund Requested On', 'directorist' ); ?>
								</th>

								<th class="directorist-table-ex-date">
									<?php esc_html_e( 'Refund Reason', 'directorist' ); ?>
								</th>

								<th class="directorist-table-ex-date">
									<?php esc_html_e( 'Payment Details', 'directorist' ); ?>
								</th>

								<th class="directorist-table-status">
									<?php esc_html_e( 'Status', 'directorist' ); ?>
								</th>

								<th class="directorist-table-actions"></th>

							</tr>
						</thead>

						<tbody class="directorist-dashboard-listings-tbody">
							<?php include BDB_TEMPLATES_DIR . '/refund-policy/requested-listings.php'; ?>
						</tbody>

					</table>

					<div class="directorist-dashboard-pagination">
						<?php //echo wp_kses_post( $dashboard->listing_pagination() ); ?>
					</div>

				</div>

			</div>

		</div>

	</div>

</div>