(function ($) {
    $(document).ready(function () {
        $('body').on('click', '.mark_sold', function (e) {
            e.preventDefault();
            var _this = $(this);
            var listingID = $(this).attr('data-listing-id');
            var actionType = $(this).attr('data-action');
            // Post via AJAX
            var data = {
                'action': 'mas_user_dashboard_action',
                'post_id': listingID,
                'action_type': actionType,
            };
            $.post(mas_main_js.ajaxurl, data, function (response) {
                $('.mark_sold').after('<span class="directorist-mas-notifier">' + response['message'] + '</span>');
                if(response['action_response'] === 'marked'){
                    $(_this).addClass('directorist-mas-checked');
                }else if(response['action_response'] === 'unmarked'){
                    $(_this).removeClass('directorist-mas-checked');
                }
            }, 'json');
            setTimeout(function () {
                $('.directorist-mas-notifier').fadeOut().remove();
            }, 2000);

            if(actionType == "sold"){
                $(this).parent('.directorist-dropdown-menu__list').find('.directorist-checkbox-absent-input').removeClass('directorist-mas-checked');
            }

        });

        $('body').on('click', '.mark_negotiate', function (e) {
            e.preventDefault();
            var _this = $(this);
            var listingID = $(this).attr('data-listing-id');
            var actionType = $(this).attr('data-action');
            // Post via AJAX
            var data = {
                'action': 'mas_user_dashboard_action',
                'post_id': listingID,
                'action_type': actionType,
            };
            $.post(mas_main_js.ajaxurl, data, function (response) {
                $('.mark_negotiate').after('<span class="directorist-mas-notifier">' + response['message'] + '</span>');
                if(response['action_response'] === 'marked'){
                    $(_this).addClass('directorist-mas-checked');
                }else if(response['action_response'] === 'unmarked'){
                    $(_this).removeClass('directorist-mas-checked');
                }
            }, 'json');
            setTimeout(function () {
                $('.directorist-mas-notifier').fadeOut().remove();
            }, 2000);
            if(actionType == "negotiate"){
                $(this).parent('.directorist-dropdown-menu__list').find('.directorist-checkbox-absent-input').removeClass('directorist-mas-checked');
                $(this).addClass('directorist-mas-checked');
            }

        });
    });
})(jQuery);

