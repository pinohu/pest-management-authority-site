<?php
// silence is golder