<?php
// Plugin version.
if ( ! defined( 'BDSC_VERSION' ) ) {define( 'BDSC_VERSION', $version );}
// Plugin Folder Path.
if ( ! defined( 'BDSC_DIR' ) ) { define( 'BDSC_DIR', plugin_dir_path( BDSC_FILE ) ); }
// Plugin Folder URL.
if ( ! defined( 'BDSC_URL' ) ) { define( 'BDSC_URL', plugin_dir_url( BDSC_FILE ) ); }
// Plugin Root File.
if ( ! defined( 'BDSC_BASE' ) ) { define( 'BDSC_BASE', plugin_basename( BDSC_FILE ) ); }
// Plugin Text domain File.
if ( ! defined( 'BDSC_TEXTDOMAIN' ) ) { define( 'BDSC_TEXTDOMAIN', 'directorist-slider-carousel' ); }
// Plugin Assets Path
if ( !defined('BDSC_ASSETS') ) { define('BDSC_ASSETS', BDSC_URL.'assets/'); }
// Plugin Language File Path
if ( !defined('BDSC_LANG_DIR') ) { define('BDSC_LANG_DIR', dirname(plugin_basename( BDSC_FILE ) ) . '/languages'); }
// Plugin Name
if ( !defined('BDSC_NAME') ) { define('BDSC_NAME', 'Directorist - Listing Slider & Carousel'); }
// plugin author url
if (!defined('ATBDP_AUTHOR_URL')) {
    define('ATBDP_AUTHOR_URL', 'https://directorist.com');
}
// post id from download post type (edd)
if (!defined('ATBDP_SLIDER_POST_ID')) {
    define('ATBDP_SLIDER_POST_ID', 13774 );
}
