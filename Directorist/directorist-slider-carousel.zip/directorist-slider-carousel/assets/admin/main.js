jQuery( document ).ready( function() {
    // auto update and license activation
    var $ = jQuery;
    $('#slider_activated input[name="slider_activated"]').on('change', function (event) {
        event.preventDefault();
        var form_data = new FormData();
        var slider_license = $('#slider_license input[name="slider_license"]').val();
        form_data.append('action', 'atbdp_slider_license_activation');
        form_data.append('slider_license', slider_license);
        $.ajax({
            method: 'POST',
            processData: false,
            contentType: false,
            url: slider_js_obj.ajaxurl,
            data: form_data,
            success: function (response) {
                if (response.status === true){
                    $('#success_msg').remove();
                    $('#slider_activated').after('<p id="success_msg">' + response.msg + '</p>');
                    location.reload();
                }else{
                    $('#error_msg').remove();
                    $('#slider_activated').after('<p id="error_msg">' + response.msg + '</p>');
                }
            },
            error: function (error) {
                //console.log(error);
            }
        });
    });
    // license deactivation
    $('#slider_deactivated input[name="slider_deactivated"]').on('change', function (event) {
        event.preventDefault();
        var form_data = new FormData();
        var slider_license = $('#slider_license input[name="slider_license"]').val();
        form_data.append('action', 'atbdp_slider_license_deactivation');
        form_data.append('slider_license', slider_license);
        $.ajax({
            method: 'POST',
            processData: false,
            contentType: false,
            url: slider_js_obj.ajaxurl,
            data: form_data,
            success: function (response) {
                if (response.status === true){
                    $('#success_msg').remove();
                    $('#slider_deactivated').after('<p id="success_msg">' + response.msg + '</p>');
                    location.reload();
                }else{
                    $('#error_msg').remove();
                    $('#slider_deactivated').after('<p id="error_msg">' + response.msg + '</p>');
                }
            },
            error: function (error) {
                //console.log(error);
            }
        });
    });
});