=== Directorist Listings Slider & Carousel ===
Contributors:      wpwax
Tags:              directory, directorist, directorist faqs, directorist listings slider, directorist listings carousel, directorist listings slider & carousel
Requires at least: 5.7
Tested up to:      6.4
Requires PHP:      7.2
Stable tag:        1.0.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Increase the beauty of your directory website by displaying numerous listings through attractive sliders or carousels with this highly customizable extension.

== Description ==

[DOC](https://directorist.com/documentation/extensions/listings-slider-carousel-listing/listings-slider-carousel/) | [Contact](https://directorist.com/contact/) | [Other Extensions](https://directorist.com/extensions/)

Listing Slider & Carousel is used to display different listings using appealing sliders and carousels. This is a highly customizable extension that boosts up your paid listing submissions and increases your ultimate revenue by attracting more users to your directory listing website.

Why not? Because, all the listings are presented in a more nice and organized way. This type of demonstration helps to attract your visitors and turn them into potential leads. Using this extension, you can display a slider or carousel on any of the pages, post custom templates, and even in the widget section.

== Control by Customizing a Number of Sliders and Carousels ==

As a listing owner, you can have the liberty to customize the sliders and carousels as you want. You will be able to customize the height, width of sliders and enable/disable the image feature option of your carousel.

== Use a Number of Advanced Shortcode Facilities ==

Shortcodes are like magic and this extension will provide you 15+ slider shortcode attributes with 25+ carousel shortcodes attributes.

👉 Join Our FB Community : [Directorist Community](https://www.facebook.com/groups/directorist)
👉 Official Facebook Page : [Like and Follow on Facebook](https://www.facebook.com/directorist)
👉 Official Twitter handle : [Follow on Twitter](https://twitter.com/wpdirectorist)
👉 Official YouTube Channel : [Follow on YouTube](https://www.youtube.com/c/wpWax)
👉 Official Support : [Contact](https://directorist.com/dashboard/)

== REQUIREMENTS ==

The following plugins must be installed in order to translate.

1. Directorist – WordPress Business Directory Plugin with Classified Ads Listings (Free)

== FEATURES AT A GLANCE ==

* Control the number of listings to be displayed
* Customize the Height and Width of a slider
* Show/hide the title, excerpt & navigation.
* Customize the excerpt length
* Show/hide thumbnails
* Customize thumbnail columns
* Shortcode with 18 attributes

== Contribute to Directorist - FAQs ==

If you want to contribute to the project, you’re most welcome to make it happen. The full source code is available on [GitHub](https://github.com/sovware/directorist-slider-carousel). If you find anything improbable, feel free to shoot a bug report.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/` directory, install the plugin through the WordPress plugins screen directly, or search for `QuickPost` in the Block Library.
2. Activate the plugin through the 'Plugins' screen in WordPress if installed manually or through the WordPress plugins screen.
3. Use the `Add New` button in the Block Editor toolbar when needed.

== Screenshots ==
1. Sidebar
2. Carousel
3. Settings
4. Slider on a Live Site
5. Carousel on a Live Site