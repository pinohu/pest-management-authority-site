=== Directorist - Listings FAQs ===
Contributors:      wpwax
Tags:              directory, directorist, directorist faqs, faqs
Requires at least: 5.7
Tested up to:      6.4
Requires PHP:      7.2
Stable tag:        1.0.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Directorist-FAQs integration plugin uses an organized FAQ page on your directory website and provide quick information to help customers make a potential decision. Here, the idea is to keep the answers short and direct so that people find info quickly.

== Description ==

[DOC](https://directorist.com/documentation/extensions/faqs/listing-faqs/) | [Contact](https://directorist.com/contact/) | [Other Extensions](https://directorist.com/extensions/)

Directorist FAQs is a quality extension which is used to provide a quick and easy way to add FAQs pages on your directory listing website. It is very common that every business receives some generic questions from its customers. These general questions regarding a business are also known as Frequently Asked Questions (FAQs).

Through Directorist FAQ, you can display Frequently Asked Questions and their answers in any listings on your directory website. All FAQs will be displayed using a very nice and responsive accordion.

== Generate Traffic and Build Trust By Solving Their Queries ==

Create a well-written FAQ with Directorist that ultimately helps to bring enormous traffic to your directory website. It’s interesting that you know what customers are thinking and you’ve already got an answer to those. It’s a great way to establish trust value among your customers.

== Taking Smart Steps to Address Their Issues ==

Directorist FAQs is an efficient extension to address the issues your potential customers made. If you are accepting public listing using Directorist Pricing Plans/ Directorist WooCommerce Pricing Plans add-ons, you can add more value to a pricing plan by adding FAQs feature to a plan. It is 100% integrated with the Pricing Plans add-ons. Therefore, you can boost your revenue very easily with this add-on. It also offers more features.

👉 Join Our FB Community : [Directorist Community](https://www.facebook.com/groups/directorist)
👉 Official Facebook Page : [Like and Follow on Facebook](https://www.facebook.com/directorist)
👉 Official Twitter handle : [Follow on Twitter](https://twitter.com/wpdirectorist)
👉 Official YouTube Channel : [Follow on YouTube](https://www.youtube.com/c/wpWax)
👉 Official Support : [Contact](https://directorist.com/dashboard/)

== REQUIREMENTS ==

The following plugins must be installed in order to translate.

1. Directorist – WordPress Business Directory Plugin with Classified Ads Listings (Free)

== FEATURES AT A GLANCE ==

* Create unlimited Frequently Asked Questions & Answers.
* Display/Hide FAQs in the listing page content.
* Available FAQs Widget.
* 100% responsive.
* Display them in an animated accordion.
* Very easy to use.
* No configuration needed. Just Plug & Play.
* Compatible with all Directorist add-ons including Pricing Plans/WooCommerce Pricing Plans.
* Very lightweight

== Contribute to Directorist - FAQs ==

If you want to contribute to the project, you’re most welcome to make it happen. The full source code is available on [GitHub](https://github.com/sovware/directorist-faqs). If you find anything improbable, feel free to shoot a bug report.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/` directory, install the plugin through the WordPress plugins screen directly, or search for `QuickPost` in the Block Library.
2. Activate the plugin through the 'Plugins' screen in WordPress if installed manually or through the WordPress plugins screen.
3. Use the `Add New` button in the Block Editor toolbar when needed.

== Screenshots ==
1. Frontend
2. Sidebar Widget
3. Backend