=== Directorist Gallery ===
Contributors:      wpwax
Tags:              directory, directorist, directorist gallery, directorist image gallery
Requires at least: 5.7
Tested up to:      6.4
Requires PHP:      7.2
Stable tag:        1.0.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Use a quality image gallery and increase conversation by reducing your return rate on your directory listing website.

== Description ==

[DOC](https://directorist.com/documentation/extensions/image-gallery/image-gallery/) | [Contact](https://directorist.com/contact/) | [Other Extensions](https://directorist.com/extensions/)

There is a saying that indicates one image worths a thousand words That’s exactly what the Directorist Image Gallery extension does! Directorist Image Gallery extension will help you to convert your website visitors to profitable leads of your business directory listing business. You can simply create unlimited gallery images with tons of advanced visual features and functionalities.

Displaying an image gallery is crucial for business listings that adds a lot of value and attracts more customers on your directory listing business. For example, a listing of a hotel will get more leads if it displays a gallery of images of its rooms than a listing of a hotel without an image gallery. Using the Image Gallery extension will allow you to make it happen.

== Display Professional Images on Your Directory Websites ==

With Image Gallery extension, you can provide an opportunity to your users to place visually enticing images to represent their brand on your directory site. For example, a listing of a hotel will get more leads if it displays a gallery of images of its rooms than a listing of a hotel without an image gallery.

== A Perfect Visual Demonstration to Your Business ==

If you have a directory website that publishes listings like restaurants, hotels, properties, etc; then Image Gallery is a must-have extension for demonstrating your business visually. This will help to boost the ultimate revenue by attracting your audiences.
Users like to see the pictures of foods and place inside a restaurant or the picture of a hotel room or a property. A property listing without an image gallery will not gain proper user trust. Because we all know seeing is believing. Besides, if you are using Directorist Pricing Plans/Directorist WooCommerce Pricing plans add-on, you can increase sales of your plan by adding an image gallery feature to a premium plan. This add-on will make your pricing plan more valuable to your customers.

👉 Join Our FB Community : [Directorist Community](https://www.facebook.com/groups/directorist)
👉 Official Facebook Page : [Like and Follow on Facebook](https://www.facebook.com/directorist)
👉 Official Twitter handle : [Follow on Twitter](https://twitter.com/wpdirectorist)
👉 Official YouTube Channel : [Follow on YouTube](https://www.youtube.com/c/wpWax)
👉 Official Support : [Contact](https://directorist.com/dashboard/)

== REQUIREMENTS ==

The following plugins must be installed in order to translate.

1. Directorist – WordPress Business Directory Plugin with Classified Ads Listings (Free)

== FEATURES AT A GLANCE ==

* 100% responsive gallery
* Unlimited gallery images
* Display every image of a gallery in a beautiful lightbox
* Enable/Disable image cropping feature
* Customize the number of columns to display image gallery
* Customize the width and height of the column of a gallery
* 100% compatible with other add-ons and adds more value to pricing plans add-on.
* Very lightweight in size
* Front-end image gallery upload supported
* Has a very simple interface and easy to use
* Plug & play. No configuration needed though you can customize some settings if you wish.

== Contribute to Directorist - FAQs ==

If you want to contribute to the project, you’re most welcome to make it happen. The full source code is available on [GitHub](https://github.com/sovware/directorist-gallery). If you find anything improbable, feel free to shoot a bug report.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/` directory, install the plugin through the WordPress plugins screen directly, or search for `QuickPost` in the Block Library.
2. Activate the plugin through the 'Plugins' screen in WordPress if installed manually or through the WordPress plugins screen.
3. Use the `Add New` button in the Block Editor toolbar when needed.

== Screenshots ==
1. Gallery Frontend
2. Single Gallery Image
3. Settings
4. Gallery Image Uploader