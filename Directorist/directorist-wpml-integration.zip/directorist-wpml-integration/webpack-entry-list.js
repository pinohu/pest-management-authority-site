module.exports = {
    commonEntries: {
        ['public-main']: "./assets/src/js/public/public-main.js",
        ['admin-main']: "./assets/src/js/admin/admin-main.js",
        ['admin-directory-builder']: "./assets/src/js/admin/directory-builder.js",
    },
}