# Directorist WPML Integration
A WPML integration extension for Directorist
