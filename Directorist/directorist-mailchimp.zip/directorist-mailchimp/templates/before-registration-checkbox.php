<?php
/**
 * @author  wpWax
 * @since   1.1
 * @version 1.0
 */
?>

<div class="directorist-checkbox directorist-mb-15">

	<input id="mc_subscribe" type="checkbox" name="mc_subscribe" checked>
	<label for="mc_subscribe" class="directorist-checkbox__label"><?php echo esc_html( $args ); ?></label>

</div>