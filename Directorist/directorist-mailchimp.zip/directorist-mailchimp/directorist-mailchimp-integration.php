<?php
/**
 * Plugin Name: Directorist - Mailchimp Integration
 * Plugin URI: https://directorist.com/product/directorist-mailchimp-integration
 * Description: This is an extension for Directorist plugin. It allows you to create mailing listing using Mailchimp.
 * Version: 2.2
 * Author: wpWax
 * Author URI: https://wpwax.com
 * License: GPLv2 or later
 * Text Domain: directorist-mailchimp-integration
 * Domain Path: /languages
 */

// Prevent direct access to the file
defined( 'ABSPATH' ) || die( 'No direct script access allowed!' );

if ( ! class_exists( 'Directorist_Mailchimp_Integration' ) ) {

	final class Directorist_Mailchimp_Integration {

		private static $instance;
		public static $base_dir;
		public static $base_url;

		public static function instance() {

			if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Directorist_Mailchimp_Integration ) ) {
				self::$instance = new Directorist_Mailchimp_Integration();
				self::$instance->setup_constants();
				self::$instance->init();
				add_action( 'admin_init', [ self::$instance, 'update_controller' ] );
			}

			return self::$instance;
		}

		private function __construct() {}

		private function init() {
			add_action( 'plugins_loaded', array( $this, 'load_textdomain' ), 20 );

			self::$base_dir = plugin_dir_path( __FILE__ );
			self::$base_url = plugin_dir_url( __FILE__ );

			$this->includes();
		}

		public function update_controller() {

            $data = get_user_meta( get_current_user_id(), '_plugins_available_in_subscriptions', true );
            $license_key = ! empty( $data['directorist-mailchimp-integration'] ) ? $data['directorist-mailchimp-integration']['license'] : '';
            new EDD_SL_Plugin_Updater(ATBDP_AUTHOR_URL, __FILE__, array(
                'version' => DM_VERSION,        // current version number
                'license' => $license_key,    // license key (used get_option above to retrieve from DB)
                'item_id' => DM_POST_ID,    // id of this plugin
                'author' => 'AazzTech',    // author of this plugin
                'url' => home_url(),
                'beta' => false // set to true if you wish customers to receive update notifications of beta releases
            ));
        }

		public function load_textdomain() {
			load_plugin_textdomain( 'directorist-mailchimp-integration', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
		}

		public function includes() {
			require_once self::$base_dir . '/includes/class-helper.php';
			require_once self::$base_dir . '/includes/class-settings-manager.php';
			require_once self::$base_dir . '/vendor/autoload.php';
			require_once self::$base_dir . '/includes/class-mailchimp.php';
			require_once self::$base_dir . '/includes/class-subscribe-after-listing-contact.php';
			require_once self::$base_dir . '/includes/class-subscribe-after-registration.php';

			if ( ! class_exists( 'EDD_SL_Plugin_Updater' ) ) {
                // load our custom updater if it doesn't already exist
                include( dirname( __FILE__ ) . '/includes/EDD_SL_Plugin_Updater.php');
            }
		}

		private function setup_constants()
        {
            // Plugin version
            if (!defined('DM_VERSION')) {
                define('DM_VERSION', self::get_version_from_file_content( __FILE__ ) );
            }
            // post id from download post type (edd)
            if (!defined('DM_POST_ID')) {
                define('DM_POST_ID', 76269);
            }

			// plugin author url
            if (!defined('ATBDP_AUTHOR_URL')) {
                define('ATBDP_AUTHOR_URL', 'https://directorist.com');
            }
        }

		public static function get_version_from_file_content( $file_path = '' ) {
            $version = '';
    
            if ( ! file_exists( $file_path ) ) {
                return $version;
            }
    
            $content = file_get_contents( $file_path );
            $version = self::get_version_from_content( $content );
            
            return $version;
        }

        public static function get_version_from_content( $content = '' ) {
            $version = '';
    
            if ( preg_match('/\*[\s\t]+?version:[\s\t]+?([0-9.]+)/i', $content, $v) ) {
                $version = $v[1];
            }
    
            return $version;
        }
	}

	/**
	 * @return object|Directorist_Mailchimp_Integration
	 * @since 1.0
	 */
	function Directorist_Mailchimp_Integration() {
		return Directorist_Mailchimp_Integration::instance();
	}

	// Instantiate Directorist_Mailchimp_Integration, when Directorist plugin is active
	if ( in_array( 'directorist/directorist-base.php', (array) get_option( 'active_plugins' ) ) ) {
		Directorist_Mailchimp_Integration();
	}
}