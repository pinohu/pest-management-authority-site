<?php
// prevent direct access to folder