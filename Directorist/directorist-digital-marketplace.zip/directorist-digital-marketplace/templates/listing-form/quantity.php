<?php
/**
 * Custom field file upload field template.
 * @package DirectoristDigitalMarketplace
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	die();
}
?>
<div class="ddm-quantity">
	<div class="ddm-checkbox enable-quantity">
		<input type="checkbox" <?php echo !empty(  $args['fields_data']['allow_quantity'] ) ? 'checked' : ''; ?>  name="ddm_allow_quantity" class="ddm-checkbox ddm-checkbox-quantity" id="ddm-checkbox-quantity">
		<label for="ddm-checkbox-quantity" class="ddm-checkbox-label"><?php esc_html_e( 'Available stock', 'directorist-digital-marketplace'); ?></label>
	</div>
	<div class="set-quantity">
		<label for="ddm-set-quantity"><?php esc_html_e( 'Maximum', 'directorist-digital-marketplace'); ?></label>
		<input type="number" value="<?php echo esc_attr(  $args['fields_data']['quantity'] ); ?>" name="ddm_set_quantity" id="ddm-set-quantity" class="ddm-set-quantity" min="1" >
	</div>
	
</div>