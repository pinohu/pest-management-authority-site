<?php
/**
 * Custom field file upload field template.
 * @package DirectoristDigitalMarketplace
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	die();
}
?>
<div class="ddm-checkbox monthly-checkbox">
	<input type="checkbox" <?php echo !empty(  $args['fields_data']['monthly'] ) ? 'checked' : ''; ?> name="ddm_monthly" id="ddm-checkbox-monthly" class="ddm-checkbox ddm-checkbox-monthly">
	<label for="ddm-checkbox-monthly" class="ddm-checkbox-label"><?php esc_html_e( 'Is Monthly?', 'directorist-digital-marketplace'); ?></label>
</div>