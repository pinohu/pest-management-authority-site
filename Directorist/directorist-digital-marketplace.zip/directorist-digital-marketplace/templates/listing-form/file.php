<?php
/**
 * Custom field file upload field template.
 * @package DirectoristDigitalMarketplace
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	die();
}

use DirectoristDigitalMarketplace\Global_Helpers as Global_Helpers;


if( $args['digital_tiers'] ) {
	Global_Helpers\get_template( 'listing-form/tiers', $args );
}

if( $args['digital_extras'] ) {
	Global_Helpers\get_template( 'listing-form/extras', $args );
}

if( $args['digital_hourly'] ) {
	Global_Helpers\get_template( 'listing-form/hourly', $args );
}

if( $args['digital_quantity'] ) {
	Global_Helpers\get_template( 'listing-form/quantity', $args );
}