<?php
/**
 * Custom field file upload field template.
 * @package DirectoristDigitalMarketplace
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	die();
}
?>
<div class="ddm-checkbox hourly-checkbox">
	<input type="checkbox" <?php echo !empty(  $args['fields_data']['hourly'] ) ? 'checked' : ''; ?> name="ddm_hourly" id="ddm-checkbox-hourly" class="ddm-checkbox ddm-checkbox-hourly">
	<label for="ddm-checkbox-hourly" class="ddm-checkbox-label"><?php esc_html_e( 'Is Hourly?', 'directorist-digital-marketplace'); ?></label>
</div>
