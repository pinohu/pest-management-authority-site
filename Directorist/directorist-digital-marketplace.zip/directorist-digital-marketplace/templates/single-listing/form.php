<?php
/**
 * 
 * @package DirectoristDigitalMarketplace
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	die();
}
use DirectoristDigitalMarketplace\Global_Helpers as Global_Helpers;

if( ! empty( $args[ 'fields_data' ]['section'] )  ) { ?>


<div class="directorist-card directorist-card-digital-download" <?php $args['section_id']; ?>>

	<div class="directorist-card__header">

		<h4 class="directorist-card__header--title"><?php directorist_icon( $args['icon'] );?><?php echo esc_html( $args['label'] );?></h4>

	</div>

	<div class="directorist-card__body">

    <form action="#" id="directorist-digital-product">
        <input type="hidden" name="listing_id" value="<?php echo esc_attr( get_the_ID() ); ?>">
    <?php
        if( ! empty( $args['fields_data']['price'] ) ) {
            Global_Helpers\get_template( 'single-listing/pricing', $args );
        }
        if( ! empty( $args['fields_data']['tiers'] ) ) {
            Global_Helpers\get_template( 'single-listing/tiers', $args );
        }

        if( ! empty( $args['fields_data']['extras'] ) ) {
            Global_Helpers\get_template( 'single-listing/extras', $args );
        }

        if( ! empty( $args['fields_data']['allow_quantity'] ) ) {
            Global_Helpers\get_template( 'single-listing/quantity', $args );
        }

        Global_Helpers\get_template( 'single-listing/buy-now', $args );
    ?>
    </form>
	
	</div>

</div>

<?php 
}else{
?>
<form action="#" id="directorist-digital-product">
    <input type="hidden" name="listing_id" value="<?php echo esc_attr( get_the_ID() ); ?>">
<?php
    if( ! empty( $args['fields_data']['price'] ) ) {
        Global_Helpers\get_template( 'single-listing/pricing', $args );
    }
    if( ! empty( $args['fields_data']['tiers'] ) ) {
        Global_Helpers\get_template( 'single-listing/tiers', $args );
    }

    if( ! empty( $args['fields_data']['extras'] ) ) {
        Global_Helpers\get_template( 'single-listing/extras', $args );
    }

    if( ! empty( $args['fields_data']['allow_quantity'] ) ) {
        Global_Helpers\get_template( 'single-listing/quantity', $args );
    }

    Global_Helpers\get_template( 'single-listing/buy-now', $args );
?>
</form>
<?php }

