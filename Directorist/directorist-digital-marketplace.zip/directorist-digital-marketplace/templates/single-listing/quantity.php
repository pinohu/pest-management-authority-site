<?php
/**
 * Custom field file upload field template.
 * @package DirectoristDigitalMarketplace
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	die();
}
?>
<div class="ddm-template single-quantity-template">
	<span class="ddm-template__title"><?php _e( 'Quantity', 'directorist-digital-marketplace' ); ?></span>
	<div class="ddm-template-input">
		<div class="input-part">
			<input type="number" max="<?php echo ! empty( $args['fields_data']['quantity'] ) ? esc_attr( $args['fields_data']['quantity'] ) : ''; ?>" value="1" name="quantity" class="ddm-set-quantity">	
		</div>
	</div>
	
</div>