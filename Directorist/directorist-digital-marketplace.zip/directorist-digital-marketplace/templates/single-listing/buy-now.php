<?php
/**
 * Custom field file upload field template.
 * @package DirectoristDigitalMarketplace
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	die();
}
?>
<div class="ddm_submit-btn">
	<input type="submit" class="buy-now-btn" value="<?php esc_html_e( 'Buy Now', 'directorist-digital-marketplace' ); ?>">
</div>
