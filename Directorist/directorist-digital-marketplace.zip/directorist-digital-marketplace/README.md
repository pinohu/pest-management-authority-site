# Directorist Digital Marketplace
A MVC based plugin starter for WordPress
## Getting Started
#### 1) Find and replace
- DirectoristDigitalMarketplace -> NewPluginName
- 'directorist-digital-marketplace' -> new-plugin-name
- ddm_ -> new_plugin_name_
- DDM_ -> NEW_PLUGIN_NAME_

#### 2) Run following command in terminal

```shell
composer dump-autoload
```