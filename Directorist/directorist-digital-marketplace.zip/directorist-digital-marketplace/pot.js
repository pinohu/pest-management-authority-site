const wpPot = require('wp-pot');
 
wpPot({
  destFile: './languages/directorist-digital-marketplace.pot',
  domain: 'directorist-digital-marketplace',
  package: 'Directorist Digital Marketplace',
  src: './**/*.php'
});