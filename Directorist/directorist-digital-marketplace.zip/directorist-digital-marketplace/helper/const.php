<?php

if ( ! defined( 'DDM_VERSION' ) ) {
    define( 'DDM_VERSION', '2.1' );
}

if ( ! defined( 'DDM_SCRIPT_VERSION' ) ) {
    define( 'DDM_SCRIPT_VERSION', DDM_VERSION );
}

if ( ! defined( 'DDM_FILE' ) ) {
    define( 'DDM_FILE', dirname( dirname( __FILE__ ) ) . '/directorist-digital-marketplace.php' );
}

if ( ! defined( 'DDM_BASE' ) ) {
    define( 'DDM_BASE', dirname( dirname( __FILE__ ) ) . '/' );
}

if ( ! defined( 'DDM_LANGUAGES' ) ) {
    define( 'DDM_LANGUAGES', DDM_BASE . 'languages' );
}

if ( ! defined( 'DDM_POST_TYPE' ) ) {
    define( 'DDM_POST_TYPE', 'directorist-digital-marketplace' );
}

if ( ! defined( 'DDM_TEMPLATE_PATH' ) ) {
    define( 'DDM_TEMPLATE_PATH', DDM_BASE . 'templates/' );
}

if ( ! defined( 'DDM_VIEW_PATH' ) ) {
    define( 'DDM_VIEW_PATH', DDM_BASE . 'view/' );
}

if ( ! defined( 'DDM_URL' ) ) {
    define( 'DDM_URL', plugin_dir_url( DDM_FILE ) );
}

if ( ! defined( 'DDM_ASSET_URL' ) ) {
    define( 'DDM_ASSET_URL', DDM_URL . 'assets/dist/' );
}

if ( ! defined( 'DDM_JS_PATH' ) ) {
    define( 'DDM_JS_PATH',  DDM_ASSET_URL . 'js/' );
}

if ( ! defined( 'DDM_CSS_PATH' ) ) {
    define( 'DDM_CSS_PATH', DDM_ASSET_URL . 'css/' );
}

if ( ! defined( 'DDM_LOAD_MIN_FILES' ) ) {
    define( 'DDM_LOAD_MIN_FILES', ! SCRIPT_DEBUG );
}

// plugin author url
if (!defined('ATBDP_AUTHOR_URL')) {
	define('ATBDP_AUTHOR_URL', 'https://directorist.com');
}

// post id from download post type (edd)
if (!defined('ATBDP_DDM_POST_ID')) {
	define('ATBDP_DDM_POST_ID', 148417);
}