<?php

namespace DirectoristDigitalMarketplace\Module\Core\Widget;

use DirectoristDigitalMarketplace\Module\Core\Widget\DDW_Purchase_Download;

class Purchase {

	/**
	 * Constuctor
	 * 
	 */
	function __construct() {
		add_action( 'widgets_init', [ $this, 'register_download_widget' ] );
	}

	
	public function register_download_widget() {

		register_widget( DDW_Purchase_Download::class );

	}
}