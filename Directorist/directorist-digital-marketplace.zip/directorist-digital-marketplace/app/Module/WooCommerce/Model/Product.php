<?php

namespace DirectoristDigitalMarketplace\Module\WooCommerce\Model;

use DirectoristDigitalMarketplace\Global_Helpers as Global_Helpers;
use WC_Product_Query;
class Product {

	/**
	 * Constuctor
	 * 
	 */
	function __construct() {
		// add_action( 'edit_post', [ $this, 'update_listing' ], 10, 2 );

	}


	/**
	 * Gets related product.
	 *
	 * @param int   $parent_id Parent ID.
	 * @param array $args Query arguments.
	 * @return object
	 */
	public static function get_related( $parent_id, $args = [] ) {

		return Global_Helpers\ddm_get_first_array_value(
			wc_get_products(
				array_merge(
					[
						'parent' => $parent_id,
						'limit'  => 1,
						'post_status' => 'any',
					],
					$args
				)
			)
		);
	}
}