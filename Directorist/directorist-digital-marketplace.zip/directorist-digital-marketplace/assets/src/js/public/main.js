import './../../scss/public-style.scss';

(function($){

    $(document).ready(function () {
        
        /*--------Add Listing --------*/
        const ddmWrapper = document.querySelectorAll(".ddm-listing-wrapper");

        if(ddmWrapper) {
            ddmWrapper.forEach((elm, ind) => {
                /*--------Digital Download Toggle Switch--------*/    
                function toggleDigitalDownload() {
                    var showDigitalDownload = elm.querySelector(".directorist-switch #directorist_digital_download"); 

                    if(showDigitalDownload) {
                        if(showDigitalDownload.checked) {
                            elm.querySelector(".digital-download-toggle").classList.add('digital-download-enable');
                            
                        } else {
                            elm.querySelector(".digital-download-toggle").classList.remove('digital-download-enable');
                        }
                    }
                }

                $('body').on('change', '.ddm-listing-wrapper .directorist-switch .directorist-switch-input', function(e) {
                    toggleDigitalDownload()
                });
                toggleDigitalDownload();


                /*--------Add Tiers SECTION---------*/                  
                $('body').on('click', '.ddm-template__add-btn-tiers', function(e) {
                    e.preventDefault();
                    var checkWrapper = $(this).closest('.ddm-listing-wrapper');

                    if(elm == checkWrapper[0]) {

                        var tiersClone = $(this).siblings('.ddm-template__list-tiers').find('.ddm-template__wrapper-tiers').clone();

                        var tiersItemsList = $(this).siblings('.ddm-template__list-tiers').find('.ddm-template__wrapper-tiers');

                        var tiersItem = $(tiersClone[tiersClone.length - 1]);
                        var tiersTitle = $(tiersClone[tiersClone.length - 1]).find('.ddm-template__input-tiers-title input');
                        var tiersPrice = $(tiersClone[tiersClone.length - 1]).find('.ddm-template__input-tiers-price input');
                        var tiersDescription = $(tiersClone[tiersClone.length - 1]).find('.ddm-template__input-tiers-description input');
                        var tiersFile = $(tiersClone[tiersClone.length - 1]).find('.ddm-template__input-tiers-file input');

                        tiersTitle.attr('id', `ddm-template__input-tiers-title-${tiersItemsList.length}`);
                        tiersTitle.attr('name', `price_tiers[${tiersItemsList.length}][title]`);  
                        tiersTitle.attr('placeholder', `${ ddm_script_helper.i18n.title }`);       

                        tiersPrice.attr('id', `ddm-template__input-tiers-price-${tiersItemsList.length}`);
                        tiersPrice.attr('name', `price_tiers[${tiersItemsList.length}][price]`); 
                        tiersPrice.attr('placeholder', `${ ddm_script_helper.i18n.price }`);                

                        tiersDescription.attr('id', `ddm-template__input-tiers-description-${tiersItemsList.length}`);
                        tiersDescription.attr('name', `price_tiers[${tiersItemsList.length}][description]`); 
                        tiersDescription.attr('placeholder', `${ ddm_script_helper.i18n.description }`);             

                        tiersItem.attr('id', `ddm-template__wrapper-tiers-${tiersItemsList.length}`);

                        tiersItem.attr('data-index', `${tiersItemsList.length}`);
                        
                        $(this).siblings('.ddm-template__list-tiers').append(tiersClone[tiersClone.length - 1]);

                        var tiersParent = $(this).siblings('.ddm-template__list-tiers');

                        // Generate First Tiers
                        if (tiersParent[0].childElementCount == 0) {
                            tiersParent[0].innerHTML =`
                                <div class="ddm-template__wrapper ddm-template__wrapper-tiers" id='ddm-template__wrapper-tiers-0' data-index="0" draggable="true">
                                    <div class="ddm-template__single-wrapper ddm-template__single-wrapper-tiers">
                                        <div class="ddm-template__drag">
                                            <a href="#" class="ddm-template__drag-btn">${ ddm_script_helper.drag_icon }</a>
                                        </div>
                                        <div class="ddm-template__input ddm-template__input-tiers-title">
                                            <input type="text" placeholder="${ ddm_script_helper.i18n.title }" id="ddm-tiers-title-0" name="price_tiers[0][title]" >
                                        </div>
                                        <div class="ddm-template__input ddm-template__input-tiers-price">
                                            <input type="number" placeholder="${ ddm_script_helper.i18n.price }" id="ddm-tiers-price-0" name="price_tiers[0][price]" >
                                        </div>
                                        <div class="ddm-template__input ddm-template__input-tiers-description">
                                            <input type="text" placeholder="${ ddm_script_helper.i18n.description }" id="ddm-tiers-description-0" name="price_tiers[0][description]" >
                                        </div>
                                        <div class="ddm-template__remove ddm-template__remove-tiers">
                                            <a href="#" class="ddm-template__remove-btn ddm-template__remove-btn-tiers">${ ddm_script_helper.trash_icon }</a>
                                        </div>
                                    </div>				 
                                </div>
                            `; 
                        } else {
                            ddmDragDrop();
                        }
                    } 
                });

                // Remove Tiers
                $('body').on('click', '.ddm-template__remove-btn-tiers', function(e) {
                    e.preventDefault();
        
                    $(this).closest('.ddm-template__wrapper-tiers').remove();
        
                    ddmDragDrop();
                });

                
                /*--------Add Extras SECTION---------*/    
                $('body').on('click', '.ddm-template__add-btn-extras', function(e) {
                    e.preventDefault();
                    var checkWrapper = $(this).closest('.ddm-listing-wrapper');

                    if(elm == checkWrapper[0]) {
                        var extrasClone = $(this).siblings('.ddm-template__list-extras').find('.ddm-template__wrapper-extras').clone();
                    
                        var extrasItemsList = $(this).siblings('.ddm-template__list-extras').find('.ddm-template__wrapper-extras'); 

                        var extrasItem = $(extrasClone[extrasClone.length - 1]);
                        var extrasTitle = $(extrasClone[extrasClone.length - 1]).find('.ddm-template__input-extras-title input');
                        var extrasPrice = $(extrasClone[extrasClone.length - 1]).find('.ddm-template__input-extras-price input');

                        extrasTitle.attr('id', `ddm-template__input-extras-title-${extrasItemsList.length}`);
                        extrasTitle.attr('name', `price_extras[${extrasItemsList.length}][title]`); 
                        extrasTitle.attr('placeholder', `${ ddm_script_helper.i18n.title }`);        

                        extrasPrice.attr('id', `ddm-template__input-extras-price-${extrasItemsList.length}`);
                        extrasPrice.attr('name', `price_extras[${extrasItemsList.length}][price]`);
                        extrasPrice.attr('placeholder', `${ ddm_script_helper.i18n.price }`);        

                        extrasItem.attr('id', `ddm-template__wrapper-extras-${extrasItemsList.length}`);
                        extrasItem.attr('data-index', `${extrasItemsList.length}`);

                        $(this).siblings('.ddm-template__list-extras').append(extrasClone[extrasClone.length - 1]);
                        var extrasParent = $(this).siblings('.ddm-template__list-extras');

                        // Generate First Extras
                        if (extrasParent[0].childElementCount == 0) {
                            extrasParent[0].innerHTML =`
                                <div class="ddm-template__wrapper ddm-template__wrapper-extras" id='ddm-template__wrapper-extras-0' data-index="0" draggable="true">
                                    <div class="ddm-template__single-wrapper ddm-template__single-wrapper-extras">
                                        <div class="ddm-template__drag">
                                            <a href="#" class="ddm-template__drag-btn">${ ddm_script_helper.drag_icon }</a>
                                        </div>
                                        <div class="ddm-template__input ddm-template__input-extras-title">
                                            <input type="text" placeholder="Title" id="ddm-extras-title-0" name="price_extras[0][title]" >
                                        </div>
                                        <div class="ddm-template__input ddm-template__input-extras-price">
                                            <input type="number" placeholder="Price" id="ddm-extras-price-0" name="price_extras[0][price]" >
                                        </div>
                                        <div class="ddm-template__input ddm-template__input-extras-description">
                                            <input type="text" placeholder="Description" id="ddm-extras-description-0" name="price_extras[0][description]" >
                                        </div>
                                        <div class="ddm-template__remove ddm-template__remove-extras">
                                            <a href="#" class="ddm-template__remove-btn ddm-template__remove-btn-extras">${ ddm_script_helper.trash_icon }</a>
                                        </div>
                                    </div>				 
                                </div>
                            `; 
                        } else {
                            ddmDragDrop();
                        }
                    } 

                });

                // Remove Extras
                $('body').on('click', '.ddm-template__remove-btn-extras', function(e) {
                    e.preventDefault();

                    $(this).closest('.ddm-template__wrapper-extras').remove();

                    ddmDragDrop();
                }); 


                /*--------Let User to set Quantity---------*/    
                function setQuantity(){ 
                    var quantityCheckbox = elm.querySelector('.ddm-quantity .enable-quantity input[type="checkbox"]');

                    if(quantityCheckbox) {
                        if(quantityCheckbox.checked){
                            elm.querySelector('.ddm-quantity .set-quantity').classList.add('visible-quantity');
                        }
                        else {
                            elm.querySelector('.ddm-quantity .set-quantity').classList.remove('visible-quantity');
                        }
                    }
                }

                $('body').on('click', '.ddm-quantity .enable-quantity input[type="checkbox"]', function(e) {
                    setQuantity();
                });        
                setQuantity();  

            });
        }        


        /*-------- Drag & Drop Section ---------*/
        function ddmDragDrop() {
            var dragElement = null;

            function handleDragStart(e) {
                // Target (this) element is the source node.
                dragElement = this;

                this.classList.add('drag-start');                
            }
            
            function handleDragOver(e) {
                if (e.preventDefault) {
                    e.preventDefault(); // Necessary. Allows us to drop.
                }
                this.classList.add('drag-over');

                return false;
            }

            function handleDragEnter(e) {
                // this / e.target is the current hover target.
            }

            function handleDragLeave(e) {
                this.classList.remove('drag-over');  // this / e.target is previous target element.
            }

            function handleDrop(e) {
                // this/e.target is current target element.
                e.preventDefault()
                
                if (e.stopPropagation) {
                    e.stopPropagation(); // Stops some browsers from redirecting.
                }

                // Don't do anything if dropping the same column we're dragging.
                if (dragElement != this && dragElement !=null) {
                    var droppedElement = dragElement;
                    this.parentNode.removeChild(dragElement);

                    this.insertAdjacentElement('beforebegin',droppedElement);
                    
                    var dropEl = this.previousSibling;
                    handlersDragDrop(dropEl);
                    
                }
                this.classList.remove('drag-start'); 
                this.classList.remove('drag-over');
                return false;
            }

            function handleDragEnd(e) {
                this.classList.remove('drag-start'); 
                this.classList.remove('drag-over');
            }

            function handlersDragDrop(el) {
                el.addEventListener('dragstart', handleDragStart, true);
                el.addEventListener('dragenter', handleDragEnter, false)
                el.addEventListener('dragover', handleDragOver, false);
                el.addEventListener('dragleave', handleDragLeave, false);
                el.addEventListener('drop', handleDrop, false);
                el.addEventListener('dragend', handleDragEnd, false);
            }
            
            function startDragDrop() {
                var items = document.querySelectorAll('.ddm-template__list .ddm-template__wrapper');
                [].forEach.call(items, handlersDragDrop);
            }
            
            startDragDrop();
        }  
        ddmDragDrop(); 


        /*--------Dashboard Wallet--------*/
        function dashboardWallet() {
            const myWallet = document.getElementById('my_wallet');
            if(myWallet) {
                // Payout Part
                const payoutType = document.querySelectorAll('#ddm_process_payout .directorist-form-group input[type="radio"]');
                var selectedPayoutType = document.querySelector('#ddm_process_payout .directorist-form-group input[type="radio"]:checked');
                const payoutDescription = document.querySelectorAll('#ddm_process_payout .directorist-form-group textarea.ddm_payment_method_details');
        
                const btnText = document.getElementById('ddm_submit_payment_method');
                var btnTextUpdated = btnText.innerHTML;

                // Update Button Text on Description
                function updateButtonText () {
                    payoutDescription.forEach((elm, ind) => {
                        var selectedPayoutType = document.querySelector('#ddm_process_payout .directorist-form-group input[type="radio"]:checked');

                        if(elm.id == selectedPayoutType.id) {
                            if(elm.value) {
                                btnTextUpdated = "Request to Payout";
                            } else {
                                btnTextUpdated = 'Save';
                            }
                            // SET text of Button
                            btnText.innerHTML = btnTextUpdated;
                
                            elm.addEventListener('input', function handleChange(event) {
                                var selectedPayoutType = document.querySelector('#ddm_process_payout .directorist-form-group input[type="radio"]:checked');
                                if(elm.id == selectedPayoutType.id) {
                                    if(elm.value) {
                                        btnTextUpdated = "Request to Payout";
                                    } else {
                                        btnTextUpdated = 'Save';
                                    } 
                                }
                                
                                // SET text of Button
                                btnText.innerHTML = btnTextUpdated;
                            });                        
                        }                     
                            
                    });
                }

                // Button Text Update on Type Change
                $(payoutType).change(function() {  
                    updateButtonText();
                });

                updateButtonText(); 


            }
        } 
        dashboardWallet(); 
        

        /*--------Single Listing --------*/
        const ddmProduct = document.querySelectorAll("#directorist-digital-product");

        if(ddmProduct) {
            ddmProduct.forEach((elm, ind) => {

                /*--------Single Listing Pricing--------*/
                function singleListingPricing() {

                    // Initialize First Item Checked
                    function checkFirstItem () {
                        var singleListingTiersInput = elm.querySelectorAll('.ddm-template.single-tiers-template .ddm-template-input .input-part input[type="radio"][name="tiers"]');  
                        
                        if(singleListingTiersInput.length > 0) {
                            var firstListingTiersInput = singleListingTiersInput[0];
                            firstListingTiersInput.setAttribute('checked', '');
                        }                        
                    }

                    checkFirstItem ();

                    var totalPricing = elm.querySelector('.ddm_listing-pricing-total .directorist-listing-price');
                    var extraValues = elm.querySelectorAll('.ddm-template-input .input-part input[type="checkbox"]');
                    var quantityValues = elm.querySelector('.ddm-template-input .input-part input[type="number"].ddm-set-quantity');

                    var selectTiers = elm.querySelectorAll("input[type='radio'][name='tiers']");
                    var selectedTiers = elm.querySelector("input[type='radio'][name='tiers']:checked");

                    var totalQuantity = 1;
                    var pricingAmount;
                    var changeableAmount;
                    var splittedAmount=null;
                    var totalQuantity = 1;
                    var selectedTiersValue = 0;
                    var totalExtraValues = 0; 
                    
                    // For Default Calculation
                    if(selectedTiers) {
                        selectedTiersValue = selectedTiers.defaultValue;
                    }
                    if(quantityValues) {
                        totalQuantity = Number(quantityValues.value);
                    }   

                    if(totalPricing) {
                        var pricingAmount = totalPricing.innerHTML;
                        var splittedAmount = pricingAmount.split("$");
                        var changeableAmount = Number(splittedAmount[1]);

                        if (selectedTiers) {
                            changeableAmount = selectedTiers.defaultValue;
                        }
                
                        pricingAmount = (changeableAmount * totalQuantity) + totalExtraValues;

                        totalPricing.innerHTML = '$' + pricingAmount; 

                    }

                    // Function for Update Buy Now
                    function updateSingleListingBuyNow () {
                        var extraValuesChecked = elm.querySelectorAll('.ddm-template-input .input-part input[type="checkbox"]:checked');

                        var totalExtraValues = 0;
                        var totalQuantity = 1;
                        if(quantityValues) {
                            totalQuantity = Number(quantityValues.value);
                        } 

                        for (var [index, val] of selectTiers.entries()) {
                            if(val.checked) {
                                selectedTiersValue = Number(val.defaultValue);

                                changeableAmount = selectedTiersValue;

                                break;
                            } else {
                                if(selectedTiers) {
                                    selectedTiersValue = selectedTiers.defaultValue;
                                }
                            }
                        }

                        extraValuesChecked.forEach((e) => {
                            var extraValue = Number(e.defaultValue);
                            totalExtraValues += extraValue;
                        })

                        pricingAmount = (changeableAmount * totalQuantity) + totalExtraValues;

                        totalPricing.innerHTML = '$' + pricingAmount;
                    }

                    // Select Tiers Type
                    $(selectTiers).change(function() {        
                        updateSingleListingBuyNow();
                    });

                    // Set Quantity
                    $(quantityValues).change(function() {                
                        updateSingleListingBuyNow();

                    });

                    // Select Extras
                    $(extraValues).change(function() {                
                        updateSingleListingBuyNow();

                    });
                }        
                singleListingPricing(); 
            });
        }


        // process the buy now form
        $('body').on('submit', '#directorist-digital-product', function (e) {
            if (ddm_script_helper.is_admin) return;
            e.preventDefault();
            const $form = $(e.target);

            let form_data = new FormData();

            form_data.append( 'action', 'directoirst_digital_product_purchase_request' );
            form_data.append( 'directorist_nonce', ddm_script_helper.directorist_nonce );

            const fieldValuePairs = $form.serializeArray();

            // Append Form Fields Values
            for ( const field of fieldValuePairs ) {

                if ( '' === field.value ) {
                    continue;
                }

                form_data.append( field.name, field.value );
            }

            $.ajax({
                method: 'POST',
                processData: false,
                contentType: false,
                url: ddm_script_helper.ajax_rul,
                data: form_data,
                success(response) {
                    if( response.error ) {
                        $('.ddm_buy_notice').remove();
                        $( '.ddm_submit-btn' ).append( '<span class="ddm_buy_notice">' + response.error + '</span>');
                    }
                    if( response.success ){
                        window.location.href = response.redirect_url;
                    }
                },
                
                beforeSend: function () {
                    $('.ddm_submit-btn').addClass('ddm_loading');
                },
                complete: function () {
                    $('.ddm_submit-btn').removeClass('ddm_loading');
                },

                error( error ) {
                    console.log( error );
                }
            });

        });

        // process the payout form
        $('body').on('submit', '#ddm_process_payout', function (e) {
            
            if (ddm_script_helper.is_admin) return;
            e.preventDefault();
            const $form = $(e.target);
        
            let form_data = new FormData();

            form_data.append( 'action', 'directoirst_digital_product_request_payout' );
            form_data.append( 'directorist_nonce', ddm_script_helper.directorist_nonce );

            const fieldValuePairs = $form.serializeArray();

            // Append Form Fields Values
            for ( const field of fieldValuePairs ) {

                if ( '' === field.value ) {
                    continue;
                }

                form_data.append( field.name, field.value );
            }

            $.ajax({
                method: 'POST',
                processData: false,
                contentType: false,
                url: ddm_script_helper.ajax_rul,
                data: form_data,
                success(response) {
                    console.log( response );
                    if( response.error ){
                        $('#ddm_notice_board').empty().removeClass( 'ddm_success' ).addClass( 'ddm_error' ).append( response.message );
                    }else{
                        $('#ddm_notice_board').empty().removeClass( 'ddm_error' ).addClass( 'ddm_success' ).append( response.message );
                    }

                },
                beforeSend: function () {
                    $('#ddm_process_payout #ddm_submit_payment_method').addClass('ddm_loading');
                },
                complete: function () {
                    $('#ddm_process_payout #ddm_submit_payment_method').removeClass('ddm_loading');
                    setTimeout( function(){
                        $('#ddm_notice_board').empty(); 
                    }, 1500 );
                },
                error( error ) {
                    console.log( error );
                }
            });

        });


    });

})(jQuery);
