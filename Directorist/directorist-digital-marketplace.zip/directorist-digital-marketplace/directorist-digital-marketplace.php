<?php
/**
 * DirectoristDigitalMarketplace
 *
 * @package           DirectoristDigitalMarketplace
 * @author            WpWax
 * @copyright         2022 WpWax
 * @license           GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name:       Directorist - Digital Marketplace
 * Plugin URI:        https://directorist.com
 * Description:       A simple digital marketplace solution
 * Version:           2.1
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            WpWax
 * Author URI:        https://github.com/syedgalib
 * Text Domain:       directorist-digital-marketplace
 * License:           GPL v2 or later
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Update URI:        https://directorist.com
 */

require dirname( __FILE__ ) . '/vendor/autoload.php';
require dirname( __FILE__ ) . '/app.php';

if ( ! function_exists( 'DirectoristDigitalMarketplace' ) ) {
    function DirectoristDigitalMarketplace() {
        return DirectoristDigitalMarketplace::get_instance();
    }

    if (!class_exists('EDD_SL_Plugin_Updater')) {
        // load our custom updater if it doesn't already exist
        include(dirname(__FILE__) . '/inc/EDD_SL_Plugin_Updater.php');
    }
}

add_action( 'directorist_loaded', 'DirectoristDigitalMarketplace' );

add_action( 'admin_init', 'DirectoristDigitalMarketplace_update_controller' );

function DirectoristDigitalMarketplace_update_controller() {
    $data        = get_user_meta( get_current_user_id(), '_plugins_available_in_subscriptions', true );
    $license_key = ! empty( $data['directorist-digital-marketplace'] ) ? $data['directorist-digital-marketplace']['license'] : '';
    
    new EDD_SL_Plugin_Updater(ATBDP_AUTHOR_URL, __FILE__, array(
        'version' => get_plugin_data( __FILE__ )['Version'],        // current version number
        'license' => $license_key,    // license key (used get_option above to retrieve from DB)
        'item_id' => ATBDP_DDM_POST_ID,    // id of this plugin
        'author' => 'AazzTech',    // author of this plugin
        'url' => home_url(),
        'beta' => false // set to true if you wish customers to receive update notifications of beta releases
    ));
}