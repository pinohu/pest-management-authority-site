const wpPot = require('wp-pot');
 
wpPot({
  destFile: './languages/directorist-buddyboss-integration.pot',
  domain: 'directorist-buddyboss-integration',
  package: 'Directorist BuddyBoss Integration',
  src: './**/*.php'
});