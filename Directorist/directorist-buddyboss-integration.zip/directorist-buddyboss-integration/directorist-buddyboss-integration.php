<?php
/**
 * Plugin Name: Directorist - BuddyBoss Integration
 * Plugin URI:  https://directorist.com/product/directorist-buddyboss-integration
 * Description: BuddyBoss compatibility and integration extension for <a href="https://directorist.com/" target="blank">Directorist</a>
 * Version:     2.0
 * Author:      wpWax
 * Author URI:  https://directorist.com/
 * RequiresWP:  5.0
 * RequiresPHP: 7.0.0
 * License:     GPLv2 or later
 * Text Domain: directorist-buddyboss-integration
 * Domain Path: /languages
 */

/**
 * Directorist buddyboss extension.
 * 
 * @package wpWax\Directorist\BuddyBoss
 */

defined( 'ABSPATH' ) || die();

// plugin author url
if (!defined('ATBDP_AUTHOR_URL')) {
	define('ATBDP_AUTHOR_URL', 'https://directorist.com');
}

// post id from download post type (edd)
if (!defined('ATBDP_DIR_BUDDYBOSS_POST_ID')) {
	define('ATBDP_DIR_BUDDYBOSS_POST_ID', 60945);
}

final class Directorist_BuddyBoss_Integration {

	/**
	 * Self instance.
	 *
	 * @var Directorist_BuddyBoss_Integration
	 */
	private static $instance = null;

	/**
	 * Plugin version.
	 *
	 * @var string
	 */
	public $version;

	/**
	 * Plugin directory path.
	 *
	 * @var string
	 */
	public $plugin_dir;

	/**
	 * Plugin directory url.
	 *
	 * @var string
	 */
	public $plugin_url;

	/**
	 * Plugin template path.
	 *
	 * @var string
	 */
	public $template_dir;

	/**
	 * Instantiate or get the the instance.
	 *
	 * @return Directorist_BuddyBoss_Plugin
	 */
	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		$this->setup_variables();
		$this->setup_actions();
	}

	protected function setup_variables() {
		$this->plugin_dir   = plugin_dir_path( __FILE__ );
		$this->plugin_url   = plugin_dir_url( __FILE__ );
		$this->template_dir = trailingslashit( $this->plugin_dir . 'includes/templates' );
	}

	protected function setup_actions() {
		add_action( 'bp_include', array( $this, 'on_bp_include' ), 90 );
		add_action( 'plugins_loaded', array( $this, 'on_plugins_loaded' ), 20 );
		add_action( 'directorist_loaded', array( $this, 'includes' ) );
		add_action( 'admin_init', [ $this, 'update_controller' ] );
	}

	public function update_controller() {
		$data = get_user_meta( get_current_user_id(), '_plugins_available_in_subscriptions', true );
		$license_key = ! empty( $data['directorist-buddyboss-integration'] ) ? $data['directorist-buddyboss-integration']['license'] : '';

		new EDD_SL_Plugin_Updater(ATBDP_AUTHOR_URL, __FILE__, array(
			'version' => get_plugin_data( __FILE__ )['Version'],        // current version number
			'license' => $license_key,    // license key (used get_option above to retrieve from DB)
			'item_id' => ATBDP_DIR_BUDDYBOSS_POST_ID,    // id of this plugin
			'author' => 'AazzTech',    // author of this plugin
			'url' => home_url(),
			'beta' => false,
		));
	}

	public function includes() {
		// setup the updater
		if (!class_exists('EDD_SL_Plugin_Updater')) {
			// load our custom updater if it doesn't already exist
			include(dirname(__FILE__) . '/inc/EDD_SL_Plugin_Updater.php');
		}
	}

	public function on_plugins_loaded() {		
		if ( ! directorist_is_plugin_active( 'directorist/directorist-base.php' ) ) {
			if ( $this->can_see_admin_notice() ) {
				add_action( 'admin_notices', array( $this, 'show_directorist_missing_admin_notice' ) );
			}
			return;
		}

		if ( ! directorist_is_plugin_active( 'buddyboss-platform/bp-loader.php' ) ) {
			if ( $this->can_see_admin_notice() ) {
				add_action( 'admin_notices', array( $this, 'show_buddyboss_missing_admin_notice' ) );
			}
			return;
		}

		if ( is_admin() ) {
			include_once $this->plugin_dir . 'includes/class-settings.php';
			include_once $this->plugin_dir . 'includes/class-builder.php';
		}

		add_action( 'template_redirect', array( $this, 'redirect_login_registration' ) );

		$this->load_plugin_textdomain();

		// Add link to settings page.
		add_filter( 'plugin_action_links',               array( $this, 'add_plugin_action_links' ), 10, 2 );
		add_filter( 'network_admin_plugin_action_links', array( $this, 'add_plugin_action_links' ), 10, 2 );

		include_once $this->plugin_dir . 'includes/class-template.php';
	}

	public function add_plugin_action_links( $links, $file ) {
		// Return normal links if not BuddyPress.
		if ( plugin_basename( __FILE__ ) !== $file ) {
			return $links;
		}

		$url = add_query_arg( array(
			'post_type' => ATBDP_POST_TYPE,
			'page'      => 'atbdp-settings#extension_settings__buddyboss-integration'
		), self_admin_url( 'edit.php' ) );

		// Add a few links to the existing links array.
		return array_merge( $links, array(
			'settings' => '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'directorist-buddyboss-integration' ) . '</a>',
		) );
	}

	protected function load_plugin_textdomain() {
		load_plugin_textdomain(
			'directorist-buddyboss-integration',
			false,
			dirname( plugin_basename( __FILE__ ) ) . '/languages'
		 );
	}

	protected function can_see_admin_notice() {
		return ( current_user_can( 'install_plugins' ) || current_user_can( 'activate_plugins' ) );
	}

	public function on_bp_include() {
		if ( ! directorist_is_plugin_active( 'directorist/directorist-base.php' ) ) {
			if ( $this->can_see_admin_notice() ) {
				add_action( 'admin_notices', array( $this, 'show_directorist_missing_admin_notice' ) );
			}
			return;
		}

		if ( ! directorist_is_plugin_active( 'buddyboss-platform/bp-loader.php' ) ) {
			if ( $this->can_see_admin_notice() ) {
				add_action( 'admin_notices', array( $this, 'show_buddyboss_missing_admin_notice' ) );
			}
			return;
		}

		include_once $this->plugin_dir . 'includes/listings-common-functions.php';
		include_once $this->plugin_dir . 'includes/class-bp-listings-component.php';
		include_once $this->plugin_dir . 'includes/class-bp-listings-loader.php';
	}

	/**
	 * If the user is on the login page, redirect them to the bb login page. If the user is on the
	 * registration page, redirect them to the bb registration page.
	 * 
	 * @return void
	 */
	public function redirect_login_registration() {
		$login_page_id      = (int) get_directorist_option( 'user_login' );
		$signin_signup_page = (int) get_directorist_option( 'signin_signup_page' );
		$redirect_login     = (bool) get_directorist_option( 'redirect_login_to_bb_login', true );

		if ( $redirect_login &&
			( ( $login_page_id && is_page( $login_page_id ) ) ||
			( $signin_signup_page && is_page( $signin_signup_page ) ) )
		) {
			wp_safe_redirect( wp_login_url() );
			die();
		}

		$registration_page_id = (int) get_directorist_option( 'custom_registration' );
		$redirect_registration = (bool) get_directorist_option( 'redirect_registration_to_bb_registration', true );
		
		if ( $redirect_registration &&
			( ( $registration_page_id && is_page( $registration_page_id ) ) ||
			( $signin_signup_page && is_page( $signin_signup_page ) ) )
		) {
			wp_safe_redirect( wp_registration_url() );
			die();
		}
	}

	/**
	 * Show directorist missing admin notice.
	 * 
	 * When installed but deactivated it'll show an activation link,
	 * and when not installed it'll show an installation link.
	 *
	 * @return void
	 */
	public function show_directorist_missing_admin_notice() {
		$plugin_slug = 'directorist';
		$plugin_file = "{$plugin_slug}/directorist-base.php";

		if ( file_exists( trailingslashit( WP_PLUGIN_DIR ) . $plugin_file ) ) {
			$notice_title = __( 'Activate Directorist', 'directorist-buddyboss-integration' );
			$notice_url   = wp_nonce_url(
				"plugins.php?action=activate&plugin={$plugin_file}&plugin_status=all&paged=1",
				"activate-plugin_{$plugin_file}"
			);
		} else {
			$notice_title = __( 'Install Directorist', 'directorist-buddyboss-integration' );
			$notice_url   = wp_nonce_url(
				self_admin_url( "update.php?action=install-plugin&plugin={$plugin_slug}" ),
				"install-plugin_{$plugin_slug}"
			);
		}

		$notice = wp_kses_data( sprintf(
			/* translators: 1: Plugin name 2: Directorist 3: Directorist installation link */
			__( '%1$s requires %2$s to be installed and activated to function properly. %3$s', 'directorist-buddyboss-integration' ),
			'<strong>' . __( 'Directorist BuddyBoss Integration', 'directorist-buddyboss-integration' ) . '</strong>',
			'<strong>' . __( 'Directorist', 'directorist-buddyboss-integration' ) . '</strong>',
			'<a href="' . esc_url( $notice_url ) . '">' . $notice_title . '</a>'
		) );

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $notice );
	}

	/**
	 * Show buddyboss missing notice.
	 * 
	 * When installed but inactive it'll show an activation link,
	 * otherwise intallation message.
	 *
	 * @return void
	 */
	public function show_buddyboss_missing_admin_notice() {
		$plugin_slug = 'buddyboss-platform';
		$plugin_file = "{$plugin_slug}/bp-loader.php";

		if ( file_exists( trailingslashit( WP_PLUGIN_DIR ) . $plugin_file ) ) {
			$notice_title = __( 'Activate BuddyBoss Platform', 'directorist-buddyboss-integration' );
			$notice_url   = wp_nonce_url(
				"plugins.php?action=activate&plugin={$plugin_file}&plugin_status=all&paged=1",
				"activate-plugin_{$plugin_file}"
			);
		} else {
			$notice_title = __( 'Download & Install BuddyBoss Platform', 'directorist-buddyboss-integration' );
			$notice_url   = 'https://www.buddyboss.com/platform/';
		}

		$notice = wp_kses_data( sprintf(
			/* translators: 1: Plugin name 2: Directorist 3: Directorist installation link */
			__( '%1$s requires %2$s to be installed and activated to function properly. %3$s', 'directorist-buddyboss-integration' ),
			'<strong>' . __( 'Directorist BuddyBoss Integration', 'directorist-buddyboss-integration' ) . '</strong>',
			'<strong>' . __( 'BuddyBoss Flatform', 'directorist-buddyboss-integration' ) . '</strong>',
			'<a href="' . esc_url( $notice_url ) . '">' . $notice_title . '</a>'
		) );

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $notice );
	}
}

if ( ! function_exists( 'directorist_is_plugin_active' ) ) {
    function directorist_is_plugin_active( $plugin ) {
        return in_array( $plugin, (array) get_option( 'active_plugins', array() ), true ) || directorist_is_plugin_active_for_network( $plugin );
    }
}

if ( ! function_exists( 'directorist_is_plugin_active_for_network' ) ) {
    function directorist_is_plugin_active_for_network( $plugin ) {
        if ( ! is_multisite() ) {
            return false;
        }
                
        $plugins = get_site_option( 'active_sitewide_plugins', array() );
        return isset( $plugins[ $plugin ] );
    }
}

function directorist_buddyboss() {
	return Directorist_BuddyBoss_Integration::get_instance();
}

directorist_buddyboss();
