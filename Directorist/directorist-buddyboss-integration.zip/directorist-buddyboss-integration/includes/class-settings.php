<?php
/**
 * Directorist BuddyBoss settings panel.
 * 
 * @package wpWax\Directorist\BuddyBoss
 * @since Directorist\BuddyBoss 1.0.0
 */
namespace wpWax\Directorist\BuddyBoss;

defined( 'ABSPATH' ) || die();

class Settings {

	public static function init() {
		add_action( 'atbdp_listing_type_settings_layout', array( __CLASS__, 'register_panel' ) );
		add_filter( 'atbdp_listing_type_settings_field_list', array( __CLASS__, 'register_fields' ) );
	}

	protected static function default_selected_activity_events() {
		$events = wp_list_pluck( self::activity_events(), 'value' );

		if ( ! get_directorist_option( 'enable_add_listing_sharing', true ) ) {
			$index = array_search( 'publish_listing', $events, true );
			if ( $index !== false ) {
				$events[ $index ] = null;
			}
		}

		return $events;
	}

	protected static function activity_events() {
		return array(
			array(
				'value' => 'publish_listing',
				'label' => __( 'Publish a new listing', 'directorist' ),
			),
			array(
				'value' => 'favorite_listing',
				'label' => __( 'Favorite a listing', 'directorist' ),
			),
			array(
				'value' => 'purchase_price_plan',
				'label' => __( 'Purchase a pricing plan', 'directorist' ),
			),
			array(
				'value' => 'review_listing',
				'label' => __( 'Review a listing', 'directorist' ),
			),
		);
	}

	protected static function get_my_profile_fields() {
		$activity_status = '';
		if ( ! bp_is_active( 'activity' ) ) {
			$activity_status = sprintf( '<mark>%s</mark> ', esc_html__( 'NOTICE: Activity Feed is disabled.', 'directorist-buddyboss-integration' ) );
		}

		return array(
			// 'bb_user_activity_events' => [
			// 	'label'       => __( 'User Activity Events', 'directorist-buddyboss-integration' ),
			// 	'description' => __( 'Share activity update on users timeline whenever the selected event occurs.', 'directorist-buddyboss-integration' ),
			// 	'type'        => 'checkbox',
			// 	'value'       =>  self::default_selected_activity_events(),
			// 	'options'     => self::activity_events(),
			// ],
			'enable_add_listing_sharing' => array(
				'type'        => 'toggle',
				'label'       => __( 'Add Listing Sharing', 'directorist-buddyboss-integration' ),
				'description' => $activity_status . __( 'Allow users to share activity update on timeline when the user creates a new listing.', 'directorist-buddyboss-integration' ),
				'value'       => bp_is_active( 'activity' ),
			),
			'enable_listing_sharing' => array(
				'type'        => 'toggle',
				'label'       => __( 'Allow Listing Sharing', 'directorist-buddyboss-integration' ),
				'description' => $activity_status . __( 'Allow users to share a single listing on their timeline from single listing view.', 'directorist-buddyboss-integration' ),
				'value'       => bp_is_active( 'activity' ),
			),
			'bp_listing_sharing_text' => array(
				'type'        => 'text',
				'label'       => __( 'Share Button Text', 'directorist-buddyboss-integration' ),
				'description' => __( 'Update listing sharing button text from here.', 'directorist-buddyboss-integration' ),
				'value'       => __( 'On Timeline', 'directorist-buddyboss-integration' ),
			),
			'bp_my_listings_view' => array(
				'type'        => 'select',
				'label'       => __( 'My Listings Default View', 'directorist-buddyboss-integration' ),
				'description' => __( 'Select a default layout view for my listings (My Listings & Favorites).', 'directorist-buddyboss-integration' ),
				'value'       => 'grid',
				'options'     => array(
					array(
						'value' => 'grid',
						'label' => __( 'Grid View', 'directorist-buddyboss-integration' ),
					),
					array(
						'value' => 'list',
						'label' => __( 'List View', 'directorist-buddyboss-integration' ),
					),
					array(
						'value' => 'map',
						'label' => __( 'Map View', 'directorist-buddyboss-integration' ),
					),
				),
			),
			'bp_my_listings_per_page' => array(
				'type'        => 'number',
				'label'       => __( 'Listings Per Page', 'directorist-buddyboss-integration' ),
				'description' => __( 'Set the number of listings to show at a time. Keep it low (3-12) to load the page faster.', 'directorist-buddyboss-integration' ),
				'value'       => 6,
				'min'         => 1,
				'max'         => 20,
			),
		);
	}

	public static function get_group_listings_fields() {
		return array(
			'enable_group_listings' => array(
				'type'        => 'toggle',
				'label'       => __( 'Enable Group Directory Listings', 'directorist-buddyboss-integration' ),
				'description' => __( 'Group admin will get the access to create directory listings.', 'directorist-buddyboss-integration' ),
				'value'       => false,
			),
			'bp_group_listings_view' => array(
				'type'        => 'select',
				'label'       => __( 'Listings Default View', 'directorist-buddyboss-integration' ),
				'description' => __( 'Select a default layout view for group directory listings.', 'directorist-buddyboss-integration' ),
				'value'       => 'grid',
				'options'     => array(
					array(
						'value' => 'grid',
						'label' => __( 'Grid View', 'directorist-buddyboss-integration' ),
					),
					array(
						'value' => 'list',
						'label' => __( 'List View', 'directorist-buddyboss-integration' ),
					),
					array(
						'value' => 'map',
						'label' => __( 'Map View', 'directorist-buddyboss-integration' ),
					),
				),
			),
			'bp_group_listings_per_page' => array(
				'type'        => 'number',
				'label'       => __( 'Listings Per Page', 'directorist-buddyboss-integration' ),
				'description' => __( 'Set the number of listings to show at a time. Keep it low (3-12) to load the page faster.', 'directorist-buddyboss-integration' ),
				'value'       => 6,
				'min'         => 1,
				'max'         => 20,
			),
		);
	}

	public static function get_page_redirection_fields() {
		return array(
			'redirect_login_to_bb_login' => array(
				'type'        => 'toggle',
				'label'       => __( 'Login Redirect', 'directorist-buddyboss-integration' ),
				'description' => __( 'Redirect Directorist login page to default login page.', 'directorist-buddyboss-integration' ),
				'value'       => true,
			),
			'redirect_registration_to_bb_registration' => array(
				'type'        => 'toggle',
				'label'       => __( 'Registration Redirect', 'directorist-buddyboss-integration' ),
				'description' => __( 'Redirect Directorist registration page to default registration page.', 'directorist-buddyboss-integration' ),
				'value'       => true,
			),
		);
	}

	public static function register_fields( $fields ) {
		return array_merge(
			$fields,
			self::get_my_profile_fields(),
			self::get_group_listings_fields(),
			self::get_page_redirection_fields()
		);
	}

	public static function register_panel( $layout ) {
		$layout['extension_settings']['submenu']['buddyboss-integration'] = array(
			'label' => __( 'BuddyBoss', 'directorist-buddyboss-integration' ),
			'icon' => '<i class="fa fa-circle"></i>',
			'sections' => array(
				'my_profile_settings' => array(
					'title' => __( 'User Profile', 'directorist-buddyboss-integration' ),
					'fields' => array_keys( self::get_my_profile_fields() )
				),
				'group_listings_settings' => array(
					'title' => __( 'Group Directory', 'directorist-buddyboss-integration' ),
					'fields' => array_keys( self::get_group_listings_fields() )
				),
				'page_directions' => array(
					'title' => __( 'Pages', 'directorist-buddyboss-integration' ),
					'fields' => array_keys( self::get_page_redirection_fields() )
				)
			),
		);

		return $layout;
	}
}

Settings::init();
