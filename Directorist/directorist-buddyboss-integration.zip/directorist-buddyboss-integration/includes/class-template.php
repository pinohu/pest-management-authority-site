<?php
/**
 * Directorist BuddyBoss template class.
 * 
 * @package wpWax\Directorist\BuddyBoss
 * @since Directorist\BuddyBoss 1.0.0
 */
namespace wpWax\Directorist\BuddyBoss;

defined( 'ABSPATH' ) || die();

class Template {

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'add_styles' ) );
		add_filter( 'directorist_template_file_path', array( __CLASS__, 'add_template_file_path' ), 10, 2 );
		add_filter( 'directorist_single_listing_widget_value', array( __CLASS__, 'set_single_listing_widget_value' ), 10, 2 );
	}
	
	public static function set_single_listing_widget_value( $value, $data ) {
		if ( $data['widget_name'] === 'bp_message_button' ) {
			$value = true;
		}
		
		return $value;
	}

	public static function add_styles() {
		$data = <<<STYLE
		.dbb-btn--single {
			margin-top: 20px;
			margin-bottom: 20px;
		}
		.dbb-btn--archive {
			color: #767792;
			padding-left: 5px;
			padding-right: 5px;
		}
STYLE;
		wp_add_inline_style(
			'directorist-main-style',
			$data
		);
	}

	public static function add_template_file_path( $file_path, $template_file ) {
		if ( 'archive/fields/bp_message_button' === $template_file ) {
			$_template_file = directorist_buddyboss()->template_dir . 'directorist/archive-message-button.php';

			if ( is_readable( $_template_file ) ) {
				$file_path = $_template_file;
			}
		}

		if ( 'single/fields/bp_message_button' === $template_file ) {
			$_template_file = directorist_buddyboss()->template_dir . 'directorist/single-message-button.php';

			if ( is_readable( $_template_file ) ) {
				$file_path = $_template_file;
			}
		}

		return $file_path;
	}
}

Template::init();
