<?php
/**
 * Actions related functions.
 * 
 */
defined( 'ABSPATH' ) || die();


function dbb_listing_share_action() {
	// Return early when activiy feed is disabled
	if ( ! bp_is_active( 'activity' ) ) {
		return;
	}

	if ( ! dbb_is_admin_listing_sharing_enabled() || ! bp_is_current_action( 'favorite' ) ) {
		return;
	}

	$action_type = bp_action_variable( 0 );
	$action_value = bp_action_variable( 1 );
	
	if ( empty( $action_type ) || $action_type !== 'share' || empty( $action_value ) ) {
		return;
	}

	$nonce = isset( $_GET['_wpnonce'] ) ? $_GET['_wpnonce'] : '';
	if ( ! wp_verify_nonce( $nonce, 'dbb_single_listing_share_on_timeline' ) ) {
		return;
	}
	
	$listing = get_post( (int) $action_value );
	if ( empty( $listing ) || $listing->post_type !== ATBDP_POST_TYPE || $listing->post_status !== 'publish' ) {
		return;
	}
	
	dbb_listings_record_activity( array(
		'type'    => 'shared_listing',
		'item_id' => $listing->ID,
	) );

	bp_core_redirect( trailingslashit( bp_loggedin_user_domain() . bp_get_activity_slug() ) );
}
add_action( 'bp_actions', 'dbb_listing_share_action' );

/**
 * When a new listing is published, record an activity for it
 * 
 * @param string $new_status The new status of the post.
 * @param string $old_status The status of the post before the transition.
 * @param WP_Post $post The post object.
 * 
 * @return void.
 */
function dbb_transition_post_status_action( $new_status, $old_status, $post ) {
	// Return early when activity feed is disabled
	if ( ! bp_is_active( 'activity' ) ) {
		return;
	}
	
	if ( $new_status === $old_status || $post->post_type !== ATBDP_POST_TYPE || ! dbb_is_admin_add_listing_sharing_enabled() ) {
		return;
	}

	// Statuses to check the old status
    $old_statuses = array( 'new', 'auto-draft', 'draft', 'private', 'pending', 'future' );

    // Statuses to check the new status
    $new_statuses = array( 'publish' );

    // Check if post status transition come to publish
    if ( ! in_array( $old_status, $old_statuses, true ) || ! in_array( $new_status, $new_statuses, true ) ) {
		return;
	}

	$activity_args = array(
		'type'      => 'new_listing',
		'item_id'   => $post->ID,
		'user_id'   => $post->post_author,
		'component' => buddypress()->listings->id,
	);

	$activity_id = bp_activity_get_activity_id( $activity_args );

	if ( $activity_id ) {
		return;
	}
	
	dbb_listings_record_activity( $activity_args );
}
add_action( 'transition_post_status', 'dbb_transition_post_status_action', 10, 3 );

function dbb_delete_activity( $listing_id ) {
	if ( get_post_type( $listing_id ) !== ATBDP_POST_TYPE || ! function_exists( 'bp_activity_delete' ) ) {
		return;
	}

	$activity_args = array(
		'item_id'   => $listing_id,
		'component' => buddypress()->listings->id,
		'type'      => 'new_listing',
	);

	// Delete new listing activity
	bp_activity_delete( $activity_args );

	// Delete shared listing activity
	$activity_args['type'] = 'shared_listing';
	bp_activity_delete( $activity_args );
	
	// Delete new listing built in activity
	$activity_args = array(
		'secondary_item_id' => $listing_id,
		'component' => 'blogs',
		'type'      => 'new_blog_' . ATBDP_POST_TYPE,
	);

	bp_activity_delete( $activity_args );
}
add_action( 'delete_post', 'dbb_delete_activity' );
add_action( 'wp_trash_post', 'dbb_delete_activity' );
