<?php
/**
 * Listings common functions.
 * 
 * Define functions that are globally accessible in all listigns files.
 */
defined( 'ABSPATH' ) || die();

/**
 * Check add listings shareing is enabled in admin settings.
 *
 * @return bool
 */
function dbb_is_admin_add_listing_sharing_enabled() {
	return (bool) get_directorist_option( 'enable_add_listing_sharing', true );
}

/**
 * Check notification is enabled in admin settings.
 *
 * @return bool
 */
function dbb_is_admin_notification_enabled() {
	return (bool) get_directorist_option( 'enable_notification', true );
}

/**
 * Check add favorite sharing is enabled in admin settings.
 *
 * @return bool
 */
function dbb_is_admin_add_favorite_sharing_enabled() {
	return (bool) get_directorist_option( 'enable_add_favorite_sharing', true );
}

/**
 * Check listings sharing is enabled in admin settings.
 *
 * @return bool
 */
function dbb_is_admin_listing_sharing_enabled() {
	return (bool) get_directorist_option( 'enable_listing_sharing', true );
}

/**
 * Check group listings is enabled in admin settings.
 *
 * @return bool
 */
function dbb_is_admin_group_listings_enabled() {
	return (bool) get_directorist_option( 'enable_group_listings', false );
}

function dbb_listings_dropdown( $args = array() ) {
	$args = wp_parse_args( $args, array(
		'class'       => '',
		'id'          => '',
		'value'       => array(),
		'name'        => 'directorist_listings_dropdown',
		'placeholder' => __( 'Type and select...', 'directorist-buddyboss-integration' ),
	) );

	$query_args = array(
		'post_type'              => ATBDP_POST_TYPE,
		'post_status'            => 'publish',
		'orderby'                => 'date',
		'order'                  => 'DESC',
		'posts_per_page'         => 10,
		'no_found_rows'          => true,
		'update_post_meta_cache' => false,
		'update_post_term_cache' => false,
	);

	$selected = false;

	if ( ! empty( $args['value'] ) ) {
		$query_args['orderby']        = 'post__in';
		$query_args['post__in']       = $args['value'];
		$query_args['posts_per_page'] = count( $args['value'] );
		$selected = true;
	}

	$query    = new WP_Query( $query_args );
	$listings = $query->have_posts() ? $query->posts : array();

	?>
	<select
		style="width:100%"
		name="<?php echo esc_attr( $args['name'] ); ?>[]"
		id="<?php echo esc_attr( $args['id'] ); ?>"
		class="<?php echo esc_attr( $args['class'] ); ?>"
		multiple="multiple"
		data-placeholder="<?php echo esc_attr( $args['placeholder'] ); ?>">
		<?php
		if ( ! empty( $listings ) ) :
			foreach ( $listings as $listing ) : ?>
				<option <?php echo $selected ? 'selected="selected"' : ''; ?> value="<?php echo esc_attr( $listing->ID ); ?>"><?php echo esc_html( $listing->post_title ); ?></option>
			<?php endforeach; ?>
		<?php else : ?>
			<option value=""><?php echo esc_attr( $args['placeholder'] ); ?></option>
		<?php endif; ?>
	</select>
	<?php
}



/**
 * Count user listings.
 * 
 * @param int $user_id
 * 
 * @return int
 */
function dbb_count_user_listings( $user_id = 0 ) {
	global $wpdb;

	$sql = "SELECT COUNT(*) FROM $wpdb->posts WHERE post_type = '%s' AND post_status = 'publish' AND post_author = %d";

	$count = $wpdb->get_var( $wpdb->prepare( $sql, ATBDP_POST_TYPE, $user_id ) );

	return $count;
}

function dbb_get_send_message_link( $user_id ) {
	if ( ! is_user_logged_in() ) {
		return;
	}

	$url = add_query_arg( array(
		'r' => bp_core_get_username( $user_id ),
	), trailingslashit( bp_loggedin_user_domain() . bp_get_messages_slug() . '/compose' ) );
	
	return esc_url( wp_nonce_url( $url ) );
}

/**
 * Compare the BuddyPress Platform version with the given version and operator.
 * Default version is 2.0 and operator >=
 * 
 * @since 1.6.0
 * @param string $version The version of BuddyPress Platform you want to check against.
 * @param string $operator The comparison operator. See PHP's version_compare() for a list of possible
 * operators.
 * @return bool
 */
function dbb_is_platform_version( $version = '2.0', $operator = '>=' ) {
	return defined( 'BP_PLATFORM_VERSION' ) && version_compare( BP_PLATFORM_VERSION, $version, $operator );
}

/**
 * Get the user's favorite listings
 *
 * @param int $user_id The user ID of the user whose favorites you want to retrieve.
 *
 * @return array An array of listing IDs.
 */
function dbb_get_user_favorites( $user_id = 0 ) {
	if ( function_exists( 'directorist_get_user_favorites' ) ) {
		return directorist_get_user_favorites( $user_id );
	}

	$favorites = get_user_meta( $user_id, 'atbdp_favourites', true );

	if ( ! empty( $favorites ) && is_array( $favorites ) ) {
		$favorites = array_values( $favorites );
		$favorites = array_map( 'absint', $favorites );
		$favorites = array_filter( $favorites );
		$favorites = array_unique( $favorites );
	} else {
		$favorites = array();
	}

	return $favorites;
}

/**
 * Get the favorite listings count.
 *
 * @param  int  $user_id
 *
 * @return int
 */
function dbb_get_user_favorites_count( $user_id = 0 ) {
	$favorites = dbb_get_user_favorites( $user_id );

	if ( empty( $favorites ) ) {
		return 0;
	}

	$listings = get_posts( array(
		'post_type'        => ATBDP_POST_TYPE,
		'status'           => 'publish',
		'post__in'         => $favorites,
		'fields'           => 'ids',
		'suppress_filters' => false,
	) );

	if ( empty( $listings ) ) {
		return 0;
	}

	return count( $listings );
}
