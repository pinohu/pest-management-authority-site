<?php do_action( 'bp_before_member_' . bp_current_action() . '_content' ); ?>

<?php echo dbb_run_shortcode_callback( 'directorist_add_listing' ); ?>

<?php do_action( 'bp_after_member_' . bp_current_action() . '_content' ); ?>
