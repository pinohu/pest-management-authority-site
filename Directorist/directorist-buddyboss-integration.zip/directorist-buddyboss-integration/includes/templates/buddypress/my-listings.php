<?php do_action( 'bp_before_member_' . bp_current_action() . '_content' ); ?>

<?php
$args = array(
	'orderby'             => 'date',
	'order'               => 'DESC',
	'view'                => get_directorist_option( 'bp_my_listings_view', 'grid' ),
	'advanced_filter'     => 'no',
	'listings_per_page'   => get_directorist_option( 'bp_my_listings_per_page', 6 ),
	'logged_in_user_only' => 'no',
);

echo dbb_run_shortcode_callback( 'directorist_all_listing', $args );
?>

<?php do_action( 'bp_after_member_' . bp_current_action() . '_content' ); ?>
