<?php
/**
 * @package  Directorist - Compare Listing
 */

if( ! class_exists( 'IncludeClasses' ) ){
    /**
     * All classes includer class
     */
    class IncludeClasses
    {   
        public static function includes(){

            $plugin_path = dirname(__FILE__).'/';

            $files = array( 
                'Inc/Controller/Base/Enqueue',
                'Inc/Controller/Base/Activate',
                'Inc/Controller/Base/AjaxHandler',
                'Inc/Controller/Base/CompareButton',
                'Inc/Controller/Base/HelperFunctions',
                'Inc/Controller/Base/ExtensionSettings',
                'Inc/Controller/Shortcodes/ShortcodeListingCompare'
            );

            foreach( $files as $file ){
                $file_path = $plugin_path . $file . '.php';
            
                if( file_exists( $file_path ) ){
                    require_once( $file_path ); 
                }
            }
        }

    }// End class

}
