<div id='directorist-compare-listing-wrapper' class='directorist-compare-listing-wrapper'>
    <div class='directorist-compare-listing-collapse'>
        <div id='directorist-compare-listing-count' class='directorist-compare-listing-count'><?php echo $total_selected; ?></div>
            <div id='directorist-compare-listing-collapse-out' class='directorist-compare-listing-collapse-btn'>
            <?php directorist_icon( 'las la-exchange-alt' ); ?>
        </div>
    </div>
    
    <div class='directorist-compare-listing-items'>
        <h2 class='directorist-compare-listing-items__title'><?php echo $window_title; ?></h2>

        <div id='directorist-compare-listing-items__wrapper' class='directorist-compare-listing-items__wrapper'>
            <?php while( $listings_query->have_posts() ) : $listings_query->the_post();
                $listing_id = get_the_ID();

                // Get listing image
                $default_img = get_directorist_option( 'default_preview_image', ATBDP_PUBLIC_ASSETS .'images/grid.jpg' );
                $prv_img     = get_post_meta( $listing_id, '_listing_prv_img', true );
                $prv_img_src = atbdp_get_image_source( $prv_img );
                $img_src     = ! empty( $prv_img_src ) ? $prv_img_src : $default_img;
                ?>
                
                <div id='directorist-compare-listing-single<?php echo $listing_id; ?>' class='directorist-compare-listing-single'>
                    <div class='directorist-compare-listing-single__img'>
                        <img src='<?php echo $img_src; ?>' alt=''>
                    </div>
                    <div class="directorist-compare-listing-single__content">
                        <p class='directorist-compare-listing-single__title'><?php echo get_the_title( $listing_id );?></p>
                        <div class="directorist-compare-listing-single__action">
                            <div id='directorist-compare-listing-single__action__btn' remove_btn_id='<?php echo $listing_id; ?>' class='directorist-compare-listing-single__action__btn'>
                            <?php directorist_icon( 'las la-trash' ); ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; wp_reset_query(); ?>
        </div>

        <div class='directorist-compare-listing-all'>
            <a id='directorist-compare-listing-all__btn' class='directorist-compare-listing-all__btn' href='<?php echo ! empty( $compare_page_url ) ? esc_url( $compare_page_url ) : ''; ?>' target='_blank'><?php echo $compare_button_title; ?></a>
        </div>
    </div>
</div>