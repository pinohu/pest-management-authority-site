<?php
/**
 * @package  Directorist - Compare Listing
 */

// Select window
$select_window = "
<div id='directorist-compare-listing-wrapper' class='directorist-compare-listing-wrapper'>
    <div class='directorist-compare-listing-collapse'>
        <div id='directorist-compare-listing-count' class='directorist-compare-listing-count'>$total_selected</div>
            <div id='directorist-compare-listing-collapse-out' class='directorist-compare-listing-collapse-btn'>
            " . directorist_icon( 'las la-exchange-alt', false ) . "
        </div>
    </div>
    <div class='directorist-compare-listing-items'>
        <h2 class='directorist-compare-listing-items__title'>$select_window_title</h2>
        <div id='directorist-compare-listing-items__wrapper' class='directorist-compare-listing-items__wrapper'>
            <div id='directorist-compare-listing-single$selected_listing_id' class='directorist-compare-listing-single'>
                <div class='directorist-compare-listing-single__img'>
                    <img src='$img_src' alt=''>
                </div>
                <div class='directorist-compare-listing-single__content'>
                    <p class='directorist-compare-listing-single__title'>$listing_title</p>
                    <div class='directorist-compare-listing-single__action'>
                        <div id='directorist-compare-listing-single__action__btn' remove_btn_id='$selected_listing_id' class='directorist-compare-listing-single__action__btn'>
                        " . directorist_icon( 'las la-trash', false ) . "
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='directorist-compare-listing-all'>
            <a id='directorist-compare-listing-all__btn' class='directorist-compare-listing-all__btn' href='$compare_page_url' target='_blank'>$compare_btn_title</a>
        </div>
    </div>
</div>
";

return $select_window;