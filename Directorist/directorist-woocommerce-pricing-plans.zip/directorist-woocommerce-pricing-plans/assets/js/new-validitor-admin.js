jQuery(document).ready(function ($) {

    // show allowancess on plan selection
    // $('#directorist-allowances').hide();
    // $('body').on('change', 'select[name=admin_plan]', function (e) {
    //     e.preventDefault();
    //     e.stopPropagation();
    //     $('#dcl-claim-warning-notification').html(' ');
    //     var data = {
    //         'action': 'plan_allowances',
    //         'plan_id': $(this).val(),
    //         'user_id': $('select[name=post_author_override]').val(),
    //     };
    //     $.post(new_validator_admin.ajaxurl, data, function (response) {
    //         if (response){
    //             if (response != 0) {
    //                 $('#directorist-allowances').show();
    //                 $('#directorist-allowances').html(response.split('<!--end-->')[0]);
    //             } else {
    //                 $('#directorist-allowances').html(' ');
    //             }
    //         }else{
    //             $('#directorist-allowances').html(' ');
    //         }

    //     });
    // });


});