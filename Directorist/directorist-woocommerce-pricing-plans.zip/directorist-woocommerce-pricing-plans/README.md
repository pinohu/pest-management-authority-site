<p align="center">
<a href="https://packagist.org/packages/waxframework/waxframework"><img src="https://img.shields.io/packagist/l/waxframework/framework" alt="License"></a>
</p>

# About Directorist - WooCommerce Pricing Plan

It is an extension of Directorist which allows users to collect money using WooCommerce cart and checkout. It also supports WooCommerce Subscription too

## Test Cases

1. Purchase pay per listing/package plan
2. Package allowance restriction
3. Listings duration (expiration)
4. Upgrade/Downgrade from the user dashboard
5. Purchase plan as guest
6. Direct plan purchase
7. Skip the plan page for paid users
8. .... Let's start now with a subscription
9. Activate the WC subscription and subscribe a user to a normal monthly subscription
10. Assign the subscription with a pricing plan
11. Try submitting a listing by the subscribed user and the specific plan
12. Purchase the subscription plan by another user and let check the auto recurrence and listings status and expiration
13. Try a daily recurring plan and a listing's expiration
14. Check the email notifications on every event
15. Plan allowance validation
16. Multiple activated orders with a single package plan
