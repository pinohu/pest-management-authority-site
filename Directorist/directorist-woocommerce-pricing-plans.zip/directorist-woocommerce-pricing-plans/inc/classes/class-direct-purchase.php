<?php
defined('ABSPATH') || die('Direct access is not allowed.');
/**
 * @since 1.7.4
 * @package Directorist
 */
if (!class_exists('Directorist_Direct_Purchase')) :

    class Directorist_Direct_Purchase
    {
        public function __construct()
        {
           add_action('template_redirect', array($this, 'process_direct_purchase'));
           
        }

       public function process_direct_purchase(){
        $plan_id = !empty( $_GET['plan'] ) ? $_GET['plan'] : '';
        if( $plan_id ){
            WC()->cart->empty_cart();
            WC()->session->set('cart', array());
            WC()->cart->add_to_cart( directoirst_wc_plan_auto_renewal( $plan_id ) ? directoirst_wc_plan_auto_renewal( $plan_id ) : $plan_id );
        }
    }

    }
endif;