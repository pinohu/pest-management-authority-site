<?php
/**
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */

namespace Directorist_Job_Manager;

class Form_Handler {

	protected static $instance = null;

	public function __construct() {}

	public static function instance() {
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	public function submit_data_process() {
		if ( isset( $_POST['listing_id'] ) ) {

			if ( 'publish' == get_post_status( $_POST['listing_id'] ) ) {

				$mail_sent = Mail_Processor::instance()->setup( $_POST )->send();

				if ( $mail_sent ) {
					wp_send_json_success( array( 'message' => 'Your application was successfully submitted!' ) );
				} else {
					wp_send_json_error( array( 'message' => 'Oops! Your application was not submitted.' ) );
				}

			} else {
				wp_send_json_error( array( 'message' => 'Oops! Your application was not submitted.' ) );
			}

		} else {
			wp_send_json_error( array( 'message' => 'Oops! Your application was not submitted.' ) );
		}
	}
}