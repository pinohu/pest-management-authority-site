
<?php
/**
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$dirjob_salary = get_post_meta( get_the_ID(), '_dirjob_salary', true );

$dirjob_salary = self::get_salary_range( $dirjob_salary );
if ( ! $dirjob_salary ) {
	return;
}
?>

<div class="directorist-info-item directorist-info-item-dirjob_salary">

	<div class="directorist-info-item__value">
		<span class="directorist-info-item__label-icon"><?php directorist_icon( 'las la-money-bill-wave' );?></span>
		<?php echo esc_html( $dirjob_salary ); ?>
	</div>

</div>