<?php
/**
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */

use Directorist_Job_Manager\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$dirjob_open_position = get_post_meta( get_the_ID(), '_dirjob_open_position', true );
if ( ! $dirjob_open_position ) {
	return;
}

$label_placement = Helper::open_position_label_placement( get_the_ID() );
$label           = isset( $data['label'] ) ? $data['label'] : '';
?>

<div class="directorist-info-item directorist-info-item-dirjob_open_position">

	<div class="directorist-info-item__value">
		<span class="directorist-info-item__label-icon"><?php directorist_icon( 'las la-user-check' );?></span>

		<?php if ( 'after' == $label_placement ) {
			printf( '%s %s', $dirjob_open_position, $label );
		} else {
			printf( '%s %s', $label, $dirjob_open_position );
		}?>

	</div>

</div>
