<?php
/**
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */

use Directorist_Job_Manager\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$dirjob_job_type = get_post_meta( get_the_ID(), '_dirjob_job_type', true );
if ( ! $dirjob_job_type ) {
	return;
}
?>

<div class="directorist-info-item directorist-info-item-dirjob_job_type">

	<div class="directorist-info-item__value"> 
		<span class="directorist-info-item__label-icon"><?php directorist_icon( 'las la-briefcase' );?></span> 
		<?php echo esc_html( $dirjob_job_type ); ?>
	</div>

</div>