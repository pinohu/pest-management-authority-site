<?php
/**
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */

use Directorist_Job_Manager\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$dirjob_deadline = get_post_meta( get_the_ID(), '_dirjob_deadline', true );
if ( ! $dirjob_deadline ) {
	return;
}
?>

<div class="directorist-info-item directorist-info-item-dirjob_deadline">

	<div class="directorist-info-item__value">
		<span class="directorist-info-item__label-icon"><?php directorist_icon( 'las la-clock' );?></span>
		<?php echo Helper::get_date_by_wp_format( $dirjob_deadline ); ?>
	</div>

</div>