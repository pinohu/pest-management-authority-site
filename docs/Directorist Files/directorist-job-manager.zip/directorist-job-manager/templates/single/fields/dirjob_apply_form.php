<?php
/**
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */

use Directorist_Job_Manager\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$dirjob_apply_form = get_post_meta( get_the_ID(), '_dirjob_apply_form', true );
if ( ! $dirjob_apply_form ) {
	return;
}
?>

<div class="directorist-info-item directorist-info-item-dirjob_apply_form">
	<?php echo Helper::get_apply_now_button_html( get_the_ID(), $args ); ?>
</div>