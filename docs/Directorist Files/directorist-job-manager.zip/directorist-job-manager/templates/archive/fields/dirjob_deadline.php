<?php
/**
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */

use Directorist_Job_Manager\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<li class="directorist-listing-card-job-type">
	<?php directorist_icon( $icon );?>
	<span class="directorist-listing-single__info--list__label"><?php $listings->print_label( $label );?></span>
	<span class="directorist-listing-single__info--list__deadline"><?php echo esc_html( Helper::get_date_by_wp_format( $value ) ); ?></span>
</li>
