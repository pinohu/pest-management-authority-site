<?php
/**
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */

use Directorist_Job_Manager\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( ! Helper::get_salary_range( $value ) ) {
	return;
}
?>

<li class="directorist-listing-card-job-type">
	<?php directorist_icon( $icon );?>
	<span class="directorist-listing-single__info--list__label"><?php $listings->print_label( $label );?></span>
	<?php echo Helper::get_salary_range( $value ); ?>
</li>