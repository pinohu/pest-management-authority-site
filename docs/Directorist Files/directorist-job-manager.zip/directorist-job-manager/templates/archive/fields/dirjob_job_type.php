<?php
/**
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<li class="directorist-listing-card-job-type">
	<?php directorist_icon( $icon );?>
	<span class="directorist-listing-single__info--list__label"><?php $listings->print_label( $label );?></span>
	<?php echo esc_html( $value ); ?>
</li>
