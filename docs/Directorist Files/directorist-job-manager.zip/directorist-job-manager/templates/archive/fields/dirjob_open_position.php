<?php
/**
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */

use Directorist_Job_Manager\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$label_placement = Helper::open_position_label_placement( get_the_ID() );
?>

<li class="directorist-listing-card-job-type">

	<?php directorist_icon( $icon );?>

	<?php if ( 'before' == $label_placement ): ?>
		<?php printf( '<span class="directorist-listing-single__info--list__label">%s</span> %s', esc_html( $label ), esc_html( $value ) );?>
	<?php else: ?>
		<?php printf( '<span class="directorist-listing-single__info--list__label">%s</span> %s', esc_html( $value ), esc_html( $label ) );?>
	<?php endif;?>

</li>
