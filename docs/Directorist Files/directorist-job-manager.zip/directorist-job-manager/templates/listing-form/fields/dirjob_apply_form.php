<?php
/**
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */

use Directorist_Job_Manager\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$form_fields = ( isset( $data['value'] ) && is_array( $data['value'] ) ) ? $data['value'] : array();
wp_enqueue_script( 'jquery-ui-sortable' );
?>

<div class="directorist-form-group directorist-custom-form-builder">

	<?php Helper::field_label_template( $data );?>

	<div class='repeater'>

		<div data-repeater-list class="group-a directorist-apply-form-draggable directorist-form-group" id="dirjob_apply_form_sortable_container">
			<?php Helper::get_template( 'listing-form/fields/dirjob_apply_form_fields', array( 'form_fields' => $form_fields ) );?>
		</div>

		<div class="directorist-form-group directorist-form-title-field">
			<input data-repeater-create type="button" value="Add" class="directorist-form-element" id="addNewFormField" />
		</div>

	</div>
</div>