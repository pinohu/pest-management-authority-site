
	<?php if ( isset( $form_fields ) && is_array( $form_fields ) ):?>

		<?php foreach ( $form_fields as $id => $field ): ?>

			<div data-repeater-item class="directorist-apply-form-item dirjob_apply_form_field_wrapper" draggable="true" id="FormField-<?php echo $id; ?>">
				<div class="directorist-apply-form-input">
					<div class="directorist-form-group directorist-form-title-field">
						<select name="dirjob_apply_form[<?php echo $id; ?>][selectfield-type]" class="directorist-form-element selectfield-type">
							<option value="text" <?php echo selected( $field['selectfield-type'] == 'text' ) ?>>Text</option>
							<option value="textarea" <?php echo selected( $field['selectfield-type'] == 'textarea' ) ?>>Textarea</option>
							<option value="email" <?php echo selected( $field['selectfield-type'] == 'email' ) ?>>Email</option>
							<option value="url" <?php echo selected( $field['selectfield-type'] == 'url' ) ?>>URL</option>
							<option value="number" <?php echo selected( $field['selectfield-type'] == 'number' ) ?>>Number</option>
							<option value="file" <?php echo selected( $field['selectfield-type'] == 'file' ) ?>>File</option>
						</select>
					</div>
					<div class="directorist-form-group directorist-form-label-field">
						<input type="text" name="dirjob_apply_form[<?php echo $id; ?>][text-label]" class="directorist-form-element text-label" value="<?php echo $field['text-label'] ?>" placeholder="Label">
					</div>
					<div class="directorist-form-group directorist-form-placeholder-field">
						<input type="text" name="dirjob_apply_form[<?php echo $id; ?>][text-placeholder]" class="directorist-form-element text-placeholder" value="<?php echo $field['text-placeholder'] ?>" placeholder="Placeholder">
					</div>
				</div>
				<div class="directorist-apply-form-action">
					<div class="directorist-checkbox">
						<input type="checkbox" id="dirjob_apply_form[<?php echo $id; ?>][required]" name="dirjob_apply_form[<?php echo $id; ?>][required]" value="yes" <?php echo ( isset( $field['required'] ) && 'yes' == $field['required'] ? 'checked' : '' );?> class="required">
						<label for="dirjob_apply_form[<?php echo $id; ?>][required]" class="directorist-checkbox__label">Required</label>
					</div>
					<span class="directorist-apply-form-drag">
						<?php directorist_icon( 'las la-arrows-alt' );?>
					</span>
					<button data-repeater-delete data-id="<?php echo $id; ?>" type="button" class="directorist-apply-form-delete directorist-form-element removeFormFieldField">
						<?php directorist_icon( 'las la-trash' );?>
					</button>
				</div>
			</div>

		<?php endforeach;?>

	<?php else: ?>

		<div data-repeater-item class="directorist-apply-form-item directorist-apply-form-draggable dirjob_apply_form_field_wrapper" draggable="true" id="FormField-<?php echo $id; ?>">
			<div class="directorist-apply-form-input">
				<div class="directorist-form-group directorist-form-title-field">
					<select name="dirjob_apply_form[<?php echo $id; ?>][selectfield-type]" class="directorist-form-element">
						<option value="text">Text</option>
						<option value="textarea">Textarea</option>
						<option value="email">Email</option>
						<option value="url">URL</option>
						<option value="number">Number</option>
						<option value="file">File</option>
					</select>
				</div>
				<div class="directorist-form-group directorist-form-label-field">
					<input type="text" name="dirjob_apply_form[<?php echo $id; ?>][text-label]" class="directorist-form-element" value="" placeholder="Label">
				</div>
				<div class="directorist-form-group directorist-form-placeholder-field">
					<input type="text" name="dirjob_apply_form[<?php echo $id; ?>][text-placeholder]" class="directorist-form-element" value="" placeholder="Placeholder">
				</div>
			</div>
			<div class="directorist-apply-form-action">
				<div class="directorist-checkbox">
					<input type="checkbox" id="dirjob_apply_form[<?php echo $id; ?>][required]" name="dirjob_apply_form[<?php echo $id; ?>][required]" value="Yes">
					<label for="dirjob_apply_form[<?php echo $id; ?>][required]" class="directorist-checkbox__label">Required</label>
				</div>
				<span class="directorist-apply-form-drag">
					<?php directorist_icon( 'las la-arrows-alt' );?>
				</span>
				<button data-repeater-delete data-id="<?php echo $id; ?>" type="button" class="directorist-apply-form-delete directorist-form-element removeFormFieldField">
					<?php directorist_icon( 'las la-trash' );?>
				</button>
			</div>
		</div>

	<?php endif;?>