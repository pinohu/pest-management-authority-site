<?php
namespace DSA\Email;
use DSA\Database\Database;

/**
 * Class Email
 *
 * Handles the email notifications for saved searches.
 */
class Email {
	
    use \DSA\Search_Helper;

    /**
     * Register actions and filters.
     */
    public function register() {
        add_filter( 'cron_schedules', array( $this, 'custom_cron_schedules' ) );
        add_action( 'wp', array( $this, 'schedule_email_events' ) );
        add_action( 'directorist_saved_search_daily_emails', array( $this, 'send_daily_emails' ) );
        add_action( 'directorist_saved_search_weekly_emails', array( $this, 'send_weekly_emails' ) );
        add_action( 'directorist_saved_search_monthly_emails', array( $this, 'send_monthly_emails' ) );

        add_action( 'directorist_delete_expired_saved_searches', array( $this, 'delete_expired_saved_searches' ) );
        //add_action( 'publish_at_biz_dir', array( $this, 'send_email_after_created_listing' ), 10, 2 );
        add_action( 'wp_insert_post', array( $this, 'handle_wp_insert_post' ), 10, 3 );
    }

    public function handle_wp_insert_post( $post_id, $post, $update ) {
        if ( 'at_biz_dir' === $post->post_type && 'publish' === $post->post_status ) {
            $this->send_email_after_created_listing( $post_id, $post );
        }
    }

    /**
     * Get the directory type slug by ID.
     *
     * @param int $id Directory type ID.
     * @return string Directory type slug.
     */
    public function get_directory_type_slug( $id ) {
		$term                   = get_term_by( 'id', $id, ATBDP_TYPE) ;
        $current_directory_type = $term->slug;
        return $current_directory_type;
	}

    public function delete_expired_saved_searches() {
        return Database::delete_expired_saved_searches();
    }
    
    /**
     * Send email after a listing is created.
     *
     * @param int $listing_id Listing ID.
     */
    public function send_email_after_created_listing( $listing_id, $post ) {

        if( 'at_biz_dir' !== $post->post_type ) {
            return;
        }
        
        $results             = Database::get_search_data( '', 'on_create_listing' );
        $directory_type      = get_post_meta( $listing_id, '_directory_type', true );
        $directory_type_slug = $this->get_directory_type_slug( $directory_type );
        $zip_code            = get_post_meta( $listing_id, '_zip', true );
        $address             = get_post_meta( $listing_id, '_address', true );
        $price               = get_post_meta( $listing_id, '_price', true );
        $title               = get_the_title( $listing_id );
        $categories          = get_the_terms( $listing_id, ATBDP_CATEGORY );
        $locations           = get_the_terms( $listing_id, ATBDP_LOCATION );
        $tags                = get_the_terms( $listing_id, ATBDP_TAGS );
        
        foreach ( $results as $user ) {
            
            // Check if directory type matches
            if ( ! empty( $user['directory_type'] ) && $user['directory_type'] != $directory_type_slug ) {
                continue;
            }
            
            // Check if zip code matches
            if ( ! empty( $user['zip_code'] ) && $user['zip_code'] != $zip_code ) {
                continue;
            }

            // Check if address matches
            if ( ! empty( $user['address'] ) && $user['address'] != $address ) {
                continue;
            }
            
            // Check if title matches
            if ( ! empty( $user['title'] ) && $user['title'] != $title ) {
                continue;
            }
            
            // Check if categories match, if user['category'] is not empty
            if ( ! empty( $user['category'] ) && ( empty( $categories ) || ! in_array( $user['category'], wp_list_pluck( $categories, 'term_id' ) ) ) ) {
                // If categories do not match, skip to the next user
                continue;
            }
            
            // Check if locations match, if user['location'] is not empty
            if ( ! empty( $user['location'] ) && ( empty( $locations ) || ! in_array( $user['location'], wp_list_pluck( $locations, 'term_id' ) ) ) ) {
                // If locations do not match, skip to the next user
                continue;
            }

            // Check if tags match, if user['tags'] is not empty
            if ( ! empty( $user['tags'] ) && ( empty( $tags ) || ! in_array( $user['tags'], wp_list_pluck( $tags, 'term_id' ) ) ) ) {
                // If tags do not match, skip to the next user
                continue;
            }

            // Check if price is within the user's min and max price range
            if ( ! empty( $user['min_price'] ) && $user['min_price'] != 0 && $price < $user['min_price'] ) {
                continue;
            }

            if ( ! empty( $user['max_price'] ) && $user['max_price'] != 0 && $price > $user['max_price'] ) {
                continue;
            }

            $this->send_email( $user );
        }
    }

    /**
     * Send email to the user.
     *
     * @param array $user User data.
     */
    public function send_email( $user ) {
        $site_name  = get_option( 'blogname' );
        $email_from = get_directorist_option( 'email_from_email' );
        $to         = $user['email'] ?? '';
        $subject    = get_directorist_option( 'search_alert_subject', 'Your Saved Search is Available Now!' );
        $message    = $this->replace_in_content( get_directorist_option( 'search_alert_body', 'Hello,
        We are excited to inform you that a listing matching your saved search criteria is now available on ==SITE_NAME==.
        
        Click here to view the available listings: ==LISTINGS_URL==

        Thank you for using ==SITE_NAME==! We hope you find exactly what you are looking for.

        Best regards,
        ==SITE_NAME== Team' ), $user );
        $body       = atbdp_email_html( $subject, $message );
        $headers    = "From: {$site_name} <{$email_from}>\r\n";

        ATBDP()->email->send_mail( $to, $subject, $body, $headers );
    }

    /**
     * Replace placeholders in email content with actual data.
     *
     * @param string $content Email content.
     * @param array $data Data to replace in content.
     * @return string Modified email content.
     */
    public function replace_in_content( $content, $data ) {
        $site_name    = get_option( 'blogname' );
        $search_url   = $this->get_search_url( $data );
        $find_replace = array(
            '==LISTINGS_URL==' => sprintf( '<a href="%s">%s</a>', $search_url, __( 'Listings URL', 'directorist-search-alert' ) ),
            '==SITE_NAME=='    => $site_name,
        );

        return nl2br( strtr( $content, $find_replace ) );
    }

    /**
     * Add custom cron schedules.
     *
     * @param array $schedules Existing schedules.
     * @return array Modified schedules.
     */
    public function custom_cron_schedules( $schedules ) {
        $schedules['monthly'] = array(
            'interval' => 2592000, // 30 days in seconds
            'display'  => __('Once Monthly'),
        );
        return $schedules;
    }

    /**
     * Schedule email events.
     */
    public function schedule_email_events() {
        if ( ! wp_next_scheduled( 'directorist_saved_search_daily_emails' ) ) {
            wp_schedule_event( time(), 'daily', 'directorist_saved_search_daily_emails' );
        }
        if ( ! wp_next_scheduled( 'directorist_saved_search_weekly_emails' ) ) {
            wp_schedule_event( time(), 'weekly', 'directorist_saved_search_weekly_emails' );
        }
        if ( ! wp_next_scheduled( 'directorist_saved_search_monthly_emails' ) ) {
            wp_schedule_event( time(), 'monthly', 'directorist_saved_search_monthly_emails' );
        }

        // Get expiration days
        $expiration_days = dsa_get_saved_search_expiration_days();

        // Schedule the auto-deletion of expired saved searches only if expiration days is greater than 0
        if ( $expiration_days > 0 ) {
            if ( ! wp_next_scheduled( 'directorist_delete_expired_saved_searches' ) ) {
                wp_schedule_event( time(), 'daily', 'directorist_delete_expired_saved_searches' );
            }
        } else {
            // If expiration days is 0, clear any existing scheduled event
            wp_clear_scheduled_hook( 'directorist_delete_expired_saved_searches' );
        }
    }

    /**
     * Send notification emails based on the specified interval.
     *
     * @param string $interval Interval type (daily, weekly, monthly).
     */
    public function send_notification_emails( $interval ) {
        $results = Database::get_search_data( '', $interval );

        foreach ( $results as $user ) {
            $count = $this->new_listings_count( $user ) ?? 0;

            if( 0 < $count ) {
                $this->send_email( $user );
            }

        }
    }

    /**
     * Send daily notification emails.
     */
    public function send_daily_emails() {
        $this->send_notification_emails( 'daily' );
    }

    /**
     * Send weekly notification emails.
     */
    public function send_weekly_emails() {
        $this->send_notification_emails( 'weekly' );
    }

    /**
     * Send monthly notification emails.
     */
    public function send_monthly_emails() {
        $this->send_notification_emails( 'monthly' );
    }
}