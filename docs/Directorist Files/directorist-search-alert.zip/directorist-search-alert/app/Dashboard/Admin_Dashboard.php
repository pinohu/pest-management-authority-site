<?php
namespace DSA\Dashboard;
use DSA\Database\Database;
class Admin_Dashboard extends Dashboard{
	
    public function register() {
        add_action( 'admin_menu', array( $this, 'status_menu' ), 60 );
	}

    public function status_menu() {
        add_submenu_page( 'edit.php?post_type=at_biz_dir', __( 'Saved Search', 'directorist-search-alert' ), __( 'Saved Search', 'directorist-search-alert' ) , 'manage_options', 'saved-search', array( $this, 'saved_search' ) );
    }

    public function get_user_type( $email ) {
        // Check if the email exists
        $user_id = email_exists( $email );

        if ( $user_id ) {
            // Email already exists
            return esc_html__( 'Registered', 'directorist-search-alert' );
        } else {
            // Email is not registered
            return esc_html__( 'Guest', 'directorist-search-alert' );
        }
    }

    public function saved_search() { 
        $get_saved_values = Database::get_search_data();
        
        $args = array(
            'values'    => $get_saved_values,
            'dashboard' => $this,
        );
        return dsa_load_template( 'dashboard/admin-dashboard', $args );
    }

}
