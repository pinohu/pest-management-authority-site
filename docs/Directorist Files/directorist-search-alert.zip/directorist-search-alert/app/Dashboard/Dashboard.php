<?php
namespace DSA\Dashboard;
use Directorist\Helper;
class Dashboard {
	
    // Function to get category name from ID
    public function get_category_name( $category_id ) {
        
        $category_name = '';
        if ( $category_id ) {
            $category = get_term( $category_id, ATBDP_CATEGORY );
            if ( $category && ! is_wp_error( $category ) ) {
                $category_name = $category->name;
            }
        }
        return $category_name;
    }

    // Function to get location name from ID
    public function get_location_name( $location_id ) {
        $location_name = '';
        if ( $location_id ) {
            $location = get_term( $location_id, ATBDP_LOCATION );
            if ( $location && ! is_wp_error( $location ) ) {
                $location_name = $location->name;
            }
        }
        return $location_name;
    }

    // Function to get tag names from IDs
    public function get_tag_names( $tag_ids ) {
        $tag_names = array();
        if ( ! empty( $tag_ids ) ) {
            $tags = get_terms(array(
                'taxonomy' => ATBDP_TAGS,
                'include' => $tag_ids,
            ));
            if ( ! is_wp_error( $tags ) ) {
                foreach ( $tags as $tag ) {
                    $tag_names[] = $tag->name;
                }
            }
        }
        return $tag_names;
    }

    public function get_price_range( $min_price = '', $max_price = '' ) {
        $min_price   = sanitize_text_field( $min_price ?? '' );
        $max_price   = sanitize_text_field( $max_price ?? '' );
        $price_range = '';
        if ( ! empty( $min_price ) && $min_price != 0 && ! empty( $max_price ) && $max_price != 0 )  {
            $price_range = Helper::formatted_price( $min_price ) . ' - ' . Helper::formatted_price( $max_price );
        } elseif ( ! empty( $min_price ) && $min_price != 0 ) {
            $price_range = Helper::formatted_price( $min_price );
        } elseif ( ! empty( $max_price ) && $max_price != 0 ) {
            $price_range = Helper::formatted_price( $max_price );
        }

        return $price_range;
    }

    public function get_search_filters( $q, $in_cat, $tag_names, $in_loc, $address, $zip_code, $price_range ) {
        $search_filters        = array_filter( [ $q, $in_cat, implode( ' , ', $tag_names ), $in_loc, $address, $zip_code, $price_range ] );
        $search_filters_string = implode( ' / ', $search_filters );

        return $search_filters_string;
    }

    public function get_date( $date ) {
        $date           = sanitize_text_field( $date ?? '' );
        $timestamp      = strtotime( $date );
        $formatted_date = date( "M d,Y", $timestamp );

        return $formatted_date;
    }

    public function get_notification_status( $status ) {
        $status = sanitize_text_field( $status ?? '' );
        if( 'on_create_listing' == $status ) {
            $status = __( 'When listings match', 'directorist-search-alert' );
        }

        return ucfirst( $status );
    }

}