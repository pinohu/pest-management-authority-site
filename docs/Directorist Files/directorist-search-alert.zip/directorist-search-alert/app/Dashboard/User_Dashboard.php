<?php
namespace DSA\Dashboard;
use DSA\Database\Database;
class User_Dashboard extends Dashboard{
    
	use \DSA\Search_Helper;

    public function register() {
        add_action( "directorist_after_dashboard_navigation", array( $this, "directorist_after_dashboard_navigation" ) );
        add_action( "directorist_after_dashboard_contents", array( $this, "directorist_after_dashboard_contents" ) );
	}

    public function directorist_after_dashboard_navigation() {

        $html = '<li class="directorist-tab__nav__item"><a href="#" class="directorist-booking-nav-link directorist-tab__nav__link" id="saved_search_tab" target="saved_search"><span class="directorist_menuItem-text"><span class="directorist_menuItem-icon">'. directorist_icon( 'las la-calendar-check', false ) .'</span>' . esc_html__('Saved Search', 'directorist-search-alert') . '</span></a></li>';
        
        echo apply_filters( 'atbdp_user_dashboard_saved_search_tab', $html );

    }

    public function directorist_after_dashboard_contents() {
        $current_user     = wp_get_current_user();
        $user_email       = $current_user->user_email;
        $get_saved_values = Database::get_search_data( $user_email );
        
        $args = array(
            'values'     => $get_saved_values,
            'dashboard' => $this,
        );
        return dsa_load_template( 'dashboard/user-dashboard', $args );
    }

}
