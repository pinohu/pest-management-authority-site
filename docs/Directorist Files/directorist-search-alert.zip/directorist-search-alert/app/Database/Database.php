<?php
namespace DSA\Database;
class Database {

    public static function insert_saved_search( $search_name, $user_email, $directory_type, $alert_period, $q, $in_cat, $in_loc, $address, $zip, $min_price, $max_price, $tags_string ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'directorist_saved_search';
    
        $data = array(
            'name'           => $search_name,
            'notification'   => $alert_period,
            'email'          => $user_email,
            'directory_type' => $directory_type,
            'title'          => $q,
            'category'       => $in_cat,
            'location'       => $in_loc,
            'zip_code'       => $zip,
            'min_price'      => $min_price,
            'max_price'      => $max_price,
            'address'        => $address,
            'tags'           => $tags_string,
            'date'           => current_time( 'mysql' ),
        );
    
        $format = array(
            '%s', // Name
            '%s', // Notification
            '%s', // Email
            '%s', // Directory Type
            '%s', // Title
            '%s', // Category
            '%s', // Location
            '%s', // Zip_Code
            '%d', // Min_Price
            '%d', // Max_Price
            '%s', // Address
            '%s', // Tags
            '%s', // Date (no need for format specifier)
        );
    
        $wpdb->insert( $table_name, $data, $format );

        if ($wpdb->insert_id) {
            return $wpdb->insert_id; // Return the inserted record ID
        } else {
            return false; // Handle error appropriately
        }
    }

    public static function update_saved_search( $id, $alert_period, $search_name ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'directorist_saved_search';
        
        $data = array(
            'notification' => $alert_period,
            'name'        => $search_name,
        );
        
        $where = array(
            'id' => $id,
        );
        
        $data_format = array(
            '%s', // Notification
            '%s', // Title
        );
        
        $where_format = array('%d');
        
        return $wpdb->update($table_name, $data, $where, $data_format, $where_format);
    }

    public static function get_search_data( $email = '', $notification = '' ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'directorist_saved_search';
        $query = "SELECT * FROM {$table_name}";

        $conditions = array();
        $params = array();

        if ( ! empty( $email ) ) {
            $conditions[] = "email = %s";
            $params[]     = $email;
        }

        if ( ! empty( $notification ) ) {
            $conditions[] = "notification = %s";
            $params[]     = $notification;
        }

        if ( ! empty( $conditions ) ) {
            $query .= ' WHERE ' . implode( ' AND ', $conditions );
        }

        // If there are parameters, use $wpdb->prepare
        if ( ! empty( $params ) ) {
            $query = $wpdb->prepare( $query, ...$params );
        }

        return $wpdb->get_results( $query, ARRAY_A );
    }

    public static function get_search_data_by_id( $id ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'directorist_saved_search';

        // Fetch the saved search by ID
        $saved_search = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM $table_name WHERE id = %d", 
                $id
            ),
            ARRAY_A,
        );

        return $saved_search;
    }

    public static function deleted_saved_search( $id ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'directorist_saved_search';
    
        $deleted = $wpdb->delete( $table_name, array( 'ID' => $id ), array( '%d' ) );
    
        return ( false !== $deleted );
    }

    public static function delete_expired_saved_searches() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'directorist_saved_search';
    
        // Get the expiration period from Directorist settings
        $expiration_days = dsa_get_saved_search_expiration_days();
        $expiration_time = date( 'Y-m-d H:i:s', strtotime( "-$expiration_days days" ) );
    
        // Get the IDs of expired saved searches
        $expired_ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT ID FROM $table_name WHERE date < %s",
                $expiration_time
            )
        );
    
        // Loop through the expired IDs and delete each one using the existing method
        foreach ( $expired_ids as $id ) {
            self::deleted_saved_search( $id );
        }
    }
    

    public static function check_combined_request_values_in_db( $user_email ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'directorist_saved_search';
        // Initialize an array to hold where conditions
        $conditions = array();
        
        if ( ! empty( $user_email ) ) {
            $conditions[] = $wpdb->prepare("email = %s", $user_email);
        }

        // Check and add conditions for each parameter
        if ( ! empty( $_REQUEST['directory_type'] ) ) {
            $directory_type = sanitize_text_field( $_REQUEST['directory_type'] );
            $conditions[]   = $wpdb->prepare( "directory_type = %s", $directory_type );
        } else {
            $conditions[]   = $wpdb->prepare( "directory_type = %s", '' );
        }

        if ( ! empty( $_REQUEST['q'] ) ) {
            $q            = sanitize_text_field( $_REQUEST['q'] );
            $conditions[] = $wpdb->prepare( "title = %s", $q );
        } else {
            $conditions[] = $wpdb->prepare( "title = %s", '' );
        }
    
        if ( ! empty( $_REQUEST['in_cat'] ) ) {
            $in_cat       = sanitize_text_field( $_REQUEST['in_cat'] );
            $conditions[] = $wpdb->prepare( "category = %d", $in_cat );
        } else {
            $conditions[] = $wpdb->prepare("category = %d", '');
        }
    
    
        if ( ! empty( $_REQUEST['in_loc'] ) ) {
            $in_loc       = sanitize_text_field( $_REQUEST['in_loc'] );
            $conditions[] = $wpdb->prepare( "location = %d", $in_loc );
        } else {
            $conditions[] = $wpdb->prepare("location = %d", '');
        }
    
        if ( ! empty( $_REQUEST['in_tag'] ) ) {
            $in_tag_raw = $_REQUEST['in_tag'];
            if ( is_string( $in_tag_raw ) ) {
                $in_tags = array_map( 'intval', explode( ',', $in_tag_raw ) ); // Split by comma and sanitize
            } elseif ( is_array( $in_tag_raw ) ) {
                $in_tags = array_map( 'intval', $in_tag_raw ); // Already an array, just sanitize
            } else {
                $in_tags = []; // Fallback for unexpected cases
            }
            $tag_conditions = array();
            foreach ( $in_tags as $tag ) {
                $tag_conditions[] = $wpdb->prepare( "FIND_IN_SET(%d, tags)", $tag );
            }
            if (!empty($tag_conditions)) {
                $conditions[] = '(' . implode(' AND ', $tag_conditions) . ')';
            }
        } else {
            $conditions[] = $wpdb->prepare("tags = %s", '');
        }
    
        if ( ! empty( $_REQUEST['price'][0] ) ) {
            $price_0      = floatval( $_REQUEST['price'][0] );
            $conditions[] = $wpdb->prepare( "min_price = %s", $price_0 );
        } else {
            $conditions[] = $wpdb->prepare("min_price = %s", 0);
        }
    
        if ( ! empty( $_REQUEST['price'][1] ) ) {
            $price_1      = floatval( $_REQUEST['price'][1] );
            $conditions[] = $wpdb->prepare( "max_price = %s", $price_1 );
        } else {
            $conditions[] = $wpdb->prepare("max_price = %s", 0);
        }
    
        if ( ! empty( $_REQUEST['address'] ) ) {
            $address      = sanitize_text_field( $_REQUEST['address'] );
            $conditions[] = $wpdb->prepare( "address = %s", $address );
        } else {
            $conditions[] = $wpdb->prepare("address = %s", '');
        }
    
        if ( ! empty( $_REQUEST['zip'] ) ) {
            $zip          = sanitize_text_field( $_REQUEST['zip'] );
            $conditions[] = $wpdb->prepare( "zip_code = %s", $zip );
        } else {
            $conditions[] = $wpdb->prepare("zip_code = %s", '');
        }
    
        // Combine all conditions into a single query
        if ( ! empty( $conditions ) ) {
            $where_clause = implode(' AND ', $conditions);
            $query = "SELECT id FROM $table_name WHERE $where_clause";
            $result = $wpdb->get_var($query);
            return $result ? $result : false; // Return the ID or false if no match is found
        }
    
        // If no conditions are provided, return false
        return false;
    }
    
}
