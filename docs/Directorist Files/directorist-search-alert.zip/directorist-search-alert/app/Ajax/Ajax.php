<?php
namespace DSA\Ajax;
use DSA\Database\Database;
use DSA\Dashboard\Dashboard;
class Ajax {

    public function register() {
        //saved search
        add_action( 'wp_ajax_dsa_saved_search', array( $this, 'saved_search' ) );
		add_action( 'wp_ajax_nopriv_dsa_saved_search', array( $this, 'saved_search' ) );

        //deleted search 
        add_action( 'wp_ajax_dsa_deleted_search', array( $this, 'deleted_search' ) );
		add_action( 'wp_ajax_nopriv_dsa_deleted_search', array( $this, 'deleted_search' ) );

        //edit modal 
        add_action( 'wp_ajax_dsa_edit_modal', array( $this, 'edit_modal' ) );
		add_action( 'wp_ajax_nopriv_dsa_edit_modal', array( $this, 'edit_modal' ) );

        //edit save search
        add_action( 'wp_ajax_dsa_edit_saved_search', array( $this, 'edit_save_search' ) );
		add_action( 'wp_ajax_nopriv_dsa_edit_saved_search', array( $this, 'edit_save_search' ) );
    }

    public function edit_save_search() {
        if ( ! directorist_verify_nonce( 'nonce', 'dsa_ajax_nonce' ) ) {
            wp_send_json_error( __( 'Something went wrong, please try again.', 'directorist-search-alert' ) );
        }

        $search_name  = sanitize_text_field( $_POST['search_name'] ?? '' );
        $user_email   = sanitize_email( $_POST['user_email'] ?? '' );
        $alert_period = sanitize_text_field( $_POST['alert_period'] ?? 'on_create_listing' );
    
        $id             = absint( $_POST['id'] ?? 0 );
        $q              = sanitize_text_field( $_POST['q'] ?? '' );
        $directory_type = sanitize_text_field( $_POST['directory_type'] ?? '' );
        $in_cat         = sanitize_text_field( $_POST['in_cat'] ?? '' );
        $in_loc         = sanitize_text_field( $_POST['in_loc'] ?? '' );
        $address        = sanitize_text_field( $_POST['address'] ?? '' );
        $zip            = sanitize_text_field( $_POST['zip'] ?? '' );
        $tags           = directorist_clean( $_POST['tag'] ?? array() );
        $price          = directorist_clean( $_POST['price'] ?? array() );
    
        $saved = Database::update_saved_search(
            $id,
            $alert_period,
            $search_name,
        );
    
        if ( $saved ) {
            wp_send_json_success( __( 'Updated', 'directorist-search-alert' ) );
        } else {
            wp_send_json_error( __( 'Failed to updated.', 'directorist-search-alert' ) );
        }
    
        wp_die();
    }

    public function edit_modal() {
        if ( ! directorist_verify_nonce( 'nonce', 'dsa_ajax_nonce' ) ) {
            wp_send_json_error( __( 'Something went wrong, please try again.', 'directorist-search-alert' ) );
        }

        if ( ! isset( $_POST['id'] ) ) {
            wp_send_json_error( 'Missing ID.' );
        }
    
        $id           = absint( $_POST['id'] );
        $saved_search = Database::get_search_data_by_id( $id );

        if( $saved_search ) {
            ob_start();
            $args = array(
                'values'          => $saved_search,
                'category_fields' => dsa_get_terms( ATBDP_CATEGORY ),
                'location_fields' => dsa_get_terms( ATBDP_LOCATION ),
                'tag_fields'      => dsa_get_terms( ATBDP_TAGS ),
            );
             dsa_load_template( 'editing-form', $args );
            $modal = ob_get_clean();
            wp_send_json_success( $modal );
        }

        wp_die();
    }

    public function deleted_search() {
        if ( ! directorist_verify_nonce( 'nonce', 'dsa_ajax_nonce' ) ) {
            wp_send_json_error( __( 'Something went wrong, please try again.', 'directorist-search-alert' ) );
        }

        if ( ! isset( $_POST['id'] ) ) {
            wp_send_json_error( 'Missing ID.' );
        }
    
        $id      = absint( $_POST['id'] );
        $deleted = Database::deleted_saved_search( $id );

        if ( $deleted ) {
            wp_send_json_success( array( 'success' => true ) );
        } else {
            wp_send_json_error( 'Failed to delete saved search.' );
        }
    
    }

    public function saved_search() {
        if ( ! directorist_verify_nonce( 'nonce', 'dsa_save_search_form' ) ) {
            wp_send_json_error( __( 'Something went wrong, please try again.', 'directorist-search-alert' ) );
        }
    
        $search_name  = sanitize_text_field( $_POST['search_name'] ?? '' );
        $user_email   = sanitize_email( $_POST['user_email'] ?? '' );
        $alert_period = sanitize_text_field( $_POST['alert_period'] ?? 'on_create_listing' );
    
        $q              = sanitize_text_field( $_POST['q'] ?? '' );
        $directory_type = sanitize_text_field( $_POST['directory_type'] ?? '' );
        $in_cat         = sanitize_text_field( $_POST['in_cat'] ?? '' );
        $in_loc         = sanitize_text_field( $_POST['in_loc'] ?? '' );
        $address        = sanitize_text_field( $_POST['address'] ?? '' );
        $zip            = sanitize_text_field( $_POST['zip'] ?? '' );
        $tags           = directorist_clean( $_POST['tag'] ?? array() );
        $price          = directorist_clean( $_POST['price'] ?? array() );
    
        $min_price   = absint( $price[0] ?? 0 );
        $max_price   = absint( $price[1] ?? 0 );
        $tags_string = implode(',', $tags);

        if ( ! email_exists( $user_email ) ) {
            $random_password = wp_generate_password( 12, false );
            $user_id         = wp_create_user( $user_email, $random_password, $user_email );
    
            if ( is_wp_error( $user_id ) ) {
                wp_send_json_error( __( 'Failed to register user.', 'directorist-search-alert' ) );
            }
    
            // Optionally set user role, meta, etc.
            wp_update_user( array(
                'ID' => $user_id,
                'role' => 'subscriber', // Set role or other fields as needed
            ) );
        }
    
        $saved = Database::insert_saved_search(
            $search_name,
            $user_email,
            $directory_type,
            $alert_period,
            $q,
            $in_cat,
            $in_loc,
            $address,
            $zip,
            $min_price,
            $max_price,
            $tags_string
        );
        
        if ( $saved ) {
            ob_start();
            ?>
                <span class="dsa-save-search dsa-saved-search" data-id="<?php echo esc_attr( $saved ?? 0 ) ?>"><?php directorist_icon( 'fas fa-heart', true ) . esc_html_e( 'Search Saved', 'directorist-search-alert' ); ?></span>
            <?php
            $saved_search_markup = ob_get_clean();
            wp_send_json_success( $saved_search_markup );
        } else {
            wp_send_json_error( __( 'Failed to insert.', 'directorist-search-alert' ) );
        }
    
        wp_die();
    }
    
}