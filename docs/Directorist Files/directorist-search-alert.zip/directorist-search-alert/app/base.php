<?php
defined( 'ABSPATH' ) || exit;

use DSA\Setup\Settings;
use DSA\Setup\Enqueue;
use DSA\Dashboard\Dashboard;
use DSA\Dashboard\User_Dashboard;
use DSA\Dashboard\Admin_Dashboard;
use DSA\Ajax\Ajax;
use DSA\Email\Email;

/**
 * Directorist_Search_Alert class
 *
 * Main plugin class that initializes the plugin and manages its lifecycle.
 */
final class Directorist_Search_Alert {

	/**
	 * Instance
	 *
	 * @return Directorist_Search_Alert
	 * @since 1.0
	 */
	private static $instance;

	 /**
     * Get the singleton instance of the class.
     *
     * @return Directorist_Search_Alert
     */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();

			add_action( 'init', array( self::$instance, 'load_textdomain' ) );
			add_filter( 'directorist_listings_header_title', array( self::$instance, 'directorist_listings_header_title' ), 10, 1 );

		}

		return self::$instance;
	}

	/**
     * Create the database table for storing saved searches.
     */
	public static function create_database_table() {
		global $wpdb;
	
		// Set the table name
		$table_name = $wpdb->prefix . 'directorist_saved_search';
	
		// SQL statement to create the table if it doesn't already exist
		$charset_collate = $wpdb->get_charset_collate();
	
		$sql = "CREATE TABLE IF NOT EXISTS $table_name (
			ID INT NOT NULL AUTO_INCREMENT,
			name VARCHAR(255) NOT NULL,
			notification VARCHAR(50) NOT NULL,
			email VARCHAR(255) NOT NULL,
			directory_type VARCHAR(255),
			title VARCHAR(255),
			category VARCHAR(100),
			location VARCHAR(255),
			zip_code VARCHAR(50),
			address VARCHAR(255),
			min_price VARCHAR(255),
			max_price VARCHAR(255),
			tags VARCHAR(255),
			date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (ID)
		) $charset_collate;";
	
		// Include the upgrade script to handle the table creation
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );
	}

	 /**
     * Clear the scheduled hooks for sending email notifications.
     */
	public static function clear_scheduled_hook() {
		wp_clear_scheduled_hook( 'directorist_saved_search_daily_emails' );
		wp_clear_scheduled_hook( 'directorist_saved_search_weekly_emails' );
		wp_clear_scheduled_hook( 'directorist_saved_search_monthly_emails' );
		wp_clear_scheduled_hook( 'directorist_delete_expired_saved_searches' );
	}

	/**
     * Modify the listings header title to include the search result template.
     *
     * @param string $args The current header title.
     * @return string Modified header title.
     */
	public function directorist_listings_header_title( $args ) {

		// Check if we've already added the content to avoid duplicate entries
		$content_added = false;

		// If content is already added, return the original args
		if ( $content_added ) {
			return $args;
		}

		$guest_alert = get_directorist_option( 'guest_alert', false );
		if( ! is_user_logged_in() && empty( $guest_alert ) ) {
            return $args;
        }

		if( ! empty( $_REQUEST['q'] ) || ! empty( $_REQUEST['in_cat'] ) || ! empty( $_REQUEST['in_loc'] ) || ! empty( $_REQUEST['in_tag'] ) || ! empty( $_REQUEST['price'][0] ) || ! empty( $_REQUEST['price'][1] ) || ! empty( $_REQUEST['address'] ) || ! empty( $_REQUEST['zip'] ) ) {
			$current_user = wp_get_current_user();
			$user_email   = is_user_logged_in() ? $current_user->user_email : '';
			ob_start();
				dsa_load_template( 'search-result', array( 'user_email' => $user_email ) );
			$args .= ob_get_clean();
			// Set the flag to true after appending the content
			$content_added = true;
		}
		return $args;
	}

	/**
     * Load plugin text domain for translations.
     *
     * @since 1.0.0
     */
	public function load_textdomain() {
		// Determine the current locale
		$locale = determine_locale();
		// Allow filters to modify the locale
		$locale = apply_filters( 'plugin_locale', $locale, 'directorist-search-alert' );
		load_textdomain( 'directorist-search-alert', WP_LANG_DIR . '/plugins/directorist-search-alert-' . $locale . '.mo' );

		load_plugin_textdomain( 'directorist-search-alert', false, DSA_LANG_PATH );
	}

	/**
     * Constructor
     *
     * Initialize the plugin by including necessary files and registering services.
     *
     * @return void
     */
	public function __construct() {
		$this->includes();
		$this->register_services();
	}

	/**
     * Include necessary plugin files.
     *
     * @return void
     */
	public function includes() {
		$files = array(
			'helpers/trait-search-helper',
			'app/Setup/Settings',
			'app/Setup/Enqueue',
			'app/Database/Database',
			'app/Ajax/Ajax',
			'app/Dashboard/Dashboard',
			'app/Dashboard/User_Dashboard',
			'app/Dashboard/Admin_Dashboard',
			'app/Email/Email',
		);

		foreach ( $files as $file ) {
			$file_path = DSA_PLUGIN_PATH . "{$file}.php";
			if ( ! file_exists( $file_path ) ) {
				continue;
			}
			include $file_path;
		}
	}

	/**
     * Get the list of service classes to be registered.
     *
     * @return array List of service class names.
     */
	public function get_services() {
		return array(
			Settings::class,
			Enqueue::class,
            Dashboard::class,
            User_Dashboard::class,
            Admin_Dashboard::class,
            Ajax::class,
            Email::class,
		);
	}

	/**
     * Register services by instantiating and calling their register method.
     *
     * @return void
     */
	public function register_services() {
		$services = $this->get_services();

		if ( ! count( $services ) ) {
			return;
		}
		foreach ( $services as $class_name ) {
			if ( class_exists( $class_name ) ) {
				if ( method_exists( $class_name, 'register' ) ) {
					$service = new $class_name();
					$service->register();
				}
			}
		}
	}
}

/**
 * Initialize the Directorist_Search_Alert plugin.
 *
 * @return Directorist_Search_Alert
 */
function Directorist_Search_Alert() {
	return Directorist_Search_Alert::instance();
}

/**
 * Check if a plugin is active.
 *
 * @param string $plugin Plugin path.
 * @return bool True if the plugin is active, false otherwise.
 */
if ( ! function_exists( 'directorist_is_plugin_active' ) ) {
	function directorist_is_plugin_active( $plugin ) {
		return in_array( $plugin, (array) get_option( 'active_plugins', array() ), true ) || directorist_is_plugin_active_for_network( $plugin );
	}
}

/**
 * Check if a plugin is active for the network.
 *
 * @param string $plugin Plugin path.
 * @return bool True if the plugin is active for the network, false otherwise.
 */
if ( ! function_exists( 'directorist_is_plugin_active_for_network' ) ) {
	function directorist_is_plugin_active_for_network( $plugin ) {
		if ( ! is_multisite() ) {
			return false;
		}
				
		$plugins = get_site_option( 'active_sitewide_plugins' );
		if ( isset( $plugins[ $plugin ] ) ) {
				return true;
		}

		return false;
	}
}

// Initialize the plugin if the Directorist base plugin is active.
if (  directorist_is_plugin_active( 'directorist/directorist-base.php' ) ) {
	Directorist_Search_Alert();
}