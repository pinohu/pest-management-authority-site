<?php
namespace DSA\Setup;

class Settings {

    public function register() {
        add_filter( 'atbdp_email_templates_settings_sections', array( $this, 'email_template_section' ) );
        add_filter( 'atbdp_listing_type_settings_field_list', array( $this, 'setting_fields' ) );
        add_filter( 'atbdp_extension_settings_submenu', array( $this, 'search_alert_menu' ) );
    }

    public function search_alert_menu( $submenu ) {
        $submenu['search_alert_submenu'] = [
            'label' => __('Search Alert', 'directorist-search-alert'),
                    'icon' => '<i class="fa fa-bell"></i>',
                    'sections' => apply_filters( 'atbdp_search_alert_settings_controls', [
                        'general_section' => [
                            'title'       => '',
                            'description' => __('You can Customize the Search Alert here', 'directorist-search-alert'),
                            'fields'      =>  [ 'guest_alert', 'delete_saved_searches_after' ],
                        ],
                        
                    ] ),
        ];

        return $submenu;
    }

    public function setting_fields( $fields ) {
        $fields['guest_alert'] = [
            'label'             => __('Guest Alert', 'directorist-search-alert'),
            'type'              => 'toggle',
            'value'             => false,
            'description'       => __('Enable search alerts for users.', 'directorist-search-alert'),
        ];
        $fields['delete_saved_searches_after'] = array(
            'type'        => 'number',
            'label'       => __('Auto-Delete Saved Searches', 'directorist-search-alert'),
            'value'       => 30, // Default value, you can adjust as needed
            'description' => __('Automatically delete saved searches after X days. Enter 0 to keep them forever', 'directorist-search-alert'),
        );
        $fields['search_alert_subject'] = array(
            'type'           => 'text',
            'label'          => __('Email Subject', 'directorist-search-alert'),
            'value'          => __('Your Saved Search is Available Now!', 'directorist-search-alert'),
        );
        $fields['search_alert_body'] = array(
            'type'           => 'textarea',
            'label'          => __('Email Body', 'directorist-search-alert'),
            'value'          => __("
                Hello,
                We are excited to inform you that a listing matching your saved search criteria is now available on ==SITE_NAME==.
                
                Click here to view the available listings: ==LISTINGS_URL==

                Thank you for using ==SITE_NAME==! We hope you find exactly what you are looking for.

                Best regards,
                ==SITE_NAME== Team
            ", 'directorist-search-alert'),
        );

        return $fields;
    }

    public function email_template_section( $section ) {
        $section['search_alert'] = array(
            'title'       => __('For Search Alert', 'directorist-search-alert'),
            'description' => '',
            'fields'      => [ 
                'search_alert_subject', 'search_alert_body'
            ],
        );

        return $section;
    }
}
