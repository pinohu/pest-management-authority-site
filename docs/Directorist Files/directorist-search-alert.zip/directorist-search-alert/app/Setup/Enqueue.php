<?php
namespace DSA\Setup;

class Enqueue {
	/**
	 * Register
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'wp_enqueue_scripts', array( $this, 'load_frontend_scripts' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'load_admin_scripts' ) );
	}

	/**
	 * Load Frontend Scripts
	 *
	 * @return void
	 */
	public function load_frontend_scripts() {

		wp_enqueue_script('dsa-main-js',
		 DSA_PLUGIN_DIR_URI . 'assets/js/main.js',
		 array('jquery', 'directorist-select2-script', 'directorist-sweetalert'),
		 DSA_VERSION,
		 true
		);

		wp_enqueue_style('dsa-main-css',
		DSA_PLUGIN_DIR_URI . 'assets/css/style.css',
		array('directorist-select2-style'),
		DSA_VERSION
		);

		wp_localize_script(
			'dsa-main-js',
			'dsa',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'ajax_nonce' => wp_create_nonce( 'dsa_ajax_nonce' )
			)
		);
	}


	public function load_admin_scripts() {
		
		if ( isset( $_GET['page'] ) && $_GET['page'] === 'saved-search' ) {
			wp_enqueue_style( 'directorist-sweetalert-style' );
			wp_enqueue_style('dsa-admin-css',
			DSA_PLUGIN_DIR_URI . 'admin/css/style.css',
			DSA_VERSION,
			);

			wp_enqueue_style('dsa-admin-css-two',
			DSA_PLUGIN_DIR_URI . 'assets/css/style.css',
			array('directorist-select2-style'),
			DSA_VERSION
			);

			wp_enqueue_script('dsa-admin-js',
			DSA_PLUGIN_DIR_URI . 'admin/js/admin.js',
			array( 'jquery', 'directorist-sweetalert' ),
			DSA_VERSION,
			);

			wp_enqueue_script('dsa-main-js',
			DSA_PLUGIN_DIR_URI . 'assets/js/main.js',
			array('jquery', 'directorist-select2-script', 'directorist-sweetalert'),
			DSA_VERSION,
			true
			);

			wp_localize_script(
				'dsa-main-js',
				'dsa',
				array(
					'ajax_url' => admin_url( 'admin-ajax.php' ),
					'ajax_nonce' => wp_create_nonce( 'dsa_ajax_nonce' )
				)
			);
		}

	}



	/**
	 * Register Scripts
	 *
	 * @return void
	 */
	public function register_scripts( array $scripts ) {
		foreach ( $scripts as $id => $args ) {

			if ( ! empty( $args['desable'] ) ) {
				continue;
			}

			$defaults = array(
				'src'       => '',
				'dep'       => array(),
				'ver'       => false,
				'in_footer' => true,
			);

			$args = array_merge( $defaults, $args );
			wp_register_script( $id, $args['src'], $args['dep'], $args['ver'], $args['in_footer'] );
		}
	}
}
