<?php 
namespace DSA;

if ( ! defined( 'ABSPATH' ) ) exit;
trait Search_Helper {
    public function new_listings_count( $data ) {
        $date_query = array(
            array(
                'after'     => $data['date'],
                'inclusive' => true,
            ),
        );

        $args = array(
            'post_type'      => ATBDP_POST_TYPE,
            'post_status'    => 'publish',
            'date_query'     => $date_query,
        );

        if ( ! empty( $data['title'] ) ) {
            $args['s'] = sanitize_text_field( wp_unslash( $data['title'] ) );
        }

        $tax_queries = array();

        if ( ! empty( $data['category'] ) ) {
            $tax_queries[] = array(
                'taxonomy'         => ATBDP_CATEGORY,
                'field'            => 'term_id',
                'terms'            => wp_parse_id_list( wp_unslash( $data['category'] ) ),
                'include_children' => true,
            );
        }

        if ( ! empty( $data['location'] ) ) {
            $tax_queries[] = array(
                'taxonomy'         => ATBDP_LOCATION,
                'field'            => 'term_id',
                'terms'            => wp_parse_id_list( wp_unslash( $data['location'] ) ),
                'include_children' => true,
            );
        }

        if ( ! empty( $data['tags'] ) ) {
            $tax_queries[] = array(
                'taxonomy' => ATBDP_TAGS,
                'field'    => 'term_id',
                'terms'    => wp_parse_id_list( wp_unslash( $data['tags'] ) ),
            );
        }

        if ( count( $tax_queries ) ) {
            $args['tax_query'] = array_merge( array( 'relation' => 'AND' ), $tax_queries );
        }

        $meta_queries = array();
        $price = array( 
            0 => $data['min_price'],
            1 => $data['max_price'],
        );
        if ( ! empty( $data['min_price'] ) || ! empty( $data['max_price'] ) ) {
            $price = array_map( 'intval', wp_unslash( $price ) );
            $price = array_filter( $price );
            if ( $n = count( $price ) ) {
                if ( 2 == $n ) {
                    $meta_queries[] = array(
                        'key'     => '_price',
                        'value'   => $price,
                        'type'    => 'NUMERIC',
                        'compare' => 'BETWEEN'
                    );
                } else {
                    if ( empty( $price[0] ) ) {
                        $meta_queries[] = array(
                            'key'     => '_price',
                            'value'   => $price[1],
                            'type'    => 'NUMERIC',
                            'compare' => '<='
                        );
                    } else {
                        $meta_queries[] = array(
                            'key'     => '_price',
                            'value'   => $price[0],
                            'type'    => 'NUMERIC',
                            'compare' => '>='
                        );
                    }
                }
            }
        }

        if ( ! empty( $data['address'] ) ) {
            $meta_queries['_address'] = array(
                'key'     => '_address',
                'value'   => sanitize_text_field( wp_unslash( $data['address'] ) ),
                'compare' => 'LIKE'
            );
        }

        if ( ! empty( $data['zip_code'] ) ) {
            $meta_queries['_zip'] = array(
                'key'     => '_zip',
                'value'   => sanitize_text_field( wp_unslash( $data['zip_code'] ) ),
                'compare' => 'LIKE'
            );
        }

        if ( count( $meta_queries ) ) {
            $meta_queries['relation'] = 'AND';
            $args['meta_query'] = $meta_queries;
        }

        $query = new \WP_Query( $args );
        return $query->found_posts;
    }

    public function get_search_url( $data ) {
        // Get the base search result page link
        $search_result_page = \ATBDP_Permalink::get_search_result_page_link();

        // Prepare an array to hold the query parameters
        $query_params = array();

        // Add each parameter to the query parameters array if it exists in $data
        if ( ! empty( $data['directory_type'] ) ) {
            $query_params['directory_type'] = $data['directory_type'];
        }
        if ( ! empty( $data['title'] ) ) {
            $query_params['q'] = sanitize_text_field( $data['title'] );
        }
        if ( ! empty( $data['category'] ) ) {
            $query_params['in_cat'] = wp_unslash( $data['category'] );
        }
        if ( ! empty( $data['location'] ) ) {
            $query_params['in_loc'] = wp_unslash( $data['location'] );
        }
        if ( ! empty( $data['address'] ) ) {
            $query_params['address'] = sanitize_text_field( $data['address'] );
        }
        if ( ! empty( $data['zip_code'] ) ) {
            $query_params['zip'] = sanitize_text_field( $data['zip_code'] );
        }
        if ( ! empty( $data['tags'] ) ) {
            $query_params['in_tag'] = wp_parse_id_list( wp_unslash( $data['tags'] ) );
        }

        if ( ! empty( $data['min_price'] ) && $data['min_price'] > 0 || ! empty( $data['max_price'] && $data['max_price'] > 0 ) ) {
            $price = array( 
                0 => $data['min_price'] ?? 0,
                1 => $data['max_price'] ?? 0,
            );
            $query_params['price'] = wp_parse_id_list( wp_unslash( $price ) );
        }

        // Convert the query parameters array into a query string
        $query_string = http_build_query($query_params);

        // Append the query string to the search result page link
        if ( ! empty( $query_string ) ) {
            $search_result_page .= '?' . $query_string;
        }

        return $search_result_page;
    }
}
