<?php 
/**
 * Template Loader
 *
 * @since 1.0
 */
function dsa_load_template( $template_file, $args = array() ) {
    if ( is_array( $args ) ) {
        extract( $args );
    }

    $theme_template  = '/directorist-search-alert/' . $template_file . '.php';
    $plugin_template = DSA_DIR . $template_file . '.php';

    if ( file_exists( get_stylesheet_directory() . $theme_template ) ) {
        $file = get_stylesheet_directory() . $theme_template;
    } elseif ( file_exists( get_template_directory() . $theme_template ) ) {
        $file = get_template_directory() . $theme_template;
    } else {
        $file = $plugin_template;
    }


    if ( file_exists( $file ) ) {
        include $file;
    }
}

function dsa_get_terms( $taxonomy = ATBDP_CATEGORY ) {
    $terms = get_terms( array(
        'taxonomy'   => $taxonomy,
        'hide_empty' => false, // Set to true to hide empty terms
    ) );

    return $terms;
}

function dsa_get_saved_search_expiration_days() {
    return get_directorist_option( 'delete_saved_searches_after', 30 );
}

if ( ! function_exists( 'dsa_get_version_from_content' ) ) {
    function dsa_get_version_from_content( $content = '' ) {
        $version = '';

        if ( preg_match('/\*[\s\t]+?version:[\s\t]+?([0-9.]+)/i', $content, $v) ) {
            $version = $v[1];
        }

        return $version;
    }
}

if ( ! function_exists( 'dsa_get_version_from_file_content' ) ) {
    function dsa_get_version_from_file_content( $file_path = '' ) {
        $version = '';

        if ( ! file_exists( $file_path ) ) {
            return $version;
        }

        $content = file_get_contents( $file_path );
        $version = dsa_get_version_from_content( $content );
        
        return $version;
    }
}
