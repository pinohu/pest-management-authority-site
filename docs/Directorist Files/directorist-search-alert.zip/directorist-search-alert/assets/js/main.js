/*
    Name: Directorist search alert
    Author: WPWax
*/

// Function to apply classes and attributes to new save search containers
function updateSaveSearchContainers() {
    const saveSearchContainers = document.querySelectorAll('.dsa-save-search-container');
    saveSearchContainers.forEach((container, index) => {
        container.querySelector('.dsa-modal').classList.add(`modal-${index}`);
        if(!container.querySelector('.dsa-save-search').classList.contains('dsa-saved-search')){
            container.querySelector('.dsa-save-search').setAttribute('data-target', `modal-${index}`);
        }
        container.querySelector('.dsa-modal__close').setAttribute('data-close', `modal-${index}`);
    });
}

// MutationObserver to watch for changes in the DOM
const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
        if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
            updateSaveSearchContainers();
        }
    });
});
const config = { childList: true, subtree: true };
observer.observe(document.body, config);
updateSaveSearchContainers();


document.addEventListener('click', (e) => {
    const currentElement = e.target;
    const saveSearchBtn = currentElement.closest('.dsa-save-search'); 
    const targetId = saveSearchBtn?.getAttribute('data-target');
    const closeId = currentElement.getAttribute('data-close');

    if (targetId) {
        const targetModal = document.querySelector(`.${targetId}`);
        if (targetModal) {
            targetModal.classList.add('dsa-modal-open');
        }
        return;
    }
    if (
        !e.target.closest('.dsa-modal__content') &&
        ((saveSearchBtn && !saveSearchBtn.contains(e.target)) || !e.target.closest('.dsa-edit-search')))
    {
        const openModals = document.querySelectorAll('.dsa-modal-open');
        openModals.forEach(modal => {
            modal.classList.remove('dsa-modal-open');
        });
    }
    if(closeId){
        const targetModal = document.querySelector(`.${closeId}`);
        if(targetModal){
            targetModal.classList.remove('dsa-modal-open')
        }
    }
});

// Saved search edit modal
const editSearch = document.querySelectorAll('.dsa-edit-search');
const editModal = document.querySelector('.dsa-modal');
const editModalClose = document.querySelector('.dsa-modal__close');
if(editSearch){
    editSearch.forEach((element) =>{
        element.addEventListener('click', (e) => {
            editModal.classList.add('dsa-modal-open');
        })
    })
}
if(editModalClose){
    editModalClose.addEventListener('click', (e) => {
        editModal.classList.remove('dsa-modal-open');
    })
}

function showSuccessMessage(notice, form){
    notice.show();
    notice.find('span').text('Search Alert Saved Successfully!');
    notice.addClass('dsa-notice-message--success');
    notice.css('color', '#4caf50');
    form.addClass('dsa-save-form--success');
    setTimeout(() => {
        notice.hide();
        notice.removeClass('dsa-notice-message--success');
        const openModals = document.querySelectorAll('.dsa-modal-open');
        openModals.forEach(modal => {
            modal.classList.remove('dsa-modal-open');
        });
        notice.find('span').text('Please fill in all fields.');
        notice.css('color', '#ff5500');
        form.removeClass('dsa-save-form--success');
    }, 1500);
}

(function ($) {
    // Handle initial save search form submission with ajax
    $('body').on("submit", ".dsa-saved-search-form form", function ( e ) {
        e.preventDefault();
        let tag         = [];
        let price       = [];
        let search_advanced_form = $('.directorist-advanced-filter__form');
        let search_basic_form = $('.directorist-search-form');
        let search_form = search_advanced_form.length > 0 ? search_advanced_form : search_basic_form;
        let this_form   = $('form.dsa-form');
        let grandParent = this_form.closest('.dsa-save-search-container');

        search_form.find('input[name^="in_tag["]:checked').each(function (index, el) {
            tag.push($(el).val())
        });

        search_form.find('input[name^="price["]').each(function (index, el) {
            price.push($(el).val())
        });

        let q              = search_form.find('input[name="q"]').val();
        let directory_type = search_form.find('input[name="directory_type"]').val();
        let in_cat         = search_form.find('.bdas-category-search, .directorist-category-select').val();
        let in_loc         = search_form.find('.bdas-category-location, .directorist-location-select').val();
        let address        = search_form.find('input[name="address"]').val();
        let zip            = search_form.find('input[name="zip"]').val();

        let search_name  = $(this).find('input[name="search_name"]').val();
        let user_email   = $(this).find('input[name="user_email"]').val();
        let alert_period = $('.dsa-form__alert-frequency__period.selected[data-name="alert-period"]').data('value');
        let nonce        = $(this).find('input[name="save_search_nonce"]').val();
        const notice_message = $(this).find('#notice-message');
        const alertFrequencyRadios = $(this).find('input[name="alert-period"]');

        if ( !search_name || !user_email || !alert_period ) {
            notice_message.show();
        } else {
            notice_message.hide();

            const data = {
                action        : 'dsa_saved_search',
                nonce         : nonce,
                search_name   : search_name,
                user_email    : user_email,
                alert_period  : alert_period,
                q             : q,
                directory_type: directory_type,
                in_cat        : in_cat,
                in_loc        : in_loc,
                tag           : tag,
                price         : price,
                address       : address,
                zip           : zip,
            };

            $.post(dsa.ajax_url, data)
                .done(function (response) {
                    showSuccessMessage(notice_message, this_form);
                    alertFrequencyRadios.prop('checked', false);
                    grandParent.find('.dsa-save-search').replaceWith(response.data);
                })
                .fail(function (textStatus, errorThrown) {
                    console.error("AJAX request failed: " + textStatus, errorThrown);
                });
        }

    });

    //handle delete saved search
    $('body').on('click', '.dsa-delete-saved-search', function (event) {
        event.preventDefault();
        // Get the ID of the item to be deleted
        var id = $(this).data('id');
        swal({
            title: "Are you sure?",
            text: "Do you really want to delete this item?!",
            type: "warning",
            cancelButtonText: "Cancel",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, Delete it!",
            showLoaderOnConfirm: true,
            closeOnConfirm: false
          }, function (isConfirm) {
            if (isConfirm) {
                const data = {
                    action: 'dsa_deleted_search',
                    nonce : dsa.ajax_nonce,
                    id    : id,
                };
                $.post( dsa.ajax_url, data, function ( response )  {
                    swal({
                        title: "Delete Successful!",
                        type: "success",
                        timer: 1000,
                        showConfirmButton: false
                    });
                    window.location.reload();
                });
                
            }
        });
    });

    //Generate edit saved search modal content
    $('body').on("click", ".dsa-edit-search", function ( e ) {
        e.preventDefault();
        // Get the ID of the item to be deleted
        var id = $(this).data('id');
        const data = {
            action: 'dsa_edit_modal',
            nonce : dsa.ajax_nonce,
            id    : id,
        };

        $.post( dsa.ajax_url, data, function ( response )  {
            if( response.success ) {
                $('.dsa-saved-search-edit-form').empty().append( response.data );

                //Select category/location
                $('.dsa-category-select').select2();
                $('.dsa-location-select').select2();
            }
        });
    });

    // Handle saved search edit form submission with ajax
    $('body').on("submit", ".dsa-saved-search-edit-form form", function ( e ) {
        e.preventDefault();
        let tag         = [];
        let price       = [];
        let search_form = $('.dsa-edit-saved-form');

        search_form.find('input[name^="in_tag["]:checked').each(function (index, el) {
            tag.push($(el).val())
        });

        search_form.find('input[name^="price["]').each(function (index, el) {
            price.push($(el).val())
        });

        let id          = search_form.find('input[name="id"]').val();
        let search_name = search_form.find('input[name="search_name"]').val();

        let   alert_period   = $('input[name="alert-period"]:checked').val();
        let   nonce          = dsa.ajax_nonce;
        const notice_message = $(this).find('#notice-message');

        if ( !alert_period && !q  && !in_cat && !in_loc && !address && !zip ) {
            notice_message.show();
        } else {
            notice_message.hide();

            const data = {
                action      : 'dsa_edit_saved_search',
                nonce       : nonce,
                id          : id,
                alert_period: alert_period,
                search_name : search_name,
            };

            $.post(dsa.ajax_url, data)
                .done(function (response) {
                    showSuccessMessage(notice_message, search_form);
                    window.location.reload();
                })
                .fail(function (textStatus, errorThrown) {
                    console.error("AJAX request failed: " + textStatus, errorThrown);
                });
        }
    });

    $('body').on('click', '.dsa-saved-search, .dsa-delete-saved-search', function (event) {
        event.preventDefault();
        // Get the ID of the item to be deleted
        var id    = $(this).data('id');
        var $this = $(this);
        console.log($this);
        swal({
            title              : "Are you sure?",
            text               : "Do you really want to removed this from search saved?!",
            type               : "warning",
            cancelButtonText   : "Cancel",
            showCancelButton   : true,
            confirmButtonColor : "#DD6B55",
            confirmButtonText  : "Yes, Remove it!",
            showLoaderOnConfirm: true,
            closeOnConfirm     : false
          }, function (isConfirm) {
            if (isConfirm) {
                const data = {
                    action: 'dsa_deleted_search',
                    nonce : dsa.ajax_nonce,
                    id    : id,
                };
                $.post( dsa.ajax_url, data, function ( response )  {
                    if( response.success ) {
                        $this.replaceWith( response.data );
                    }
                });
                swal({
                    title            : "Removed Successful!",
                    type             : "success",
                    timer            : 200,
                    showConfirmButton: false
                });
                window.location.reload();
            }
        });
    });

    // Prevent Search Name to AJAX Search
    $('body').on('click keyup', 'input[name="search_name"], input[name="user_email"]', function (event) {
        event.stopPropagation();
    });

    // Handle the custom radio button click
    $('body').on('click', '.dsa-form__custom-radio', function() {
        // Get the name of the radio group
        var radioGroupName = $(this).data('name');

        // Deselect any previously selected radio in this group
        $('.dsa-form__custom-radio[data-name="' + radioGroupName + '"]').removeClass('selected');

        // Mark the clicked radio as selected
        $(this).addClass('selected');
    });

})(jQuery);