## Development Setup

### Prerequisites

- Node.js v22.14.0 or higher
- npm v7 or higher
- WordPress environment with Directorist plugin installed

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/sovware/directorist-search-alert.git
   cd directorist-search-alert
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

### Development

#### Watch SCSS changes and auto-compile to CSS
```bash
npm run scss
```

#### Generate RTL version of CSS (requires `style.css`)
```bash
npm run rtl
```

### Production Build

#### Build minified CSS
```bash
npm run scss:build
```

#### Generate minified RTL CSS (requires `style.min.css`)
```bash
npm run rtl:min
```

### Workflow

#### Start development

```bash
npm run scss
```

Edit SCSS files in `assets/scss/`

CSS will auto-compile to `assets/css/style.css`

#### Build for production

```bash
npm run scss:build && npm run rtl:min
```

Creates:

- `style.min.css` (minified production CSS)
- `style-rtl.css` (RTL version)
- `style-rtl.min.css` (minified RTL version)

### File Structure

```
directorist-search-alert/
├── assets/
│   ├── css/                 # Compiled CSS files
│   └── scss/                # Source SCSS files
├── includes/                # Plugin PHP files
├── languages/               # Translation files
├── index.js
└── readme.md
```
```` ▋