<?php
/**
 * Directorist - Search Alert
 *
 * @package           Directorist_Search_Alert
 * @author            wpwax
 * @copyright         2019 wpwax or Company Name
 * @license           GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name:       Directorist - Search Alert
 * Plugin URI:        https://directorist.com/product/directorist-search-alert/
 * Description:       Notify users when new listings match their saved search preferences.
 * Version:           1.0.2
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            wpwax
 * Author URI:        https://wpwax.com/
 * Text Domain:       directorist-search-alert
 * License:           GPL v2 or later
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */

defined( 'ABSPATH' ) || exit;

// Setup The Consts.
if ( ! defined( 'DSA_PLUGIN_FILE' ) ) {
	define( 'DSA_PLUGIN_FILE', __FILE__ );
}

$const_file = plugin_dir_path( DSA_PLUGIN_FILE ) . '/const.php';
require $const_file;

// Include The Helpers.
$helpers_file = DSA_PLUGIN_PATH . 'helpers/helpers.php';
require $helpers_file;

$edd_plugin_updater_file = DSA_PLUGIN_PATH . 'app/Setup/Edd_SL_plugin_Updater.php';
if ( ! class_exists( 'EDD_SL_Plugin_Updater' ) ) {
	include $edd_plugin_updater_file;
}

function directorist_search_alert_update_controller() {
	$data                    = get_user_meta( get_current_user_id(), '_plugins_available_in_subscriptions', true );
	$license_key             = ! empty( $data['directorist-search-alert'] ) ? $data['directorist-search-alert']['license'] : '';

	if ( class_exists( 'EDD_SL_Plugin_Updater' ) ) {
		new EDD_SL_Plugin_Updater( ATBDP_AUTHOR_URL, __FILE__, array(
			'version' => DSA_VERSION,           // current version number
			'license' => $license_key,          // license key (used get_option above to retrieve from DB)
			'item_id' => DSA_POST_ID,   // id of this plugin
			'author'  => 'AazzTech',            // author of this plugin
			'url'     => home_url(),
			'beta'    => false                  // set to true if you wish customers to receive update notifications of beta releases
		) );
	}
}

// Include The App.
$app = DSA_PLUGIN_PATH . 'app/base.php';
if ( ! class_exists( 'Directorist_Search_Alert' ) ) {
	include $app;
}

add_action( 'admin_init', 'directorist_search_alert_update_controller' );
register_activation_hook( __FILE__, array( 'Directorist_Search_Alert', 'create_database_table' ) );
register_deactivation_hook( __FILE__, array( 'Directorist_Search_Alert', 'clear_scheduled_hook' ) );