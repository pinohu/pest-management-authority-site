;(function ($) {
    'use strict';

    $(function () {
       
        //alert('dsfd')
    });
    
}(jQuery));