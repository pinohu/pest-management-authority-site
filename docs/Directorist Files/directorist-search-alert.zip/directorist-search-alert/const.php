<?php

if ( ! defined( 'DSA_LANG_PATH' ) ) {
	define( 'DSA_LANG_PATH', dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
if ( ! defined( 'DSA_PLUGIN_PATH' ) ) {
	define( 'DSA_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'DSA_PLUGIN_DIR_URI' ) ) {
	define( 'DSA_PLUGIN_DIR_URI', plugin_dir_url( __FILE__ ) );
}
if ( ! defined( 'DSA_ASSET_URI' ) ) {
	define( 'DSA_ASSET_URI', DSA_PLUGIN_DIR_URI . 'assets/' );
}
if ( ! defined( 'DSA_CSS_URI' ) ) {
	define( 'DSA_CSS_URI', DSA_ASSET_URI . 'css/' );
}
if ( ! defined( 'DSA_JS_URI' ) ) {
	define( 'DSA_JS_URI', DSA_ASSET_URI . 'js/' );
}
if ( ! defined('DSA_DIR') ) { 
	define('DSA_DIR', DSA_PLUGIN_PATH.'templates/');
 }
 if ( ! defined('DSA_VERSION') ) { 
	define('DSA_VERSION', "1.0.2");
 }
 // post id from download post type (edd)
if ( ! defined('DSA_POST_ID') ) {
    define( 'DSA_POST_ID', 323908 );
}
// plugin author url
if ( ! defined( 'ATBDP_AUTHOR_URL' ) ) {
	define( 'ATBDP_AUTHOR_URL', 'https://directorist.com' );
}
// Plugin version.
if ( ! defined( 'DSA_VERSION' ) ) {
	define( 'DSA_VERSION', dsa_get_version_from_file_content( DSA_PLUGIN_FILE ) );
}