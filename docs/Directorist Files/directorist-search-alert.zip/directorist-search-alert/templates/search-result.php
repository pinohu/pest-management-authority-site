<?php
/**
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
use DSA\Database\Database;
if( ! empty( $user_email ) ) {
    $check_saved_search = Database::check_combined_request_values_in_db( $user_email );
}

$saved_class        = ! empty( $check_saved_search ) ? 'dsa-saved-search' : '';
$save_search_icon   = ! empty( $check_saved_search ) ? 'fas fa-heart' : 'far fa-heart';
$save_search_text   = ! empty( $check_saved_search ) ? 'Search Saved' : 'Save Search';
$id                 = absint( $check_saved_search ?? 0 );

$uniqueId = uniqid();

?>
<div class="dsa-save-search-container">
    <span class="dsa-save-search <?php echo esc_attr( $saved_class ) ?>" data-id="<?php echo esc_attr( $id ?? 0 ) ?>"><?php directorist_icon($save_search_icon, true) . esc_html_e( $save_search_text, 'directorist-search-alert' ); ?></span>
    <div class="dsa-modal">
        <div class="dsa-modal__content">
            <span class="dsa-modal__close"><?php echo directorist_icon('fas fa-times', false) ?></span>
            <div class="dsa-modal__header">
                <h2><?php esc_html_e( 'Save your search', 'directorist-search-alert' ) ?></h2>
                <p><?php esc_html_e( 'Rename your search and change how often you get email notifications.', 'directorist-search-alert' ) ?></p>
            </div>
            <div class="dsa-modal__body dsa-saved-search-form">
                <form class="dsa-form">
                    <div class="dsa-form__input dsa-form__input-text">
                        <label for="dsa-form__search-text-<?php echo $uniqueId; ?>"><?php esc_html_e( 'Name your search', 'directorist-search-alert' ) ?></label>
                        <input type="text" id="dsa-form__search-text-<?php echo $uniqueId; ?>" name="search_name" />
                    </div>

                    <?php if ( is_user_logged_in() ) : ?>
                        <input type="hidden" name="user_email" value="<?php echo $user_email ?? ''; ?>" />
                    <?php else : ?>
                        <div class="dsa-form__input dsa-form__input-email"> <!-- for guest user -->
                            <label for="dsa-form__guest-email-<?php echo $uniqueId; ?>"><?php esc_html_e( 'Email', 'directorist-search-alert' ) ?></label>
                            <input type="email" id="dsa-form__guest-email-<?php echo $uniqueId; ?>" name="user_email" />
                            <small class="dsa-form__guest-input-short">We’ll store your email securely to send you alerts when new listings match your search.</small>
                        </div>
                    <?php endif; ?>

                    <div class="dsa-form__alert-frequency">
                        <span><?php esc_html_e( 'Alert me to new results', 'directorist-search-alert' ) ?></span>
                        <?php
                        $frequencies = [
                            'daily'             => __( 'Daily', 'directorist-search-alert' ),
                            'weekly'            => __( 'Weekly', 'directorist-search-alert' ),
                            'monthly'           => __( 'Monthly', 'directorist-search-alert' ),
                            'on_create_listing' => __( 'When listings match', 'directorist-search-alert' ),
                            'never'             => __( 'Never', 'directorist-search-alert' ),
                        ];
                        foreach ($frequencies as $value => $label) {
                            $frequencyId = "dsa-{$value}-{$uniqueId}";
                            $checked = $value == 'on_create_listing' ? 'selected' : '';
                            ?>
                            <div class="dsa-form__alert-frequency__period dsa-form__custom-radio <?php esc_html_e( $checked ) ?>" id="<?php esc_attr_e( $frequencyId ); ?>" data-name="alert-period" data-value="<?php echo esc_attr( $value ); ?>">
                                <span class="dsa-form__custom-radio-label"><?php esc_html_e($label); ?></span>
                            </div>
                        <?php } ?>
                    </div>

                    <input type="hidden" id="save_search_nonce" name="save_search_nonce" value="<?php echo wp_create_nonce( 'dsa_save_search_form' ); ?>">
                    <button type="submit" class="dsa-form__save-btn">
                        <?php esc_html_e( 'Save search', 'directorist-search-alert' ) ?>
                    </button>
                    <div class="dsa-notice-message" id="notice-message" style="display: none; color: red;">
                        <?php directorist_icon('fas fa-check', true) ?>
                        <span><?php esc_html_e( 'Please fill in all fields.', 'directorist-search-alert' ) ?></span>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>