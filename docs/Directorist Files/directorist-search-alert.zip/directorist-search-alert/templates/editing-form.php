<form class="dsa-edit-saved-form">
    <div class="dsa-form__input dsa-form__input-text">
        <label for="dsa-form__search-text"><?php esc_html_e( 'Name', 'directorist-search-alert' ) ?></label>
        <input type="text" id="dsa-form__search-text" name="search_name" value="<?php echo esc_attr( $values['name'] ?? '' ) ?>" />
    </div>

    <div class="dsa-form__alert-frequency">
        <span><?php esc_html_e( 'Alert me on new results', 'directorist-search-alert' ) ?></span>
        <?php
        $frequencies = [
            'daily'             => __( 'Daily', 'directorist-search-alert' ),
            'weekly'            => __( 'Weekly', 'directorist-search-alert' ),
            'monthly'           => __( 'Monthly', 'directorist-search-alert' ),
            'on_create_listing' => __( 'When listings match', 'directorist-search-alert' ),
            'never'             => __( 'Never', 'directorist-search-alert' ),
        ];
        foreach ( $frequencies as $value => $label ) {
            $checked = ( $value == $values['notification'] ) ? 'checked' : '';
            ?>
            <div class="dsa-form__alert-frequency__period">
                <input type="radio" name="alert-period" id="<?php echo esc_attr( $value ); ?>" value="<?php echo esc_attr( $value ); ?>" <?php echo esc_attr( $checked ) ?>>
                <label for="<?php echo $value; ?>"><?php esc_html_e( $label ); ?></label>
            </div>
        <?php } ?>
    </div>

    <input type="hidden" name="id" value="<?php echo absint( $values['ID'] ) ?>">
    <button type="submit" class="dsa-form__save-btn">
        <?php esc_html_e( 'Save search', 'directorist-search-alert' ) ?>
    </button>
    <div class="dsa-notice-message" id="notice-message" style="display: none; color: red;">
        <?php directorist_icon('fas fa-check', true) ?>
        <span><?php esc_html_e( 'Please fill in all fields.', 'directorist-search-alert' ) ?></span>
    </div>
</form>