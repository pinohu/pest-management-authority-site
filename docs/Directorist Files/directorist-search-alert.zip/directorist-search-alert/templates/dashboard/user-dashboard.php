<?php
/**
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
?>
<div class="directorist-tab__pane" id="saved_search">
    <?php if( $values ) : ?>
        <div class="dsa-saved-search-table directorist-table-responsive">
            <table class="directorist-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Name', 'directorist-search-alert' ) ?></th>
                        <th><?php esc_html_e( 'Filters', 'directorist-search-alert' ) ?></th>
                        <th><?php esc_html_e( 'New Listings', 'directorist-search-alert' ) ?></th>
                        <th><?php esc_html_e( 'Notifications', 'directorist-search-alert' ) ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach( $values as $value ) :
                            $q                  = sanitize_text_field( $value['title'] ?? '' );
                            $address            = sanitize_text_field( $value['address'] ?? '' );
                            $zip_code           = sanitize_text_field( $value['zip_code'] ?? '' );
                            $in_cat             = $dashboard->get_category_name( absint( $value['category'] ?? 0 ) );
                            $in_loc             = $dashboard->get_location_name( absint( $value['location'] ?? 0 ) );
                            $price_range        = $dashboard->get_price_range( $value['min_price'], $value['max_price'] );
                            $tags               = ! empty( $value['tags'] ) ? explode( ',', sanitize_text_field( $value['tags'] ) ) : [];
                            $tag_names          = $dashboard->get_tag_names( $tags );
                            $search_filters     = $dashboard->get_search_filters( $q, $in_cat, $tag_names, $in_loc, $address, $zip_code, $price_range );
                            $get_date           = $dashboard->get_date( $value['date'] );
                            $new_listings_count = $dashboard->new_listings_count( $value );
                            $view_link          = $dashboard->get_search_url( $value );
                            $notification       = $dashboard->get_notification_status( $value['notification'] );
                        ?>
                        <tr>
                            <td class="dsa-column-search-name">
                                <div class="dsa-search-name">
                                    <h3><?php esc_html_e( $value['name'] ?? '' ); ?></h3>
                                    <span><?php esc_html_e( $get_date ); ?></span>
                                </div>
                            </td>
                            <td class="dsa-column-search-filter">
                                <span class="dsa-search-filters"><?php esc_html_e( $search_filters ); ?></span>
                            </td>
                            <td class="dsa-column-new-listings">
                                <span class="dsa-new-listings"><?php esc_html_e( $new_listings_count ?? 0 ) ?></span>
                            </td>
                            <td class="dsa-column-notification">
                                <div class="dsa-search-notification">
                                    <span><?php esc_html_e( $notification ); ?></span>
                                    <div class="dsa-search-action">
                                        <a href="<?php echo esc_url( $view_link ); ?>">
                                            <?php esc_html_e( 'View', 'directorist-search-alert' ) ?>
                                        </a>
                                        <span class="dsa-edit-search" data-id="<?php echo esc_attr( $value['ID'] ) ?>">
                                            <?php esc_html_e( 'Edit', 'directorist-search-alert' ) ?>
                                        </span>
                                        <span class="dsa-delete-saved-search" data-id="<?php echo esc_attr( $value['ID'] ) ?>">
                                            <?php esc_html_e( 'Delete', 'directorist-search-alert' ) ?>
                                        </span>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="directorist-notfound"><?php esc_html_e( 'Nothing found!', 'directorist-search-alert' ); ?></div>
    <?php endif; ?>

    <div class="dsa-modal">
        <div class="dsa-modal__content">
            <span class="dsa-modal__close"><?php echo directorist_icon('fas fa-times', false) ?></span>
            <div class="dsa-modal__header">
                <h2><?php esc_html_e( 'Save your search', 'directorist-search-alert' ) ?></h2>
            </div>
            <div class="dsa-modal__body dsa-saved-search-edit-form">
                
            </div>
        </div>
    </div>
</div>