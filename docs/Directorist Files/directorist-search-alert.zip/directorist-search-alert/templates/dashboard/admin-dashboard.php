<?php
/**
 * @author  wpWax
 * @since   1.0
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
?>
<div class="wrap dsa-user-dashboard-wrap">
    <h1 class="wp-heading-inline"><?php esc_html_e( 'Saved Search', 'directorist-search-alert' ) ?></h1>
    <table class="wp-list-table widefat fixed">
        <thead>
            <tr>
                <th><?php esc_html_e( 'Search Name', 'directorist-search-alert' ) ?></th>
                <th><?php esc_html_e( 'Filters', 'directorist-search-alert' ) ?></th>
                <th><?php esc_html_e( 'Email', 'directorist-search-alert' ) ?></th>
                <th><?php esc_html_e( 'Notification', 'directorist-search-alert' ) ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if ( $values)  : ?>

                <?php foreach ( $values as $value ) : ?>
                    <?php
                        $q              = sanitize_text_field( $value['title'] ?? '' );
                        $address        = sanitize_text_field( $value['address'] ?? '' );
                        $zip_code       = sanitize_text_field( $value['zip_code'] ?? '' );
                        $in_cat         = $dashboard->get_category_name( absint( $value['category'] ?? 0 ) );
                        $in_loc         = $dashboard->get_location_name( absint( $value['location'] ?? 0 ) );
                        $min_price      = sanitize_text_field( $value['min_price'] ?? '' );
                        $max_price      = sanitize_text_field( $value['max_price'] ?? '' );
                        $email          = sanitize_text_field( $value['email'] ?? '' );
                        $price_range    = $dashboard->get_price_range( $value['min_price'], $value['max_price'] );
                        $tags           = !empty($value['tags']) ? explode(',', sanitize_text_field( $value['tags'] ) ) : [];
                        $tag_names      = $dashboard->get_tag_names( $tags );
                        $search_filters = $dashboard->get_search_filters( $q, $in_cat, $tag_names, $in_loc, $address, $zip_code, $price_range );
                        $get_date       = $dashboard->get_date( $value['date'] );
                        $notification   = $dashboard->get_notification_status( $value['notification'] );
                    ?>
                    <tr>
                        <td>
                            <h2><?php esc_html_e( $value['name'] ?? '' ) ?></h2>
                            <span><?php esc_html_e( $get_date ) ?></span>
                        </td>
                        <td>
                            <span class="dsa-user-dashboard-filters"><?php esc_html_e( $search_filters ) ?></span>
                        </td>
                        <td><span class="dsa-user-dashboard-saved-content"><?php esc_html_e( $email ) ?></span></td>
                        <td>
                            <span class="dsa-user-dashboard-saved-content"><?php esc_html_e( $notification ) ?>
                            <a href="" class="dsa-edit-search" data-id="<?php echo esc_attr( $value['ID'] ) ?>"><?php directorist_icon( 'las la-edit' ); ?><?php esc_html_e( 'Edit', 'directorist' ); ?></a>
                            <span class="dsa-delete-saved-search" data-id="<?php echo esc_attr( $value['ID'] ) ?>">
                                <?php esc_html_e( 'Delete', 'directorist-search-alert' ) ?>
                            </span>
                        </td>
                    </tr>
                <?php endforeach ?>

                <?php else : ?>
                    <tr>
                        <td colspan="4" style="text-align: center; padding: 20px;">
                            <?php esc_html_e( 'No Saved Searches Yet', 'directorist-search-alert' ); ?>
                        </td>
                    </tr>
                <?php endif ?>
        </tbody>
    </table>
    <div class="dsa-modal">
        <div class="dsa-modal__content">
            <span class="dsa-modal__close"><?php echo directorist_icon('fas fa-times', false) ?></span>
            <div class="dsa-modal__header">
                <h2><?php esc_html_e( 'Save your search', 'directorist-search-alert' ) ?></h2>
            </div>
            <div class="dsa-modal__body dsa-saved-search-edit-form">
                
            </div>
        </div>
    </div>
</div>