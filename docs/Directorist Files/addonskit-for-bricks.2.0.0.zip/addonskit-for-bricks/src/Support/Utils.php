<?php
namespace WpWax\AKFB\Support;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Directorist\Helper;
use Directorist\Directorist_Single_Listing;
use Directorist\Multi_Directory\Builder_Data;

class Utils {

	public static function do_shortcode( $tag, $atts = [], $content = null ) {
		global $shortcode_tags;

		if ( ! isset( $shortcode_tags[$tag] ) ) {
			return false;
		}

		echo call_user_func( $shortcode_tags[$tag], $atts, $content, $tag );
	}

	public static function maybe_editor() {
		return ( isset( $_GET['bricks_preview'] ) || bricks_is_builder() || bricks_is_builder_call() );
	}

	public static function get_directories() {
		$directories = directorist_get_directories();

		if ( is_wp_error( $directories ) || empty( $directories ) ) {
			return [];
		}

		return wp_list_pluck( $directories, 'name', 'slug' );
	}

	public static function get_builder_data() {
		$builder = new Builder_Data();

		return $builder->get_fields();
	}

	public static function get_quick_actions_fields( $key ) {
		$fields = [];
		$data   = self::get_builder_data()['single_listing_header']['layout'];

		foreach ( $data as $args ) {
			if ( $key === $args['placeholderKey'] ) {
				$fields = $args['placeholders'][1]['acceptedWidgets'];
				break;
			}
		}

		$actions = array_combine(
			$fields,
			array_map( 'ucwords', str_replace( '_', ' ', $fields ) ) 
		);

		return $actions;
	}

	public static function get_meta_info_fields( $key = '' ) {
		$fields      = [];
		$data        = self::get_builder_data()['single_listing_header']['layout'];
		$except_data = ['price', 'category', 'location'];

		foreach ( $data as $args ) {
			if ( $key === $args['placeholderKey'] ) {
				$accepted_fields = $args['acceptedWidgets'];
				$fields          = array_diff( $accepted_fields, $except_data );
				break;
			}
		}

		$result = array_combine(
			$fields,
			array_map( 'ucwords', str_replace( '_', ' ', $fields ) )
		);

		return $result;
	}

	public static function load_listing_widget( $widget_key = '' ) {
		if ( empty( $widget_key ) || ! is_string( $widget_key ) ) {
			return;
		}

		$widgets = self::get_builder_data()['single_listing_header']['widgets'];
		$args    = [];

		foreach ( $widgets as $w_key => $data ) {
			if ( $widget_key !== $w_key || empty( $data['options'] ) || empty( $data['options']['fields'] ) ) {
				continue;
			}

			$args                = $data;
			$args['widget_name'] = $widget_key;
			$args['widget_key']  = $widget_key;

			foreach ( $data['options']['fields'] as $field_key => $value ) {
				$args[ $field_key ] = $value['value'];
			}
		}

		if ( empty( $args ) ) {
			return;
		}

		unset( $args['options'] );

		$listing = Directorist_Single_Listing::instance( get_the_ID() );
		echo $listing->field_template( $args );
	}

	public static function load_listing_section( $args = [] ) {
		if ( empty( $args ) ) {
			return;
		}

		$listing         = Directorist_Single_Listing::instance( get_the_ID() );
		$args['listing'] = $listing;

		$listing->section_template( $args );
	}

	public static function load_listing_field( $field = '' ) {
		if ( empty( $field ) ) {
			return;
		}

		$directory_id = (int) get_post_meta( get_the_ID(), '_directory_type', true );

		if ( ! $directory_id ) {
			$directory_id = directorist_get_default_directory();
		}

		$fields = directorist_get_listing_form_fields( $directory_id );

		if ( empty( $fields ) || ! is_array( $fields ) || ! isset( $fields[ $field ] ) ) {
			return;
		}

		$listing = Directorist_Single_Listing::instance( get_the_ID() );
		$data   = $fields[ $field ];

		switch ( $data['widget_key'] ) {
			case 'map':
				$listing->field_template( $data );
				break;

			case 'social_info':
				$data['label'] = '';
				$listing->field_template( $data );
				break;

			case 'pricing':
				Helper::listing_price( $listing->id );
				break;

			case 'checkbox':
				echo self::prepare_checkbox_data( $data );
				break;

			default:
				echo $listing->get_field_value( $data );
				break;
		}
	}

	public static function prepare_checkbox_data( $data ) {
		if ( empty( $data['options'] ) ) {
			return '';
		}
		
		$options = [];

		foreach ( $data['options'] as $value ) {
			$options[] = $value['option_label'];
		}

		return join( ', ', $options );
	}

	public static function load_template( $template, $args = [] ) {
		Helper::get_template( $template, $args );
	}

	public static function to_term_taxonomy_map( $values = [] ) {
		if ( empty( $values ) || ! is_array( $values ) ) {
			return [];
		}

		$tax_map = [];

		foreach ( $values as $term ) {
			list( $taxonomy, $term_id ) = explode( '::', $term );

			if ( isset( $tax_map[ $taxonomy ] ) ) {
				$tax_map[ $taxonomy ][] = $term_id;
			} else {
				$tax_map[ $taxonomy ] = [ $term_id ];
			}
		}

		return $tax_map;
	}

	public static function to_term_ids( $values = [] ) {
		if ( empty( $values ) || ! is_array( $values ) ) {
			return [];
		}

		return array_map( static function( $term ) {
			list( , $term_id ) = explode( '::', $term );
			return $term_id;
		}, $values );
	}

	public static function to_term_slugs( $values = [], $taxonomy = ATBDP_CATEGORY ) {
		$ids = static::to_term_ids( $values );

		if ( empty( $ids ) ) {
			return array();
		}

		$slugs = get_terms( array(
			'taxonomy' => $taxonomy,
			'include'  => $ids,
			'fields'   => 'slugs',
			'orderby'  => 'include'
		) );

		if ( is_wp_error( $slugs ) || empty( $slugs ) ) {
			return array();
		}

		return $slugs;
	}
}
