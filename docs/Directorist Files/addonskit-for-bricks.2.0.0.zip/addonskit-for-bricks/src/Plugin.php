<?php
namespace WpWax\AKFB;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WpWax\AKFB\DynamicTags\DataProvider;
use WpWax\AKFB\Elements\Elements;

class Plugin {

	protected static $instance = null;

	public static function instance() {
		if ( is_null( static::$instance ) ) {
			static::$instance = new static();
			static::$instance->init();
		}

		return static::$instance;
	}

	protected function init() {
		$this->load_files();

		Elements::init();
		DataProvider::init();

		add_action( 'wp_enqueue_scripts', static function() {
			$img = DIRECTORIST_ASSETS . 'images/elementor-icon.png';

			$data = "
			.bricks-add-element .element-icon .ion-md-star.directorist-icon:before {
				content: '';
			}
			.bricks-add-element .element-icon .ion-md-star.directorist-icon {
				background-image: url('{$img}');
				background-repeat: no-repeat;
				background-size: cover;
				filter: grayscale(80%);
				width: 24px;
				height: 24px;
			}
			";

			wp_add_inline_style(
				'bricks-builder',
				$data
			);
		}, 100 );
	}

	protected function load_files() {
		require_once AKFB_PLUGIN_DIR . '/src/Support/Utils.php';
		require_once AKFB_PLUGIN_DIR . '/src/Elements/Elements.php';
		require_once AKFB_PLUGIN_DIR . '/src/DynamicTags/DataProvider.php';
	}
}
