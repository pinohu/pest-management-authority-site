<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SingleLocation extends SingleTerm {

	public $name = 'directorist-location';

	public function get_label() {
		return __( 'Single Location', 'addonskit-for-bricks' );
	}

	protected static function get_shortcode() {
		return 'directorist_location';
	}
}
