<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WpWax\AKFB\Support\Utils;

class SearchResult extends Listings {
	
	public $name = 'directorist-search-results';
	
	public function get_label() {
		return __( 'Search Results', 'addonskit-for-bricks' );
	}

	public function render() {
		echo "<div {$this->render_attributes( '_root' )}>"; 
			Utils::do_shortcode( 'directorist_search_result', $this->get_ready_args() );
		echo '</div>';
	}
}
