<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Bricks\Element;
use WpWax\AKFB\Support\Utils;

abstract class SingleTerm extends BaseElement {
	use Styles\Container;

	public function get_keywords() {
		return ['single category', 'single location', 'single tag', 'tag archive', 'location archive', 'category archive'];
	}

	public function set_control_groups() {
		$this->control_groups['listing_controls'] = [
			'title' => esc_html__( 'Listing Controls', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['listings'] = [
			'title' => esc_html__( 'Listings Layout', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['query'] = [
			'title' => esc_html__( 'Query', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];
	}

	public function set_controls() {
		$this->set_listing_control_controls( 'listing_controls', 'listing_controls' );
		$this->set_listings_controls( 'listings', 'listings' );
		$this->set_query_controls( 'query', 'query' );
	}

	protected function set_listing_control_controls( $prefix, $group ) {
		$this->controls['show_header'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => esc_html__( 'Display Controls', 'addonskit-for-bricks' ),
			'type'    => 'checkbox',
			'inline'  => true,
			'small'   => true,
			'default' => true,                                                       // Default: false
		];

		// $this->controls['show_filter_button'] = [
		// 	'tab'      => 'content',
		// 	'group'    => $group,
		// 	'label'    => esc_html__( 'Display Filter Button', 'addonskit-for-bricks' ),
		// 	'type'     => 'checkbox',
		// 	'required' => ['show_header', '=', true],
		// 	'inline'   => true,
		// 	'small'    => true,
		// 	'default'  => false,                                                           // Default: false
		// ];

		$this->controls['header_title'] = [
			'tab'           => 'content',
			'group'         => $group,
			'label'         => esc_html__( 'Listing Count Text', 'addonskit-for-bricks' ),
			'type'          => 'text',
			'spellcheck'    => true,
			'inlineEditing' => false,
			'default'       => __( 'Listings Found', 'addonskit-for-bricks' ),
			'required'      => ['show_header', '=', true],
		];
	}

	protected function set_listings_controls( $prefix, $group ) {
		$this->controls['view'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => __( 'Default View', 'addonskit-for-bricks' ),
			'type'    => 'select',
			'options' => [
				'grid' => __( 'Grid', 'addonskit-for-bricks' ),
				'list' => __( 'List', 'addonskit-for-bricks' ),
				'map'  => __( 'Map', 'addonskit-for-bricks' ),
			],
			'default'     => 'grid',
			'inline'      => true,
			'placeholder' => esc_html__( 'Select a view', 'addonskit-for-bricks' ),
			'multiple'    => false,
			'searchable'  => false,
			'clearable'   => false,
		];
	  
		$this->controls['map_height'] = [
			'tab'      => 'content',
			'group'    => $group,
			'label'    => __( 'Map Height', 'addonskit-for-bricks' ),
			'type'     => 'number',
			'min'      => 300,
			'max'      => 1980,
			'step'     => 10,
			'inline'   => true,
			'default'  => 500,
			'required' => ['view', '=', 'map'],
		];

		$this->controls['columns'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => __( 'Columns', 'addonskit-for-bricks' ),
			'type'    => 'select',
			'options' => [
				'6' => __( '6 Columns', 'addonskit-for-bricks' ),
				'4' => __( '4 Columns', 'addonskit-for-bricks' ),
				'3' => __( '3 Columns', 'addonskit-for-bricks' ),
				'2' => __( '2 Columns', 'addonskit-for-bricks' ),
			],
			'default'     => '3',
			'required'    => ['view', '=', 'grid'],
			'inline'      => true,
			'placeholder' => esc_html__( 'Select column size', 'addonskit-for-bricks' ),
			'multiple'    => false,
			'searchable'  => false,
			'clearable'   => false,
		];

		$this->controls['sidebar'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => __( 'Sidebar Filter', 'addonskit-for-bricks' ),
			'type'    => 'select',
			'inline'  => true,
			'options' => [
				''              => __( 'Default', 'addonskit-for-bricks' ),
				'left_sidebar'  => __( 'Left', 'addonskit-for-bricks' ),
				'right_sidebar' => __( 'Right', 'addonskit-for-bricks' ),
				'no_sidebar'    => __( 'No Sidebar', 'addonskit-for-bricks' ),
			],
		];

		$this->controls['show_preview_image'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => esc_html__( 'Display Preview Image', 'addonskit-for-bricks' ),
			'type'    => 'checkbox',
			'inline'  => true,
			'small'   => true,
			'default' => true,                                                            // Default: false
		];

		$this->controls['show_pagination'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => esc_html__( 'Display Pagination', 'addonskit-for-bricks' ),
			'type'    => 'checkbox',
			'inline'  => true,
			'small'   => true,
			'default' => false,                                                        // Default: false
		];
	}

	protected function set_query_controls( $prefix, $group ) {
		// $this->controls['terms'] = [
		// 	'tab'         => 'content',
		// 	'group'       => $group,
		// 	'label'       => __( 'Terms', 'addonskit-for-bricks' ),
		// 	'description' => __( 'Select listing categories, locations or tags by typing the term name or from the dropdown items.', 'addonskit-for-bricks' ),
		// 	'type'        => 'select',
		// 	'inline'      => false,
		// 	'placeholder' => esc_html__( 'Select terms', 'addonskit-for-bricks' ),
		// 	'multiple'    => true,
		// 	'searchable'  => true,
		// 	'clearable'   => true,
		// 	'optionsAjax' => [
		// 		'action'    => 'bricks_get_terms_options',
		// 		'postTypes' => ['at_biz_dir'],
		// 		'taxonomy'  => [ ATBDP_CATEGORY, ATBDP_LOCATION, ATBDP_TAGS ]
		// 	]
		// ];

		$this->controls['per_page'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => __( 'Number of Listings', 'addonskit-for-bricks' ),
			'type'    => 'number',
			'min'     => 1,
			'max'     => 100,
			'step'    => 1,
			'default' => 6,
			'inline'  => true,
		];

		$this->controls['order_by'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => __( 'Order by', 'addonskit-for-bricks' ),
			'type'    => 'select',
			'options' => [
				'title' => __( 'Title', 'addonskit-for-bricks' ),
				'date'  => __( 'Date', 'addonskit-for-bricks' ),
				'price' => __( 'Price', 'addonskit-for-bricks' ),
			],
			'default'     => 'date',
			'inline'      => true,
			'placeholder' => esc_html__( 'Select order by', 'addonskit-for-bricks' ),
			'multiple'    => false,
			'searchable'  => false,
			'clearable'   => true,
		];

		$this->controls['order'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => __( 'Order', 'addonskit-for-bricks' ),
			'type'    => 'select',
			'options' => [
				'asc'  => __( 'ASC', 'addonskit-for-bricks' ),
				'desc' => __( 'DESC', 'addonskit-for-bricks' ),
			],
			'default'     => 'desc',
			'inline'      => true,
			'placeholder' => esc_html__( 'Select listing order', 'addonskit-for-bricks' ),
			'multiple'    => false,
			'searchable'  => false,
			'clearable'   => true,
		];

		$this->controls['show_featured_only'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => esc_html__( 'Display Featured Listings Only', 'addonskit-for-bricks' ),
			'type'    => 'checkbox',
			'inline'  => true,
			'small'   => true,
			'default' => false,                                                                    // Default: false
		];

		$this->controls['show_popular_only'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => esc_html__( 'Display Popular Listings Only', 'addonskit-for-bricks' ),
			'type'    => 'checkbox',
			'inline'  => true,
			'small'   => true,
			'default' => false,                                                                   // Default: false
		];

		$this->controls['loggedin_users_only'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => esc_html__( 'Logged In User Can View Only', 'addonskit-for-bricks' ),
			'type'    => 'checkbox',
			'inline'  => true,
			'small'   => true,
			'default' => false,                                                                  // Default: false
		];
	}
	
	protected function get_ready_args() {
		$args = [
			'header'                => $this->get_setting( 'show_header' ) ? 'yes' : 'no',
			'header_title'          => $this->get_setting( 'header_title' ),
			// 'advanced_filter'       => $this->get_setting( 'show_filter_button' ) ? 'yes' : 'no',
			'view'                  => $this->get_setting( 'view' ),
			'map_height'            => $this->get_setting( 'map_height' ),
			'columns'               => $this->get_setting( 'columns' ),
			'listings_per_page'     => $this->get_setting( 'per_page', 6 ),
			'show_pagination'       => $this->get_setting( 'show_pagination' ) ? 'yes' : 'no',
			'featured_only'         => $this->get_setting( 'show_featured_only' ) ? 'yes' : 'no',
			'popular_only'          => $this->get_setting( 'show_popular_only' ) ? 'yes' : 'no',
			'logged_in_user_only'   => $this->get_setting( 'loggedin_users_only' ) ? 'yes' : 'no',
			'display_preview_image' => $this->get_setting( 'show_preview_image' ) ? 'yes' : 'no',
			'orderby'               => $this->get_setting( 'order_by' ),
			'order'                 => $this->get_setting( 'order' ),
		];

		if ( ! empty( $this->get_setting( 'sidebar' ) ) ) {
			$args['sidebar'] = $this->get_setting( 'sidebar' );
		}

		return $args;
	}

	abstract protected static function get_shortcode();

	public function render() {
		echo "<div {$this->render_attributes( '_root' )}>"; 
			Utils::do_shortcode( static::get_shortcode(), $this->get_ready_args() );
		echo '</div>';
	}
}
