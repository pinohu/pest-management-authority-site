<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Bricks\Element;

class BaseElement extends Element {

    public $category = 'directorist_element';
	public $icon     = 'ion-md-star directorist-icon';

    protected function get_setting( $key = '', $default = false ) {
        if ( empty( $key ) || ! isset( $this->settings[ $key ] ) ) {
            return $default;
        }

        return $this->settings[ $key ];
    }
}
