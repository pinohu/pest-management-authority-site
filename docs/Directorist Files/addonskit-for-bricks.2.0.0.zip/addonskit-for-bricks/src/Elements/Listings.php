<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WpWax\AKFB\Support\Utils;

class Listings extends BaseElement {
	use Styles\Container;

	public $name = 'directorist-listings';
	
	public function get_label() {
		return __( 'Listings', 'addonskit-for-bricks' );
	}

	public function get_keywords() {
		return ['all listings', 'search result', 'search form'];
	}

	public function set_control_groups() {
		$this->control_groups['directory_menu'] = [
			'title' => esc_html__( 'Directory Menu', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['searchbar'] = [
			'title' => esc_html__( 'Search Bar', 'addonskit-for-bricks' ),
			'tab'   => 'content',
			'required' => ['sidebar', '!=', 'no_sidebar']
		];

		$this->control_groups['listing_controls'] = [
			'title' => esc_html__( 'Listing Controls', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['listings'] = [
			'title' => esc_html__( 'Listings Layout', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['query'] = [
			'title' => esc_html__( 'Query', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];
	}

	public function set_controls() {
		$this->set_directory_menu_controls( 'directory_menu', 'directory_menu' );
		$this->set_searchbar_controls( 'searchbar', 'searchbar' );
		$this->set_listing_control_controls( 'listing_controls', 'listing_controls' );
		$this->set_listings_controls( 'listings', 'listings' );
		$this->set_query_controls( 'query', 'query' );
	}

	protected function set_directory_menu_controls( $prefix, $group ) {
		if ( ! directorist_is_multi_directory_enabled() ) {
			return;
		}

		$this->controls['directory'] = [
			'tab'         => 'content',
			'group'       => $group,
			'label'       => __( 'Directories', 'addonskit-for-bricks' ),
			'type'        => 'select',
			'options'     => Utils::get_directories(),
			'inline'      => true,
			'placeholder' => esc_html__( 'Select directories', 'addonskit-for-bricks' ),
			'multiple'    => true,
			'searchable'  => true,
			'clearable'   => true,
		];

		$this->controls['default_directory'] = [
			'tab'         => 'content',
			'group'       => $group,
			'label'       => __( 'Default Directory', 'addonskit-for-bricks' ),
			'type'        => 'select',
			'options'     => Utils::get_directories(),
			'inline'      => true,
			'placeholder' => esc_html__( 'Select a directory', 'addonskit-for-bricks' ),
			'multiple'    => false,
			'searchable'  => true,
			'clearable'   => true,
		];

		$this->controls[ $prefix . '_padding'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Padding', 'addonskit-for-bricks' ),
			'type'  => 'spacing',
			'css'   => [
				[
					'property' => 'padding',
					'selector' => '.directorist-type-nav__list .directorist-type-nav__link',
				]
			],
		];

		$this->controls[ $prefix . '_border'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Border', 'addonskit-for-bricks' ),
			'type'  => 'border',
			'css'   => [
				[
					'property' => 'border',
					'selector' => '.directorist-type-nav__list .directorist-type-nav__link',
				],
			],
			'inline' => true,
			'small'  => true,
		];

		$this->controls[$prefix . '_boxshadow'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Box Shadow', 'addonskit-for-bricks' ),
			'type' => 'box-shadow',
			'css' => [
				[
				'property' => 'box-shadow',
				'selector' => '.directorist-type-nav__list .directorist-type-nav__link',
				],
			],
			'inline' => true,
			'small' => true,
		];

		$this->controls[$prefix . '_typography'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Typography', 'addonskit-for-bricks' ),
			'type' => 'typography',
			'css' => [
				[
					'property' => 'typography',
					'selector' => '.directorist-type-nav__list .directorist-type-nav__link',
				],
			],
			'inline' => true,
			'exclude' => [
				'color',
				// 'text-align',
				// 'text-decoration',
			//   'font-family',
			//   'font-weight',
			//   'text-transform',
			//   'font-size',
			//   'line-height',
			//   'letter-spacing',
			//   'text-shadow',
			],
			'popup' => true, // Default: true
		];

		$this->controls[$prefix . '_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'color',
					'selector' => '.directorist-type-nav__list .directorist-type-nav__link',
				],
				[
					'property' => 'background-color',
					'selector' => '.directorist-type-nav__list .directorist-type-nav__link .directorist-icon-mask::after',
				]
			],
		];

		

		$this->controls[$prefix . '_bg_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Background Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'background-color',
					'selector' => '.directorist-type-nav__list .directorist-type-nav__link',
				]
			],
		];

		$this->controls[$prefix . '_icon_size'] = [
			'group' => $group,
			'label' => esc_html__( 'Icon Size', 'addonskit-for-bricks' ),
			'type'  => 'number',
			'css'   => [
				[
					'property' => 'width',
					'selector' => '.directorist-type-nav__list .directorist-type-nav__link .directorist-icon-mask::after',
				],
				[
					'property' => 'height',
					'selector' => '.directorist-type-nav__list .directorist-type-nav__link .directorist-icon-mask::after',
				],
			],
			'units' => true,
		];

		$this->controls[ $prefix . '_icon_padding'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Icon Padding', 'addonskit-for-bricks' ),
			'type'  => 'spacing',
			'css'   => [
				[
					'property' => 'padding',
					'selector' => '.directorist-type-nav__list .directorist-type-nav__link .directorist-icon-mask',
				]
			],
		];
	}

	protected function set_searchbar_controls( $prefix, $group ) {
		$this->set_container_controls( $prefix, $group, '.directorist-basic-search .directorist-search-form__box' );
	}

	protected function set_listing_control_controls( $prefix, $group ) {
		$this->controls['show_header'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => esc_html__( 'Display Controls', 'addonskit-for-bricks' ),
			'type'    => 'checkbox',
			'inline'  => true,
			'small'   => true,
			'default' => true,                                                       // Default: false
		];

		// $this->controls['show_filter_button'] = [
		// 	'tab'      => 'content',
		// 	'group'    => $group,
		// 	'label'    => esc_html__( 'Display Filter Button', 'addonskit-for-bricks' ),
		// 	'type'     => 'checkbox',
		// 	'required' => ['show_header', '=', true],
		// 	'inline'   => true,
		// 	'small'    => true,
		// 	'default'  => false,                                                           // Default: false
		// ];

		$this->controls['header_title'] = [
			'tab'           => 'content',
			'group'         => $group,
			'label'         => esc_html__( 'Listing Count Text', 'addonskit-for-bricks' ),
			'type'          => 'text',
			'spellcheck'    => true,
			'inlineEditing' => false,
			'default'       => __( 'Listings Found', 'addonskit-for-bricks' ),
			'required'      => ['show_header', '=', true],
		];
	}

	protected function set_listings_controls( $prefix, $group ) {
		$this->controls['view'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => __( 'Default View', 'addonskit-for-bricks' ),
			'type'    => 'select',
			'options' => [
				'grid' => __( 'Grid', 'addonskit-for-bricks' ),
				'list' => __( 'List', 'addonskit-for-bricks' ),
				'map'  => __( 'Map', 'addonskit-for-bricks' ),
			],
			'default'     => 'grid',
			'inline'      => true,
			'placeholder' => esc_html__( 'Select a view', 'addonskit-for-bricks' ),
			'multiple'    => false,
			'searchable'  => false,
			'clearable'   => false,
		];
	  
		$this->controls['map_height'] = [
			'tab'      => 'content',
			'group'    => $group,
			'label'    => __( 'Map Height', 'addonskit-for-bricks' ),
			'type'     => 'number',
			'min'      => 300,
			'max'      => 1980,
			'step'     => 10,
			'inline'   => true,
			'default'  => 500,
			'required' => ['view', '=', 'map'],
		];

		$this->controls['columns'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => __( 'Columns', 'addonskit-for-bricks' ),
			'type'    => 'select',
			'options' => [
				'6' => __( '6 Columns', 'addonskit-for-bricks' ),
				'4' => __( '4 Columns', 'addonskit-for-bricks' ),
				'3' => __( '3 Columns', 'addonskit-for-bricks' ),
				'2' => __( '2 Columns', 'addonskit-for-bricks' ),
			],
			'default'     => '3',
			'required'    => ['view', '=', 'grid'],
			'inline'      => true,
			'placeholder' => esc_html__( 'Select column size', 'addonskit-for-bricks' ),
			'multiple'    => false,
			'searchable'  => false,
			'clearable'   => false,
		];

		$this->controls['sidebar'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => __( 'Sidebar Filter', 'addonskit-for-bricks' ),
			'type'    => 'select',
			'inline'  => true,
			'options' => [
				''              => __( 'Default', 'addonskit-for-bricks' ),
				'left_sidebar'  => __( 'Left', 'addonskit-for-bricks' ),
				'right_sidebar' => __( 'Right', 'addonskit-for-bricks' ),
				'no_sidebar'    => __( 'No Sidebar', 'addonskit-for-bricks' ),
			],
		];

		$this->controls['show_preview_image'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => esc_html__( 'Display Preview Image', 'addonskit-for-bricks' ),
			'type'    => 'checkbox',
			'inline'  => true,
			'small'   => true,
			'default' => true,                                                            // Default: false
		];

		$this->controls['show_pagination'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => esc_html__( 'Display Pagination', 'addonskit-for-bricks' ),
			'type'    => 'checkbox',
			'inline'  => true,
			'small'   => true,
			'default' => false,                                                        // Default: false
		];
	}

	protected function set_query_controls( $prefix, $group ) {
		// $this->controls['terms'] = [
		// 	'tab'         => 'content',
		// 	'group'       => $group,
		// 	'label'       => __( 'Terms', 'addonskit-for-bricks' ),
		// 	'description' => __( 'Select listing categories, locations or tags by typing the term name or from the dropdown items.', 'addonskit-for-bricks' ),
		// 	'type'        => 'select',
		// 	'inline'      => false,
		// 	'placeholder' => esc_html__( 'Select terms', 'addonskit-for-bricks' ),
		// 	'multiple'    => true,
		// 	'searchable'  => true,
		// 	'clearable'   => true,
		// 	'optionsAjax' => [
		// 		'action'    => 'bricks_get_terms_options',
		// 		'postTypes' => ['at_biz_dir'],
		// 		'taxonomy'  => [ ATBDP_CATEGORY, ATBDP_LOCATION, ATBDP_TAGS ]
		// 	]
		// ];

		$this->controls['per_page'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => __( 'Number of Listings', 'addonskit-for-bricks' ),
			'type'    => 'number',
			'min'     => 1,
			'max'     => 100,
			'step'    => 1,
			'default' => 6,
			'inline'  => true,
		];

		$this->controls['order_by'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => __( 'Order by', 'addonskit-for-bricks' ),
			'type'    => 'select',
			'options' => [
				'title' => __( 'Title', 'addonskit-for-bricks' ),
				'date'  => __( 'Date', 'addonskit-for-bricks' ),
				'price' => __( 'Price', 'addonskit-for-bricks' ),
			],
			'default'     => 'date',
			'inline'      => true,
			'placeholder' => esc_html__( 'Select order by', 'addonskit-for-bricks' ),
			'multiple'    => false,
			'searchable'  => false,
			'clearable'   => true,
		];

		$this->controls['order'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => __( 'Order', 'addonskit-for-bricks' ),
			'type'    => 'select',
			'options' => [
				'asc'  => __( 'ASC', 'addonskit-for-bricks' ),
				'desc' => __( 'DESC', 'addonskit-for-bricks' ),
			],
			'default'     => 'desc',
			'inline'      => true,
			'placeholder' => esc_html__( 'Select listing order', 'addonskit-for-bricks' ),
			'multiple'    => false,
			'searchable'  => false,
			'clearable'   => true,
		];

		$this->controls['show_featured_only'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => esc_html__( 'Display Featured Listings Only', 'addonskit-for-bricks' ),
			'type'    => 'checkbox',
			'inline'  => true,
			'small'   => true,
			'default' => false,                                                                    // Default: false
		];

		$this->controls['show_popular_only'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => esc_html__( 'Display Popular Listings Only', 'addonskit-for-bricks' ),
			'type'    => 'checkbox',
			'inline'  => true,
			'small'   => true,
			'default' => false,                                                                   // Default: false
		];

		$this->controls['loggedin_users_only'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => esc_html__( 'Logged In User Can View Only', 'addonskit-for-bricks' ),
			'type'    => 'checkbox',
			'inline'  => true,
			'small'   => true,
			'default' => false,                                                                  // Default: false
		];
	}
	
	protected function get_ready_args() {
		$args = [
			'header'            => empty( $this->get_setting( 'show_header' ) ) ? 'no' : 'yes',
			'header_title'      => $this->get_setting( 'header_title' ),
			// 'advanced_filter'   => empty( $this->get_setting( 'show_filter_button' ) ) ? 'no' : 'yes',
			'view'              => $this->get_setting( 'view' ),
			'map_height'        => $this->get_setting( 'map_height' ),
			'columns'           => $this->get_setting( 'columns' ),
			'listings_per_page' => $this->get_setting( 'per_page', 6 ),
			'show_pagination'   => empty( $this->get_setting( 'show_pagination' ) ) ? 'no' : 'yes',
			'featured_only'         => empty( $this->get_setting( 'show_featured_only' ) ) ? 'no' : 'yes',
			'popular_only'          => empty( $this->get_setting( 'show_popular_only' ) ) ? 'no' : 'yes',
			'logged_in_user_only'   => empty( $this->get_setting( 'loggedin_users_only' ) ) ? 'no' : 'yes',
			'display_preview_image' => empty( $this->get_setting( 'show_preview_image' ) ) ? 'no' : 'yes',
			'orderby'               => $this->get_setting( 'order_by' ),
			'order'                 => $this->get_setting( 'order' ),
		];

		if ( ! empty( $this->get_setting( 'sidebar' ) ) ) {
			$args['sidebar'] = $this->get_setting( 'sidebar' );
		}

		if ( directorist_is_multi_directory_enabled() ) {
			$directory = $this->get_setting( 'directory' );

			if ( ! empty( $directory ) ) {
				$args['directory_type'] = is_array( $directory ) ? implode( ',', $directory ) : $directory;
			}
			
			if ( ! empty( $this->get_setting( 'default_directory' ) ) ) {
				$args['default_directory_type'] = $this->get_setting( 'default_directory' );
			}
		}

		$terms = $this->get_setting( 'terms' );
		if ( ! empty( $terms ) ) {
			$terms = Utils::to_term_taxonomy_map( $terms );
			$tax_to_arg = [
				ATBDP_CATEGORY => 'category',
				ATBDP_LOCATION => 'location',
				ATBDP_TAGS     => 'tag',
			];

			foreach ( $terms as $tax => $term_ids ) {
				if ( ! isset( $tax_to_arg[ $tax ] ) ) {
					continue;
				}

				$args[ $tax_to_arg[ $tax ] ] = implode( ',', $term_ids );
			}
		}

		return $args;
	}

	public function render() {
		echo "<div {$this->render_attributes( '_root' )}>";
			Utils::do_shortcode( 'directorist_all_listing', $this->get_ready_args() );
		echo '</div>';
	}
}
