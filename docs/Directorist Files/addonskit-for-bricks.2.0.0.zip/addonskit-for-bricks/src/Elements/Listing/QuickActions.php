<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WpWax\AKFB\Support\Utils;

class QuickActions extends BaseElement {
	
	public $category = 'single';
	public $name     = 'directorist-listing-quickaction';

	public function get_label() {
		return esc_html__( 'Listing Quick Actions', 'addonskit-for-bricks' );
	}

	public function get_keywords() {
		return ['single', 'listing', 'quick', 'action'];
	}

	public function set_control_groups() {}

	public function set_controls() {
		$this->controls['actions'] = [
			'tab'           => 'content',
			'label'         => esc_html__( 'Add & Sort Actions', 'addonskit-for-bricks' ),
			'type'          => 'repeater',
			'titleProperty' => 'action',
			'default'       => [
				['action' => 'bookmark'],
				['action' => 'share'],
				['action' => 'report'],
			],
			'placeholder' => esc_html__( 'An Action', 'addonskit-for-bricks' ),
			'max' => 2,
			'fields'      => [
				'action' => [
					'label'    => esc_html__( 'Action', 'addonskit-for-bricks' ),
					'type'     => 'select',
					'options'  => Utils::get_quick_actions_fields( 'quick-widgets-placeholder' ),
					'multiple' => false,
					'inline'   => true,
				],
			],
		];
	}
	
	public function render() {
		$actions = $this->get_setting( 'actions' );
		$actions = ! empty( $actions ) && is_array( $actions ) ? $actions : [];

		$this->set_attribute( '_root', 'class', 'directorist-flex directorist-align-center directorist-justify-content-between' );

		echo "<div {$this->render_attributes( '_root' )}>";
			echo '<div class="directorist-single-listing-quick-action directorist-flex directorist-align-center directorist-justify-content-between">';
				foreach ( $actions as $action ) {
					if ( empty( $action['action'] ) ) {
						continue;
					}
					
					Utils::load_listing_widget( $action['action'] );
				}
			echo '</div>';
		echo '</div>';
	}
}
