<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WpWax\AKFB\Support\Utils;

class MetaInfo extends BaseElement {
	
	public $category = 'single';
	public $name     = 'directorist-listing-metainfo';
	
	public function get_label() {
		return esc_html__( 'Listing Meta Info', 'addonskit-for-bricks' );
	}

	public function get_keywords() {
		return ['single', 'listing', 'count', 'meta'];
	}

	public function set_control_groups() {}

	public function set_controls() {
		$this->controls['widgets'] = [
			'tab'           => 'content',
			'label'         => esc_html__( 'Add & Sort Meta Info Widgets', 'addonskit-for-bricks' ),
			'type'          => 'repeater',
			'titleProperty' => 'widget',
			'default'       => [
				['widget' => 'ratings_count'],
			],
			'placeholder' => esc_html__( 'A Widget', 'addonskit-for-bricks' ),
			'fields'      => [
				'widget' => [
					'label'    => esc_html__( 'Widget', 'addonskit-for-bricks' ),
					'type'     => 'select',
					'options'  => Utils::get_meta_info_fields( 'more-widgets-placeholder' ),
					'multiple' => false,
					'inline'   => true,
				],
			],
		];
	}
	
	public function render() {
		$widgets = $this->get_setting( 'widgets' );
		$widgets = ! empty( $widgets ) && is_array( $widgets ) ? $widgets : [];

		$this->set_attribute( '_root', 'class', 'directorist-listing-single directorist-listing-single-quickinfo' );

		echo "<div {$this->render_attributes( '_root' )}>";
			echo '<div class="directorist-listing-single__info" style="padding:0;">';
				foreach ( $widgets as $widget ) {
					if ( empty( $widget['widget'] ) ) {
						continue;
					}
					
					Utils::load_listing_widget( $widget['widget'] );
				}
			echo '</div>';
		echo '</div>';
	}
}
