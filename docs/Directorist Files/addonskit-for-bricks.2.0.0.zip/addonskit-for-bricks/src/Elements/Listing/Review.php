<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Review extends BaseElement {
	
	public $category = 'single';
	public $name     = 'directorist-listing-review';

	public function get_label() {
		return esc_html__( 'Listing Review', 'addonskit-for-bricks' );
	}

	public function get_keywords() {
		return ['single', 'listing', 'review', 'comment'];
	}

	public function set_control_groups() {}

	public function set_controls() {}
	
	public function render() {
		if ( ! directorist_is_review_enabled() ) {
			return;
		}

		echo "<div {$this->render_attributes( '_root' )}>";
			comments_template();
		echo '</div>';
	}
}
