<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WpWax\AKFB\Support\Utils;

class SocialMedia extends BaseElement {
	
	public $category = 'single';
	public $name     = 'directorist-listing-social-contact';
	
	public function get_label() {
		return esc_html__( 'Listing Social Media', 'addonskit-for-bricks' );
	}

	public function get_keywords() {
		return ['single', 'listing', 'social', 'media'];
	}

	public function set_control_groups() {}

	public function set_controls() {}
	
	public function render() {
		echo "<div {$this->render_attributes( '_root' )}>";
			if ( Utils::maybe_editor() ) {
				$social = get_post_meta( get_the_ID(), '_social', true );
				if ( empty( $social ) ) {
					printf(
						'<div class="directorist-alert directorist-alert-info" role="alert">
								<span class="directorist-alert-title">%s</span>
								<span class="directorist-alert-description">%s</span>
								</div>',
						__( 'Nothing found!', 'addonskit-for-bricks' ),
						__( 'There is no social item in the current listing.', 'addonskit-for-bricks' )
					);
				}
			}

			Utils::load_listing_field( 'social_info' );
		echo '</div>';
	}
}
