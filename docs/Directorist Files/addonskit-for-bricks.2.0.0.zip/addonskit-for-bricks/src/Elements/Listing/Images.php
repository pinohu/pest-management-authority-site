<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WpWax\AKFB\Support\Utils;
use Directorist\Directorist_Single_Listing;

class Images extends BaseElement {
	
	public $category = 'single';
	public $name     = 'directorist-listing-images';
	
	public function get_label() {
		return esc_html__( 'Listing Images', 'addonskit-for-bricks' );
	}

	public function get_keywords() {
		return ['single', 'listing', 'image', 'gallery'];
	}

	public function set_control_groups() {}

	public function set_controls() {}

	public function enqueue_scripts() {
		wp_enqueue_script( 'directorist-listing-slider' );
		wp_enqueue_script( 'directorist-swiper' );
	}
	
	public function render() {
		$listing = Directorist_Single_Listing::instance( get_the_ID() );
		$args    = [
			'listing' => $listing,
			'data'    => $listing->get_slider_data(),
		];

		echo "<div {$this->render_attributes( '_root' )}>";
			Utils::load_template( 'single/fields/image_upload', $args );
		echo '</div>';
	}
}
