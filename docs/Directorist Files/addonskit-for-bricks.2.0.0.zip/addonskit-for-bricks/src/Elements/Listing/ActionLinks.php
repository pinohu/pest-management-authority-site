<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WpWax\AKFB\Support\Utils;
use Directorist\Directorist_Single_Listing;

class ActionLinks extends BaseElement {
	
	public $category = 'single';
	public $name     = 'directorist-listing-actionlinks';
	
	public function get_label() {
		return esc_html__( 'Listing Action Links', 'addonskit-for-bricks' );
	}

	public function get_keywords() {
		return ['single', 'listing', 'link', 'action'];
	}

	public function set_control_groups() {}

	public function set_controls() {
		$this->controls['actions'] = [
			'label'    => esc_html__( 'Action Links', 'addonskit-for-bricks' ),
			'type'     => 'select',
			'multiple' => true,
			'inline'   => true,
			'options'  => [
				'back'     => esc_html_x( 'Back', 'Edit action name', 'addonskit-for-bricks' ),
				'edit'     => esc_html_x( 'Edit', 'Edit action name', 'addonskit-for-bricks' ),
				'continue' => esc_html_x( 'Continue', 'Edit action name', 'addonskit-for-bricks' ),
			],
			'default'     => ['back', 'edit', 'continue'],
			'placeholder' => esc_html__( 'Select actions', 'addonskit-for-bricks' ),
			'description' => esc_html__( 'In the editor you will see all the action links even when you unselect them!', 'addonskit-for-bricks' ),
		];
	}
	
	public function render() {
		$actions = $this->get_setting( 'actions' );
		$actions = ( ! empty( $actions ) && is_array( $actions ) ) ? $actions : [];

		echo "<div {$this->render_attributes( '_root' )}>";
			$this->view( $actions );
		echo '</div>';
	}

	protected function view( $actions ) {
		$listing = Directorist_Single_Listing::instance( get_the_ID() );
		$is_edit = Utils::maybe_editor();

		?>
		<div class="directorist-single-listing-top directorist-flex directorist-align-center directorist-justify-content-between">
			<?php if ( $is_edit || ( $listing->display_back_link() && ( empty( $actions ) || in_array( 'back', $actions, true ) ) ) ): ?>
				<a href="javascript:history.back()" class="directorist-single-listing-action directorist-return-back directorist-btn directorist-btn-sm directorist-btn-light">
					<?php directorist_icon( 'las la-arrow-left' );?>
					<span class="directorist-single-listing-action__text"><?php esc_html_e( 'Go Back', 'addonskit-for-bricks' );?></span>
				</a>
			<?php endif;?>

			<div class="directorist-single-listing-quick-action directorist-flex directorist-align-center directorist-justify-content-between">

				<?php if ( $is_edit || ( $listing->submit_link() && ( empty( $actions ) || in_array( 'continue', $actions, true ) ) ) ): ?>
					<a href="<?php echo esc_url( $listing->submit_link() ); ?>" class="directorist-single-listing-action directorist-btn directorist-btn-sm directorist-btn-light directorist-signle-listing-top__btn-continue">
						<span class="directorist-single-listing-action__text"><?php esc_html_e( 'Continue', 'addonskit-for-bricks' );?></span>
					</a>
				<?php endif;?>

				<?php if ( $is_edit || ( empty( $actions ) || in_array( 'edit', $actions, true ) ) ): ?>
					<a href="<?php echo esc_url( $listing->edit_link() ) ?>" class="directorist-single-listing-action directorist-btn directorist-btn-sm directorist-btn-light directorist-signle-listing-top__btn-edit">
						<?php directorist_icon( 'las la-pen' );?>
						<span class="directorist-single-listing-action__text"><?php esc_html_e( 'Edit', 'addonskit-for-bricks' );?></span>
					</a>
				<?php endif;?>

			</div>
		</div>
		<?php
	}
}
