<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WpWax\AKFB\Support\Utils;

class Map extends BaseElement {
	
	public $category = 'single';
	public $name     = 'directorist-listing-map';
	
	public function get_label() {
		return esc_html__( 'Listing Map', 'addonskit-for-bricks' );
	}

	public function get_keywords() {
		return ['single', 'listing', 'map', 'address'];
	}

	public function set_control_groups() {}

	public function set_controls() {}

    public function enqueue_scripts() {
        if ( 'openstreet' === get_directorist_option( 'select_listing_map', 'openstreet' ) ) {
            wp_enqueue_script( 'directorist-openstreet-map' );
        } else {
            wp_enqueue_script( 'directorist-google-map' );
        }
    }
	
	public function render() {
		echo "<div {$this->render_attributes( '_root' )}>";
			Utils::load_listing_field( 'map' );
		echo '</div>';
	}
}
