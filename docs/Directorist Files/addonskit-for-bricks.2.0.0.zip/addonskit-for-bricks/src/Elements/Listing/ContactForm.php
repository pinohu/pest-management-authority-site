<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WpWax\AKFB\Support\Utils;

class ContactForm extends BaseElement {
	
	public $category = 'single';
	public $name     = 'directorist-listing-contact-form';
	
	public function get_label() {
		return esc_html__( 'Listing Contact Form', 'addonskit-for-bricks' );
	}

	public function get_keywords() {
		return ['single', 'listing', 'contact', 'form', 'directorist', 'directory'];
	}

	public function set_control_groups() {}

	public function set_controls() {
		$this->controls['section_title'] = [
			'tab'     => 'content',
			'label'   => esc_html__( 'Section Title', 'addonskit-for-bricks' ),
			'type'    => 'text',
			'default' => esc_html__( 'Contact Listings Owner Form', 'addonskit-for-bricks' ),
		];
	}
	
	public function render() {
        $args = [
            'type'        => 'section',
            'widget_name' => 'contact_listings_owner',
            'label'       => $this->get_setting( 'section_title' ),
        ];

        $this->set_attribute( '_root', 'class', 'directorist-single-wrapper' );

		echo "<div {$this->render_attributes( '_root' )}>";
            Utils::load_listing_section( $args );
		echo '</div>';
	}
}
