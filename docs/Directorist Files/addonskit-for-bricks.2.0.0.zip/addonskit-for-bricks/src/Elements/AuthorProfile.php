<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WpWax\AKFB\Support\Utils;

class AuthorProfile extends BaseElement {
	use Styles\Container;

	public $name = 'directorist-author-profile';
	
	public function get_label() {
		return esc_html__( 'Author Profile', 'addonskit-for-bricks' );
	}

	public function get_keywords() {
		return ['author profile', 'owner profile'];
	}

	public function set_control_groups() {
		// $this->control_groups['directory_menu'] = [
		// 	'title' => esc_html__( 'Directory Menu', 'addonskit-for-bricks' ),
		// 	'tab'   => 'content',
		// ];

		// $this->control_groups['directory_menu_item'] = [
		// 	'title' => esc_html__( 'Menu Item', 'addonskit-for-bricks' ),
		// 	'tab'   => 'content',
		// ];

		// $this->control_groups['layout'] = [
		// 	'title' => esc_html__( 'Layout & Query', 'addonskit-for-bricks' ),
		// 	'tab'   => 'content',
		// ];
	}

	public function set_controls() {
		$this->controls['loggedin_users_only'] = [
			'tab'     => 'content',
			'label'   => esc_html__( 'Logged In User Can View Only', 'addonskit-for-bricks' ),
			'type'    => 'checkbox',
			'inline'  => true,
			'small'   => true,
			'default' => false,                                           // Default: false
		];
	}
	
	public function render() {
		$params = [
			'logged_in_user_only' => empty( $this->get_setting( 'loggedin_users_only' ) ) ? 'no' : 'yes',
		];

		echo "<div {$this->render_attributes( '_root' )}>";
			Utils::do_shortcode( 'directorist_author_profile', $params );
		echo '</div>';
	}
}
