<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SingleCategory extends SingleTerm {

	public $name = 'directorist-category';

	public function get_label() {
		return __( 'Single Category', 'addonskit-for-bricks' );
	}

	protected static function get_shortcode() {
		return 'directorist_category';
	}
}
