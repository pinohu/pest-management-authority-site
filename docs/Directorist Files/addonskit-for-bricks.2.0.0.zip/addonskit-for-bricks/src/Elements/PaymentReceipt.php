<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WpWax\AKFB\Support\Utils;

class PaymentReceipt extends BaseElement {
	use Styles\Container;

	public $name = 'directorist-receipt';
	
	public function get_label() {
		return esc_html__( 'Payment Receipt', 'addonskit-for-bricks' );
	}

	public function get_keywords() {
		return ['cart', 'checkout', 'payment', 'receipt'];
	}

	public function set_control_groups() {}

	public function set_controls() {}
	
	public function render() {
		echo "<div {$this->render_attributes( '_root' )}>";
			Utils::do_shortcode( 'directorist_payment_receipt' );
		echo '</div>';
	}
}
