<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WpWax\AKFB\Support\Utils;

class Categories extends BaseElement {
	use Styles\Container;

	public $name     = 'directorist-categories';
	
	public function get_label() {
		return esc_html__( 'Categories', 'addonskit-for-bricks' );
	}

	public function get_keywords() {
		return ['all categories'];
	}

	public function set_control_groups() {
		$this->control_groups['directory_menu'] = [
			'title' => esc_html__( 'Directory Menu', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		// $this->control_groups['directory_menu_item'] = [
		// 	'title' => esc_html__( 'Menu Item', 'addonskit-for-bricks' ),
		// 	'tab'   => 'content',
		// ];

		$this->control_groups['layout'] = [
			'title' => esc_html__( 'Layout & Query', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];
	}

	public function set_controls() {
		  /**
			* Group: directory_menu
		 */
		if ( directorist_is_multi_directory_enabled() ) {
			$this->controls['directory'] = [
				'tab'         => 'content',
				'group'       => 'directory_menu',
				'label'       => __( 'Directories', 'addonskit-for-bricks' ),
				'type'        => 'select',
				'options'     => Utils::get_directories(),
				'inline'      => true,
				'placeholder' => esc_html__( 'Select directories', 'addonskit-for-bricks' ),
				'multiple'    => true,
				'searchable'  => true,
				'clearable'   => true,
			];

			$this->controls['default_directory'] = [
				'tab'         => 'content',
				'group'       => 'directory_menu',
				'label'       => __( 'Default Directory', 'addonskit-for-bricks' ),
				'type'        => 'select',
				'options'     => [ 'all' => esc_html__( 'All', 'addonskit-for-bricks' ) ] + Utils::get_directories(),
				'inline'      => true,
				'placeholder' => esc_html__( 'Select a directory', 'addonskit-for-bricks' ),
				'multiple'    => false,
				'searchable'  => true,
				'clearable'   => true,
				'default'     => 'all'
			];

			$this->controls['nav_align'] = [
				'tab'   => 'content',
				'group' => 'directory_menu',
				'label' => esc_html__( 'Alignment', 'addonskit-for-bricks' ),
				'type'  => 'justify-content',
				'css'   => [
					[
						'property' => 'justify-content',
						'selector' => '.directorist-type-nav .directorist-type-nav__list',
					],
				],
			];

			// $this->set_container_contorls( 'directory_menu', 'directory_menu_item', '.directorist-type-nav__list' );
		}

		  /**
			* Group: layout
		 */
		$this->controls['view'] = [
			'tab'     => 'content',
			'group'   => 'layout',
			'label'   => __( 'Layout', 'addonskit-for-bricks' ),
			'type'    => 'select',
			'options' => [
				'grid' => __( 'Grid', 'addonskit-for-bricks' ),
				'list' => __( 'List', 'addonskit-for-bricks' ),
			],
			'default'     => 'grid',
			'inline'      => true,
			'placeholder' => esc_html__( 'Select a layout', 'addonskit-for-bricks' ),
			'multiple'    => false,
			'searchable'  => false,
			'clearable'   => false,
		];

		$this->controls['columns'] = [
			'tab'     => 'content',
			'group'   => 'layout',
			'label'   => __( 'Columns', 'addonskit-for-bricks' ),
			'type'    => 'select',
			'options' => [
				'6' => __( '6 Columns', 'addonskit-for-bricks' ),
				'5' => __( '5 Columns', 'addonskit-for-bricks' ),
				'4' => __( '4 Columns', 'addonskit-for-bricks' ),
				'3' => __( '3 Columns', 'addonskit-for-bricks' ),
				'2' => __( '2 Columns', 'addonskit-for-bricks' ),
			],
			'default'     => 4,
			'required'    => ['view', '=', 'grid'],
			'inline'      => true,
			'placeholder' => esc_html__( 'Select column size', 'addonskit-for-bricks' ),
			'multiple'    => false,
			'searchable'  => false,
			'clearable'   => false,
		];

		$this->controls['display_selected'] = [
			'tab'     => 'content',
			'group'   => 'layout',
			'label'   => esc_html__( 'Display Selected Only', 'addonskit-for-bricks' ),
			'type'    => 'checkbox',
			'inline'  => true,
			'small'   => true,
			'default' => false,                                           // Default: false
		];

		$this->controls['selected_categories'] = [
			'group'       => 'layout',
			'description' => __( 'Select categories from dropdown.', 'addonskit-for-bricks' ),
			'type'        => 'select',
			'inline'      => false,
			'placeholder' => esc_html__( 'Select categories', 'addonskit-for-bricks' ),
			'multiple'    => true,
			'searchable'  => true,
			'clearable'   => true,
			'optionsAjax' => [
				'action'    => 'bricks_get_terms_options',
				'postTypes' => [ ATBDP_POST_TYPE ],
				'taxonomy'  => [ ATBDP_CATEGORY ]
			],
			'required' => ['display_selected', '=', true],
		];

		$this->controls['per_page'] = [
			'tab'     => 'content',
			'group'   => 'layout',
			'label'   => __( 'Number of Categories', 'addonskit-for-bricks' ),
			'type'    => 'number',
			'min'     => 1,
			'max'     => 100,
			'step'    => 1,
			'default' => 8,
			'inline'  => true,
		];

		$this->controls['order_by'] = [
			'tab'     => 'content',
			'group'   => 'layout',
			'label'   => __( 'Order by', 'addonskit-for-bricks' ),
			'type'    => 'select',
			'options' => [
				'id'       => __( 'ID', 'addonskit-for-bricks' ),
				'count'    => __( 'Count', 'addonskit-for-bricks' ),
				'name'     => __( 'Name', 'addonskit-for-bricks' ),
				'slug'     => __( 'Slug', 'addonskit-for-bricks' ),
				'slug__in' => __( 'Selected', 'addonskit-for-bricks' ),
			],
			'default'     => 'id',
			'inline'      => true,
			'placeholder' => esc_html__( 'Select order by', 'addonskit-for-bricks' ),
			'multiple'    => false,
			'searchable'  => false,
			'clearable'   => true,
		];

		$this->controls['order'] = [
			'tab'     => 'content',
			'group'   => 'layout',
			'label'   => __( 'Order', 'addonskit-for-bricks' ),
			'type'    => 'select',
			'options' => [
				'asc'  => __( 'ASC', 'addonskit-for-bricks' ),
				'desc' => __( 'DESC', 'addonskit-for-bricks' ),
			],
			'default'     => 'desc',
			'inline'      => true,
			'placeholder' => esc_html__( 'Select order', 'addonskit-for-bricks' ),
			'multiple'    => false,
			'searchable'  => false,
			'clearable'   => true,
		];

		$this->controls['loggedin_users_only'] = [
			'tab'     => 'content',
			'group'   => 'layout',
			'label'   => esc_html__( 'Logged In User Can View Only', 'addonskit-for-bricks' ),
			'type'    => 'checkbox',
			'inline'  => true,
			'small'   => true,
			'default' => false,                                           // Default: false
		];
	}
	
	public function render() {
		$args = [
			'view'                => $this->get_setting( 'view', 'grid' ),
			'columns'             => $this->get_setting( 'columns', 4 ),
			'cat_per_page'        => $this->get_setting( 'per_page', 8 ),
			'orderby'             => $this->get_setting( 'order_by', 'id' ),
			'order'               => $this->get_setting( 'order', 'desc' ),
			'logged_in_user_only' => empty( $this->get_setting( 'loggedin_users_only' ) ) ? 'no' : 'yes',
		];

		if ( $this->get_setting( 'display_selected', false ) ) {
			$selected_categories = Utils::to_term_slugs( $this->get_setting( 'selected_categories' ), ATBDP_CATEGORY );

			if ( ! empty( $selected_categories ) ) {
				$args['slug'] = implode( ',', $selected_categories );
			}
		}

		if ( directorist_is_multi_directory_enabled() ) {
			$directory = $this->get_setting( 'directory' );
			
			if ( ! empty( $directory ) ) {
				$args['directory_type'] = is_array( $directory ) ? implode( ',', $directory ) : $directory;
			}
			
			if ( ! empty( $this->get_setting( 'default_directory' ) ) ) {
				$args['default_directory_type'] = $this->get_setting( 'default_directory' );
			}
		}

		echo "<div {$this->render_attributes( '_root' )}>";
			Utils::do_shortcode( 'directorist_all_categories', $args );
		echo '</div>';
	}
}
