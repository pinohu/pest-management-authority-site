<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ATBDP_Permalink;
use Directorist\Helper;
use WpWax\AKFB\Support\Utils;

class SigninSignup extends BaseElement {

	public $name = 'directorist-signin-signup';
	
	public function get_label() {
		return esc_html__( 'Signin - Signup', 'addonskit-for-bricks' );
	}

	public function get_keywords() {
		return ['registration', 'signup', 'login', 'signin'];
	}

	public function set_control_groups() {
		  // Sign-In Settings Group
		$this->control_groups['signin_settings'] = [
			'tab'   => 'content',
			'title' => esc_html__('Sign-In Settings', 'addonskit-for-bricks')
		];
	
		  // Sign-Up Settings Group
		$this->control_groups['signup_settings'] = [
			'tab'   => 'content',
			'title' => esc_html__('Sign-Up Settings', 'addonskit-for-bricks')
		];

		// User Role Settings Group
		$this->control_groups['user_role_settings'] = [
			'tab'   => 'content',
			'title' => esc_html__('User Role Settings', 'addonskit-for-bricks'),
		];
	
		// Website Settings Group
		$this->control_groups['website_settings'] = [
			'tab'   => 'content',
			'title' => esc_html__('Website Settings', 'addonskit-for-bricks'),
		];
	
		// Name Fields Group
		$this->control_groups['name_fields'] = [
			'tab'   => 'content',
			'title' => esc_html__('Name Fields', 'addonskit-for-bricks'),
		];
	
		// Bio Settings Group
		$this->control_groups['bio_settings'] = [
			'tab'   => 'content',
			'title' => esc_html__('Bio Settings', 'addonskit-for-bricks'),
		];
	
		// Privacy & Terms Group
		$this->control_groups['privacy_terms'] = [
			'tab'   => 'content',
			'title' => esc_html__('Privacy & Terms', 'addonskit-for-bricks'),
		];
	
		// Recovery Password Settings Group
		$this->control_groups['recovery_password_settings'] = [
			'tab'   => 'content',
			'title' => esc_html__('Recovery Password Settings', 'addonskit-for-bricks'),
		];
	}

	public function set_controls() {
		$this->set_signin_controls();
		$this->set_signup_controls();
		$this->set_user_role_controls();
		$this->set_website_controls();
		$this->set_name_controls();
		$this->set_bio_controls();
		$this->set_terms_privacy_controls();
		$this->set_password_recovery_controls();
	}

	protected function set_signin_controls() {
		$this->controls['signin_username_label'] = [
			'group'   => 'signin_settings',
			'label'   => esc_html__('Username Label', 'addonskit-for-bricks'),
			'type'    => 'text',
			'default' => 'Enter your username',
		];
	
		$this->controls['password_label'] = [
			'group'   => 'signin_settings',
			'label'   => esc_html__('Password Label', 'addonskit-for-bricks'),
			'type'    => 'text',
			'default' => 'Enter your password',
		];
	
		$this->controls['signin_button_label'] = [
			'group'   => 'signin_settings',
			'label'   => esc_html__('Button Label', 'addonskit-for-bricks'),
			'type'    => 'text',
			'default' => 'Sign In',
		];
	
		$this->controls['signup_linking_text'] = [
			'group'   => 'signin_settings',
			'label'   => esc_html__('Sign Up Linking Text', 'addonskit-for-bricks'),
			'type'    => 'text',
			'default' => "Don't have an account? Sign up",
		];
	
		$this->controls['recovery_password_label'] = [
			'group'   => 'signin_settings',
			'label'   => esc_html__('Recovery Password Label', 'addonskit-for-bricks'),
			'type'    => 'text',
			'default' => 'Forgot Password?',
		];
	}

	protected function set_signup_controls() {
		// Sign-Up Settings Controls
		$this->controls['signup_preview'] = [
			'group'       => 'signup_settings',
			'label'       => esc_html__('Display Sign-Up Preview', 'addonskit-for-bricks'),
			'description' => esc_html__('This preview is editor only.',  'addonskit-for-bricks'),
			'type'        => 'checkbox',
			'default'     => false,
		];

		$this->controls['username_label'] = [
			'group'    => 'signup_settings',
			'label'    => esc_html__('Username Label', 'addonskit-for-bricks'),
			'type'     => 'text',
			'default'  => 'Enter username',
		];
	
		$this->controls['password'] = [
			'group'    => 'signup_settings',
			'label'    => esc_html__('Display Password Field', 'addonskit-for-bricks'),
			'type'     => 'checkbox',
			'default'  => false,
		];
	
		$this->controls['email_label'] = [
			'group'    => 'signup_settings',
			'label'    => esc_html__('Email Label', 'addonskit-for-bricks'),
			'type'     => 'text',
			'default'  => 'Enter email',
		];
	
		$this->controls['signup_button_label'] = [
			'group'    => 'signup_settings',
			'label'    => esc_html__('Button Label', 'addonskit-for-bricks'),
			'type'     => 'text',
			'default'  => 'Sign Up',
		];

		$this->controls['signin_after_signup'] = [
			'group' => 'signup_settings',
			'label' => esc_html__('Auto Sign In After Sign Up', 'addonskit-for-bricks'),
			'type' => 'checkbox',
			'default' => false,
		];

		$this->controls['signup_redirect_url'] = [
			'group' => 'signup_settings',
			'label' => esc_html__('Sign-Up Redirect URL', 'addonskit-for-bricks'),
			'type' => 'text',
			'default' => '',
		];

		$this->controls['signin_message'] = [
			'group' => 'signup_settings',
			'label' => esc_html__('Sign-In Success Message', 'addonskit-for-bricks'),
			'type' => 'text',
			'default' => 'You have successfully signed in!',
		];

		$this->controls['signin_linking_text'] = [
			'group' => 'signup_settings',
			'label' => esc_html__('Sign-In Linking Text', 'addonskit-for-bricks'),
			'type' => 'text',
			'default' => 'Already have an account? Sign in here',
		];
	}
	
	protected function set_user_role_controls() {
		  // User Role Settings Controls
		$this->controls['user_role'] = [
			'group'   => 'user_role_settings',
			'label'   => esc_html__('User Role', 'addonskit-for-bricks'),
			'type'    => 'checkbox',
			'default' => false,
		];
	
		$this->controls['author_role_label'] = [
			'group'   => 'user_role_settings',
			'label'   => esc_html__('Author Role Label', 'addonskit-for-bricks'),
			'type'    => 'text',
			'default' => 'Author',
		];
	
		$this->controls['user_role_label'] = [
			'group'   => 'user_role_settings',
			'label'   => esc_html__('User Role Label', 'addonskit-for-bricks'),
			'type'    => 'text',
			'default' => 'User',
		];
	}

	protected function set_website_controls() {
		  // Website Settings Controls
		$this->controls['website'] = [
			'group'   => 'website_settings',
			'label'   => esc_html__('Display Website Field', 'addonskit-for-bricks'),
			'type'    => 'checkbox',
			'default' => false,
		];
	
		$this->controls['website_label'] = [
			'group'   => 'website_settings',
			'label'   => esc_html__('Website Label', 'addonskit-for-bricks'),
			'type'    => 'text',
			'default' => 'Website',
		];
	
		$this->controls['website_required'] = [
			'group'   => 'website_settings',
			'label'   => esc_html__('Require Website', 'addonskit-for-bricks'),
			'type'    => 'checkbox',
			'default' => false,
		];
	}

	protected function set_name_controls() {
		  // Name Fields Controls
		$this->controls['firstname'] = [
			'group'   => 'name_fields',
			'label'   => esc_html__('Display First Name Field', 'addonskit-for-bricks'),
			'type'    => 'checkbox',
			'default' => false,
		];
	
		$this->controls['firstname_label'] = [
			'group'   => 'name_fields',
			'label'   => esc_html__('First Name Label', 'addonskit-for-bricks'),
			'type'    => 'text',
			'default' => 'First Name',
		];
	
		$this->controls['firstname_required'] = [
			'group'   => 'name_fields',
			'label'   => esc_html__('Require First Name', 'addonskit-for-bricks'),
			'type'    => 'checkbox',
			'default' => false,
		];
	
		$this->controls['lastname'] = [
			'group'   => 'name_fields',
			'label'   => esc_html__('Display Last Name Field', 'addonskit-for-bricks'),
			'type'    => 'checkbox',
			'default' => false,
		];
	
		$this->controls['lastname_label'] = [
			'group'   => 'name_fields',
			'label'   => esc_html__('Last Name Label', 'addonskit-for-bricks'),
			'type'    => 'text',
			'default' => 'Last Name',
		];
	
		$this->controls['lastname_required'] = [
			'group'   => 'name_fields',
			'label'   => esc_html__('Require Last Name', 'addonskit-for-bricks'),
			'type'    => 'checkbox',
			'default' => false,
		];
	}

	protected function set_bio_controls() {
		  // Bio Settings Controls
		$this->controls['bio'] = [
			'group'   => 'bio_settings',
			'label'   => esc_html__('Display Bio Field', 'addonskit-for-bricks'),
			'type'    => 'checkbox',
			'default' => false,
		];
	
		$this->controls['bio_label'] = [
			'group'   => 'bio_settings',
			'label'   => esc_html__('Bio Label', 'addonskit-for-bricks'),
			'type'    => 'text',
			'default' => 'Bio',
		];

		$this->controls['bio_required'] = [
			'group'   => 'bio_settings',
			'label'   => esc_html__('Require Bio', 'addonskit-for-bricks'),
			'type'    => 'checkbox',
			'default' => false,
		];
	}

	protected function set_terms_privacy_controls() {
		  // Privacy & Terms Controls
		$this->controls['privacy'] = [
			'group'   => 'privacy_terms',
			'label'   => esc_html__('Enable Privacy Agreement', 'addonskit-for-bricks'),
			'type'    => 'checkbox',
			'default' => false,
		];
	
		$this->controls['privacy_label'] = [
			'group'   => 'privacy_terms',
			'label'   => esc_html__('Privacy Label', 'addonskit-for-bricks'),
			'type'    => 'text',
			'default' => 'I agree to the Privacy Policy',
		];
	
		$this->controls['privacy_linking_text'] = [
			'group'   => 'privacy_terms',
			'label'   => esc_html__('Privacy Linking Text', 'addonskit-for-bricks'),
			'type'    => 'text',
			'default' => 'Privacy Policy',
		];
	
		$this->controls['terms'] = [
			'group'   => 'privacy_terms',
			'label'   => esc_html__('Enable Terms Agreement', 'addonskit-for-bricks'),
			'type'    => 'checkbox',
			'default' => false,
		];
	
		$this->controls['terms_label'] = [
			'group'   => 'privacy_terms',
			'label'   => esc_html__('Terms Label', 'addonskit-for-bricks'),
			'type'    => 'text',
			'default' => 'I agree to the Terms and Conditions',
		];
	
		$this->controls['terms_linking_text'] = [
			'group'   => 'privacy_terms',
			'label'   => esc_html__('Terms Linking Text', 'addonskit-for-bricks'),
			'type'    => 'text',
			'default' => 'Terms and Conditions',
		];		
	}

	protected function set_password_recovery_controls() {
		  // Recovery Password Settings Controls
		$this->controls['recovery_password_linking_text'] = [
			'group'   => 'recovery_password_settings',
			'label'   => esc_html__('Recovery Password Linking Text', 'addonskit-for-bricks'),
			'type'    => 'text',
			'default' => 'Forgot your password? Click here',
		];
	}

	public function render() {
		$defaults = array(
			'active_form'          => 'signin',
			'user_role'            => get_directorist_option( 'display_user_type', false ) ? 'yes' : 'no',
			'author_role_label'    => __( 'I am an author', 'addonskit-for-bricks' ),
			'user_role_label'      => __( 'I am a user', 'addonskit-for-bricks' ),
			'username_label'       => get_directorist_option( 'reg_username', __( 'Username', 'addonskit-for-bricks' ) ),
			'password'             => get_directorist_option( 'display_password_reg', true ) ? 'yes' : 'no',
			'password_label'       => get_directorist_option( 'reg_password', __( 'Password', 'addonskit-for-bricks' ) ),
			'email_label'          => get_directorist_option( 'reg_email', __( 'Email ', 'addonskit-for-bricks' ) ),
			'website'              => get_directorist_option( 'display_website_reg', false ) ? 'yes' : 'no',
			'website_label'        => get_directorist_option( 'reg_website', __( 'Website', 'addonskit-for-bricks' ) ),
			'website_required'     => get_directorist_option( 'require_website_reg', false ) ? 'yes' : 'no',
			'firstname'            => get_directorist_option( 'display_fname_reg', false ) ? 'yes' : 'no',
			'firstname_label'      => get_directorist_option( 'reg_fname', __( 'First Name', 'addonskit-for-bricks' ) ),
			'firstname_required'   => get_directorist_option( 'require_fname_reg', false ) ? 'yes' : 'no',
			'lastname'             => get_directorist_option( 'display_lname_reg', false ) ? 'yes' : 'no',
			'lastname_label'       => get_directorist_option( 'reg_lname', __( 'Last Name', 'addonskit-for-bricks' ) ),
			'lastname_required'    => get_directorist_option( 'require_lname_reg', false ) ? 'yes' : 'no',
			'bio'                  => get_directorist_option( 'display_bio_reg', 0 ) ? 'yes' : 'no',
			'bio_label'            => get_directorist_option( 'reg_bio', __( 'About/bio', 'addonskit-for-bricks' ) ),
			'bio_required'         => get_directorist_option( 'require_bio_reg', 0 ) ? 'yes' : 'no',
			'privacy'              => get_directorist_option( 'registration_privacy', 1 ) ? 'yes' : 'no',
			'privacy_label'        => get_directorist_option( 'registration_privacy_label', __( 'I agree to the', 'addonskit-for-bricks' ) ),
			'privacy_linking_text' => get_directorist_option( 'registration_privacy_label_link', __('Privacy & Policy', 'addonskit-for-bricks') ),
			'terms'                => get_directorist_option( 'regi_terms_condition', 1 ) ? 'yes' : 'no',
			'terms_label'          => get_directorist_option( 'regi_terms_label', __( 'I agree with all', 'addonskit-for-bricks' ) ),
			'terms_linking_text'   => get_directorist_option( 'regi_terms_label_link', 'terms & conditions' ),
			'signup_button_label'  => get_directorist_option( 'reg_signup', __( 'Sign Up', 'addonskit-for-bricks' ) ),
			'signin_message'       => get_directorist_option( 'login_text', __( 'Already have an account? Please Sign in', 'addonskit-for-bricks' ) ),
			'signin_linking_text'  => get_directorist_option( 'log_linkingmsg', __( 'Here', 'addonskit-for-bricks' ) ),
			'signin_after_signup'  => get_directorist_option( 'auto_login', 0 ) ? 'yes' : 'no',
			'signup_redirect_url'  => '',
			// login atts
			'signin_username_label' => get_directorist_option( 'log_username', __( 'Username or Email Address', 'addonskit-for-bricks' ) ),
			'signin_button_label'   => get_directorist_option( 'log_button', __( 'Sign In', 'addonskit-for-bricks' ) ),
			'signup_label'          => get_directorist_option( 'reg_text', __( "Don't have an account?", 'addonskit-for-bricks' ) ),
			'signup_linking_text'   => get_directorist_option( 'reg_linktxt', __( 'Sign Up', 'addonskit-for-bricks' ) ),
			// recover password atts
			'enable_recovery_password'            => get_directorist_option( 'display_recpass', 1 ) ? 'yes' : 'no',
			'recovery_password_label'             => get_directorist_option( 'recpass_text', __( 'Forgot Password?', 'addonskit-for-bricks' ) ),
			'recovery_password_description'       => get_directorist_option( 'recpass_desc', __( 'Lost your password? Please enter your email address. You will receive a link to create a new password via email.', 'addonskit-for-bricks' ) ),
			'recovery_password_email_label'       => get_directorist_option( 'recpass_username', __( 'E-mail:', 'addonskit-for-bricks' ) ),
			'recovery_password_email_placeholder' => get_directorist_option( 'recpass_placeholder', __( 'eg. mail@example.com', 'addonskit-for-bricks' ) ),
			'recovery_password_button_label'      => get_directorist_option( 'recpass_button', __( 'Get New Password', 'addonskit-for-bricks' ) ),
			'user_type'                           => ''
		);

		$atts = wp_parse_args( array(
			'user_role'            => $this->get_setting( 'user_role' ),
			'author_role_label'    => $this->get_setting( 'author_role_label' ),
			'user_role_label'      => $this->get_setting( 'user_role_label' ),
			'username_label'       => $this->get_setting( 'username_label' ),
			'password'             => $this->get_setting( 'password' ),
			'password_label'       => $this->get_setting( 'password_label' ),
			'email_label'          => $this->get_setting( 'email_label' ),
			'website'              => $this->get_setting( 'website' ),
			'website_label'        => $this->get_setting( 'website_label' ),
			'website_required'     => $this->get_setting( 'website_required' ),
			'firstname'            => $this->get_setting( 'firstname' ),
			'firstname_label'      => $this->get_setting( 'firstname_label' ),
			'firstname_required'   => $this->get_setting( 'firstname_required' ),
			'lastname'             => $this->get_setting( 'lastname' ),
			'lastname_label'       => $this->get_setting( 'lastname_label' ),
			'lastname_required'    => $this->get_setting( 'lastname_required' ),
			'bio'                  => $this->get_setting( 'bio' ),
			'bio_label'            => $this->get_setting( 'bio_label' ),
			'bio_required'         => $this->get_setting( 'bio_required' ),
			'privacy'              => $this->get_setting( 'privacy' ),
			'privacy_label'        => $this->get_setting( 'privacy_label' ),
			'privacy_linking_text' => $this->get_setting( 'privacy_linking_text' ),
			'terms'                => $this->get_setting( 'terms' ),
			'terms_label'          => $this->get_setting( 'terms_label' ),
			'terms_linking_text'   => $this->get_setting( 'terms_linking_text' ),
			'signup_button_label'  => $this->get_setting( 'signup_button_label' ),
			'signin_message'       => $this->get_setting( 'signin_message' ),
			'signin_linking_text'  => $this->get_setting( 'signin_linking_text' ),
			'signin_after_signup'  => $this->get_setting( 'signin_after_signup' ),
			'signup_redirect_url'  => $this->get_setting( 'signup_redirect_url' ),
			// login atts
			'signin_username_label' => $this->get_setting( 'signin_username_label' ),
			'signin_button_label'   => $this->get_setting( 'signin_button_label' ),
			'signup_label'          => $this->get_setting( 'signup_label' ),
			'signup_linking_text'   => $this->get_setting( 'signup_linking_text' ),
			// recover password atts
			'enable_recovery_password'            => $this->get_setting( 'enable_recovery_password' ),
			'recovery_password_label'             => $this->get_setting( 'recovery_password_label' ),
			'recovery_password_description'       => $this->get_setting( 'recovery_password_description' ),
			'recovery_password_email_label'       => $this->get_setting( 'recovery_password_email_label' ),
			'recovery_password_email_placeholder' => $this->get_setting( 'recovery_password_email_placeholder' ),
			'recovery_password_button_label'      => $this->get_setting( 'recovery_password_button_label' ),
		), $defaults );

		$args = [
			'log_username'              => $atts['signin_username_label'],
			'log_password'              => $atts['password_label'],
			'log_button'                => $atts['signin_button_label'],
			'display_recpass'           => $atts['enable_recovery_password'],
			'recpass_text'              => $atts['recovery_password_label'],
			'recpass_desc'              => $atts['recovery_password_description'],
			'recpass_username'          => $atts['recovery_password_email_label'],
			'recpass_placeholder'       => $atts['recovery_password_email_placeholder'],
			'recpass_button'            => $atts['recovery_password_button_label'],
			'reg_text'                  => $atts['signup_label'],
			'reg_url'                   => ATBDP_Permalink::get_registration_page_link(),
			'reg_linktxt'               => $atts['signup_linking_text'],
			'new_user_registration'     => directorist_is_user_registration_enabled() ? 'yes' : 'no',
			'parent'                    => 0,
			'container_fluid'           => is_directoria_active() ? 'container' : 'container-fluid',
			'username'                  => $atts['username_label'],
			'password'                  => $atts['password_label'],
			'display_password_reg'      => $atts['password'],
			'email'                     => $atts['email_label'],
			'display_website'           => $atts['website'],
			'website'                   => $atts['website_label'],
			'require_website'           => $atts['website_required'],
			'display_fname'             => $atts['firstname'],
			'first_name'                => $atts['firstname_label'],
			'require_fname'             => $atts['firstname_required'],
			'display_lname'             => $atts['lastname'],
			'last_name'                 => $atts['lastname_label'],
			'require_lname'             => $atts['lastname_required'],
			'display_bio'               => $atts['bio'],
			'bio'                       => $atts['bio_label'],
			'require_bio'               => $atts['bio_required'],
			'reg_signup'                => $atts['signup_button_label'],
			'login_text'                => $atts['signin_message'],
			'login_url'                 => ATBDP_Permalink::get_login_page_link(),
			'log_linkingmsg'            => $atts['signin_linking_text'],
			'enable_registration_terms' => $atts['terms'],
			'terms_label'               => $atts['terms_label'],
			'terms_label_link'          => $atts['terms_linking_text'],
			't_C_page_link'             => ATBDP_Permalink::get_terms_and_conditions_page_url(),
			'privacy_page_link'         => ATBDP_Permalink::get_privacy_policy_page_url(),
			'registration_privacy'      => $atts['privacy'],
			'privacy_label'             => $atts['privacy_label'],
			'privacy_label_link'        => $atts['privacy_linking_text'],
			'user_type'                 => $atts['user_type'],
			'author_checked'            => 'checked',
			'enable_user_type'          => $atts['user_role'],
			'author_role_label'         => $atts['author_role_label'],
			'user_role_label'           => $atts['user_role_label'],
			'active_form'               => $atts['active_form'],
		];

		echo "<div {$this->render_attributes( '_root' )}>";
			if ( Utils::maybe_editor() && is_user_logged_in() ) {
				$args['active_form'] = ( directorist_is_user_registration_enabled() && $this->get_setting( 'signup_preview' ) ) ? 'signup' : 'signin';

				static::render_in_editor( $args );
			} else {
				Utils::do_shortcode( 'directorist_signin_signup', $atts );
			}
		echo '</div>';
	}

	protected static function render_in_editor( $args ) {
		Helper::get_template( 'account/login-registration-form', $args );
	}
}
