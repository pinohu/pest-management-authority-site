<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use Bricks\Elements as BricksElements;

class Elements {
    
    public static function init() {
        add_action( 'init', [ static::class, 'register' ], 11 );
        add_filter( 'bricks/builder/i18n', [ static::class, 'register_category' ] );
    }

    public static function register_category( $i18n ) {
        $i18n['directorist_element'] = esc_html__( 'Directorist', 'addonskit-for-bricks' );
        return $i18n;
    }

    public static function register() {
        require_once __DIR__ . '/Styles/Container.php';
        
        require_once __DIR__ . '/BaseElement.php';
        require_once __DIR__ . '/SingleTerm.php';
        
        $element_files = [
            'AddListing.php',
            'Listings.php',
            'Locations.php',
            'Categories.php',
            'SingleLocation.php',
            'SingleCategory.php',
            'SingleTag.php',
            'SearchForm.php',
            'SearchResult.php',
            'Authors.php',
            'AuthorProfile.php',
            'Dashboard.php',
            'SigninSignup.php',
            'Checkout.php',
            'PaymentReceipt.php',
            'TransactionFailure.php',
            'Listing/QuickActions.php',
            'Listing/ActionLinks.php',
            'Listing/Images.php',
            'Listing/MetaInfo.php',
            'Listing/AuthorBio.php',
            'Listing/ContactForm.php',
            'Listing/SocialMedia.php',
            'Listing/Map.php',
            'Listing/Review.php',
            'Listing/RelatedListings.php',
            'Components/Account.php',
            'Components/SearchModal.php',
        ];
        
        foreach ( $element_files as $file ) {
            BricksElements::register_element( __DIR__ . DIRECTORY_SEPARATOR . $file );
        }
    }
}
