<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SingleTag extends SingleTerm {

	public $name = 'directorist-tag';

	public function get_label() {
		return __( 'Single Tag', 'addonskit-for-bricks' );
	}

	protected static function get_shortcode() {
		return 'directorist_tag';
	}
}
