<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WpWax\AKFB\Support\Utils;

class SearchForm extends BaseElement {
	use Styles\Container;

	public $name = 'directorist-search-form';

	public function get_label() {
		return __( 'Search Form', 'addonskit-for-bricks' );
	}

	public function get_keywords() {
		return ['search form', 'search page'];
	}

	public function set_control_groups() {
		$this->control_groups['form_title'] = [
			'title' => esc_html__( 'Form Title', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['directory_menu'] = [
			'title' => esc_html__( 'Directory Menu', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['search_box'] = [
			'title' => esc_html__( 'Search', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['form'] = [
			'title' => esc_html__( 'Form', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['form_fields'] = [
			'title' => esc_html__( 'Fields', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['buttons'] = [
			'title' => esc_html__( 'Buttons', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['popular_categories'] = [
			'title' => esc_html__( 'Popular Categories', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['general'] = [
			'title' => esc_html__( 'General', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];
	}

	public function set_controls() {
		$this->controls['_margin']['css'][0]['selector'] = '.directorist-search-contents';
		$this->controls['_padding']['css'][0]['selector'] = '.directorist-search-contents';

		$this->set_form_title_controls( 'form_title', 'form_title' );
		$this->set_directory_menu_controls( 'directory_menu', 'directory_menu' );
		$this->set_search_box_controls( 'search_box', 'search_box' );
		$this->set_form_controls( 'form', 'form' );
		$this->set_form_fields_controls( 'form_fields', 'form_fields' );
		$this->set_form_buttons_controls( 'buttons', 'buttons' );
		$this->set_popular_categories_controls( 'popular_categories', 'popular_categories' );

		$this->controls['loggedin_users_only'] = [
			'tab'     => 'content',
			'group'   => 'general',
			'label'   => esc_html__( 'Logged In User Can View Only', 'addonskit-for-bricks' ),
			'type'    => 'checkbox',
			'inline'  => true,
			'small'   => true,
			'default' => false,                                                                  // Default: false
		];
	}

	protected function set_form_title_controls( $prefix, $group ) {
		$this->controls['show_title'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => esc_html__( 'Display Titles', 'addonskit-for-bricks' ),
			'type'    => 'checkbox',
			'inline'  => true,
			'small'   => true,
			'default' => true,                                                     // Default: false
		];

		$this->controls['title'] = [
			'tab'           => 'content',
			'group'         => $group,
			'label'         => esc_html__( 'Form Title', 'addonskit-for-bricks' ),
			'type'          => 'text',
			'spellcheck'    => true,
			'inlineEditing' => false,
			'default'       => __( 'Search here', 'addonskit-for-bricks' ),
			'required'      => ['show_title', '=', true],
		];

		$this->controls[$prefix . '_typography'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Typography', 'addonskit-for-bricks' ),
			'type' => 'typography',
			'css' => [
				[
					'property' => 'typography',
					'selector' => '.directorist-search-top__title',
				],
			],
			'required' => ['show_title', '=', true],
			'inline' => true,
			'exclude' => [
				// 'color',
				// 'text-align',
				// 'text-decoration',
			//   'font-family',
			//   'font-weight',
			//   'text-transform',
			//   'font-size',
			//   'line-height',
			//   'letter-spacing',
			//   'text-shadow',
			],
			'popup' => true, // Default: true
		];

		$this->controls['subtitle'] = [
			'tab'           => 'content',
			'group'         => $group,
			'label'         => esc_html__( 'Form Subtitle', 'addonskit-for-bricks' ),
			'type'          => 'text',
			'spellcheck'    => true,
			'inlineEditing' => false,
			'default'       => __( 'Find the best match of your interest', 'addonskit-for-bricks' ),
			'required'      => ['show_title', '=', true],
		];

		$this->controls[$prefix . '_sub_typography'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Typography', 'addonskit-for-bricks' ),
			'type' => 'typography',
			'css' => [
				[
					'property' => 'typography',
					'selector' => '.directorist-search-top__subtitle',
				],
			],
			'required' => ['show_title', '=', true],
			'inline' => true,
			'exclude' => [
				// 'color',
				// 'text-align',
				// 'text-decoration',
			//   'font-family',
			//   'font-weight',
			//   'text-transform',
			//   'font-size',
			//   'line-height',
			//   'letter-spacing',
			//   'text-shadow',
			],
			'popup' => true, // Default: true
		];

		$this->controls['title_align'] = [
			'tab'      => 'content',
			'group'    => $group,
			'label'    => esc_html__( 'Alignment', 'addonskit-for-bricks' ),
			'type'     => 'text-align',
			'required' => ['show_title', '=', true],
			'css'      => [
				[
					'property' => 'text-align',
					'selector' => '.directorist-search-top__title, .directorist-search-top__subtitle',
				],
			],
		];
	}

	protected function set_directory_menu_controls( $prefix, $group ) {
		if ( ! directorist_is_multi_directory_enabled() ) {
			return;
		}

		$this->controls['directory'] = [
			'tab'         => 'content',
			'group'       => $group,
			'label'       => __( 'Directories', 'addonskit-for-bricks' ),
			'type'        => 'select',
			'options'     => Utils::get_directories(),
			'inline'      => true,
			'placeholder' => esc_html__( 'Select directories', 'addonskit-for-bricks' ),
			'multiple'    => true,
			'searchable'  => true,
			'clearable'   => true,
		];

		$this->controls['default_directory'] = [
			'tab'         => 'content',
			'group'       => $group,
			'label'       => __( 'Default Directory', 'addonskit-for-bricks' ),
			'type'        => 'select',
			'options'     => Utils::get_directories(),
			'inline'      => true,
			'placeholder' => esc_html__( 'Select a directory', 'addonskit-for-bricks' ),
			'multiple'    => false,
			'searchable'  => true,
			'clearable'   => true,
		];

		$this->controls[ $prefix . '_padding'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Padding', 'addonskit-for-bricks' ),
			'type'  => 'spacing',
			'css'   => [
				[
					'property' => 'padding',
					'selector' => '.directorist-listing-type-selection__item a',
				]
			],
		];

		$this->controls[ $prefix . '_border'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Border', 'addonskit-for-bricks' ),
			'type'  => 'border',
			'css'   => [
				[
					'property' => 'border',
					'selector' => '.directorist-listing-type-selection__item a',
				],
			],
			'inline' => true,
			'small'  => true,
		];

		$this->controls[$prefix . '_boxshadow'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Box Shadow', 'addonskit-for-bricks' ),
			'type' => 'box-shadow',
			'css' => [
				[
				'property' => 'box-shadow',
				'selector' => '.directorist-listing-type-selection__item a',
				],
			],
			'inline' => true,
			'small' => true,
		];

		$this->controls[$prefix . '_typography'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Typography', 'addonskit-for-bricks' ),
			'type' => 'typography',
			'css' => [
				[
					'property' => 'typography',
					'selector' => '.directorist-listing-type-selection__item a',
				],
			],
			'inline' => true,
			'exclude' => [
				'color',
				// 'text-align',
				// 'text-decoration',
			//   'font-family',
			//   'font-weight',
			//   'text-transform',
			//   'font-size',
			//   'line-height',
			//   'letter-spacing',
			//   'text-shadow',
			],
			'popup' => true, // Default: true
		];

		$this->controls[$prefix . '_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'color',
					'selector' => '.directorist-listing-type-selection__item a',
				],
				[
					'property' => 'background-color',
					'selector' => '.directorist-listing-type-selection__item a .directorist-icon-mask::after',
				]
			],
		];

		$this->controls[$prefix . '_bg_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Background Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'background-color',
					'selector' => '.directorist-listing-type-selection__item a',
				]
			],
		];

		$this->controls[$prefix . '_icon_size'] = [
			'group' => $group,
			'label' => esc_html__( 'Icon Size', 'addonskit-for-bricks' ),
			'type'  => 'number',
			'css'   => [
				[
					'property' => 'width',
					'selector' => '.directorist-listing-type-selection__item a .directorist-icon-mask::after',
				],
				[
					'property' => 'height',
					'selector' => '.directorist-listing-type-selection__item a .directorist-icon-mask::after',
				],
			],
			'units' => true,
		];

		$this->controls[ $prefix . '_icon_padding'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Icon Padding', 'addonskit-for-bricks' ),
			'type'  => 'spacing',
			'css'   => [
				[
					'property' => 'padding',
					'selector' => '.directorist-listing-type-selection__item a .directorist-icon-mask',
				]
			],
		];
	}

	protected function set_form_controls( $prefix, $group ) {
		$this->set_container_controls( 'form', 'form', '.directorist-search-form__box' );
	}

	protected function set_form_fields_controls( $prefix, $group ) {
		$color_selectors = [
			'.directorist-search-modal__contents__body .directorist-search-field.input-is-focused .select2-selection--single .select2-selection__rendered .select2-selection__placeholder',
			'.directorist-search-contents .directorist-search-form-top .directorist-search-field__label',
			'.directorist-search-contents .directorist-search-form-top .directorist-search-field .directorist-form-element::placeholder',
			'.select2-container--default .select2-selection--single .select2-selection__placeholder',
			'.directorist-search-contents .directorist-search-form-top .directorist-search-field .directorist-btn-ml',
			'.directorist-price-ranges__item .directorist-pf-range',
			'.directorist-checkbox .directorist-checkbox__label',
			'.directorist-search-form-wrap .directorist-search-form-box .directorist-form-group .directorist-form-element::placeholder',
		];
		
		$this->controls[$prefix . '_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'color',
					'selector' => implode( ',', $color_selectors ),
				],
				[
					'property' => 'background-color',
					'selector' => '.directorist-form-group .directorist-input-icon .directorist-icon-mask:after, .directorist-select2-addons-area .directorist-icon-mask:after'
				]
			],
		];

		$this->controls[$prefix . '_typography'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Typography', 'addonskit-for-bricks' ),
			'type' => 'typography',
			'css' => [
				[
					'property' => 'typography',
					'selector' => '.directorist-search-contents .directorist-search-field__label, .directorist-search-contents .select2-selection__placeholder',
				],
			],
			'inline' => true,
			'exclude' => [
				'color',
				// 'text-align',
				// 'text-decoration',
			//   'font-family',
			//   'font-weight',
			//   'text-transform',
			//   'font-size',
			//   'line-height',
			//   'letter-spacing',
			//   'text-shadow',
			],
			'popup' => true, // Default: true
		];
	}

	protected function set_form_buttons_controls( $prefix, $group ) {
		$this->controls[$prefix . '_filter_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Filter Button Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'color',
					'selector' => '.directorist-search-form-action__filter .directorist-filter-btn',
				],
				[
					'property' => 'background-color',
					'selector' => '.directorist-search-form-action__filter .directorist-filter-btn .directorist-icon-mask:after'
				]
			],
		];

		$this->controls[$prefix . '_filter_bg_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Filter Background Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'background-color',
					'selector' => '.directorist-search-form-action__filter .directorist-filter-btn',
				],
			],
		];

		$this->controls[$prefix . '_search_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Search Button Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'color',
					'selector' => '.directorist-search-contents .directorist-btn.directorist-btn-dark',
				],
				[
					'property' => 'background-color',
					'selector' => '.directorist-search-contents .directorist-btn.directorist-btn-dark .directorist-icon-mask:after'
				]
			],
		];

		$this->controls[$prefix . '_search_bg_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Search Background Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'background-color',
					'selector' => '.directorist-search-contents .directorist-btn.directorist-btn-dark',
				],
			],
		];
	}

	protected function set_popular_categories_controls( $prefix, $group ) {
		$this->controls['show_popular_category'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'       => __( 'Display Popular Categories', 'addonskit-for-bricks' ),
			'description' => __( 'You can set the number of categories to show from settings panel.', 'addonskit-for-bricks' ),
			'type'        => 'checkbox',
			'inline'      => true,
			'small'       => true,
			'default'     => false,
		];

		$this->controls[$prefix . '_icon_size'] = [
			'group' => $group,
			'label' => esc_html__( 'Icon Size', 'addonskit-for-bricks' ),
			'type'  => 'number',
			'css'   => [
				[
					'property' => 'width',
					'selector' => '.directorist-listing-category-top li a .directorist-icon-mask::after',
				],
				[
					'property' => 'height',
					'selector' => '.directorist-listing-category-top li a .directorist-icon-mask::after',
				],
			],
			'units' => true,
		];

		$this->controls[$prefix . '_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'color',
					'selector' => '.directorist-listing-category-top li a',
				],
				[
					'property' => 'background-color',
					'selector' => '.directorist-listing-category-top li a .directorist-icon-mask:after',
				]
			],
		];

		$this->controls[$prefix . '_typography'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Typography', 'addonskit-for-bricks' ),
			'type' => 'typography',
			'css' => [
				[
					'property' => 'typography',
					'selector' => '.directorist-listing-category-top li a',
				],
			],
			'inline' => true,
			'exclude' => [
				'color',
				// 'text-align',
				// 'text-decoration',
			//   'font-family',
			//   'font-weight',
			//   'text-transform',
			//   'font-size',
			//   'line-height',
			//   'letter-spacing',
			//   'text-shadow',
			],
			'popup' => true, // Default: true
		];
	}

	protected function set_search_box_controls( $prefix, $group ) {
		$this->controls['search_btn_text'] = [
			'tab'           => 'content',
			'group'         => $group,
			'label'         => esc_html__( 'Search Button Label', 'addonskit-for-bricks' ),
			'type'          => 'text',
			'spellcheck'    => true,
			'inlineEditing' => false,
			'default'       => __( 'Search Listing', 'addonskit-for-bricks' ),
		];

		$this->controls['show_filter'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => esc_html__( 'Display Advanced Filter', 'addonskit-for-bricks' ),
			'type'    => 'checkbox',
			'inline'  => true,
			'small'   => true,
			'default' => true,                                                              // Default: false
		];

		$this->controls['filter_btn_text'] = [
			'tab'           => 'content',
			'group'         => $group,
			'label'         => esc_html__( 'Advanced Filter Button Text', 'addonskit-for-bricks' ),
			'type'          => 'text',
			'spellcheck'    => true,
			'inlineEditing' => false,
			'default'       => __( 'More Filters', 'addonskit-for-bricks' ),
			'required'      => ['show_filter', '=', true],
		];

		$this->controls['show_filter_reset'] = [
			'tab'      => 'content',
			'group'    => $group,
			'label'    => esc_html__( 'Display Advanced Filter Reset', 'addonskit-for-bricks' ),
			'type'     => 'checkbox',
			'inline'   => true,
			'small'    => true,
			'default'  => true,
			'required' => ['show_filter', '=', true],
		];

		$this->controls['filter_reset_btn_text'] = [
			'tab'           => 'content',
			'group'         => $group,
			'label'         => esc_html__( 'Advanced Filter Reset Button Text', 'addonskit-for-bricks' ),
			'type'          => 'text',
			'spellcheck'    => true,
			'inlineEditing' => false,
			'default'       => __( 'Reset Filters', 'addonskit-for-bricks' ),
			'required'      => [
				['show_filter', '=', true],
				['show_filter_reset', '=', true]
			]
		];

		$this->controls['show_apply_filter_btn'] = [
			'tab'      => 'content',
			'group'    => $group,
			'label'    => esc_html__( 'Display Apply Filter Button', 'addonskit-for-bricks' ),
			'type'     => 'checkbox',
			'inline'   => true,
			'small'    => true,
			'default'  => true,
			'required' => ['show_filter', '=', true],
		];

		$this->controls['apply_filter_btn_text'] = [
			'tab'           => 'content',
			'group'         => $group,
			'label'         => esc_html__( 'Apply Filter Button Text', 'addonskit-for-bricks' ),
			'type'          => 'text',
			'spellcheck'    => true,
			'inlineEditing' => false,
			'default'       => __( 'Apply Filters', 'addonskit-for-bricks' ),
			'required'      => [
				['show_filter', '=', true],
				['show_apply_filter_btn', '=', true]
			]
		];
	}
	
	public function render() {
		$args = [
			'show_title_subtitle'   => $this->get_setting( 'show_title' ),
			'search_bar_title'      => $this->get_setting( 'title' ),
			'search_bar_sub_title'  => $this->get_setting( 'subtitle' ),
			'search_button_text'    => $this->get_setting( 'search_btn_text' ),
			'more_filters_button'   => $this->get_setting( 'show_filter' ),
			'more_filters_text'     => $this->get_setting( 'filter_btn_text' ),
			'reset_filters_button'  => $this->get_setting( 'show_filter_reset' ),
			'reset_filters_text'    => $this->get_setting( 'filter_reset_btn_text' ),
			'apply_filters_button'  => $this->get_setting( 'show_apply_filter_btn' ),
			'apply_filters_text'    => $this->get_setting( 'apply_filter_btn_text' ),
			'logged_in_user_only'   => empty( $this->get_setting( 'loggedin_users_only' ) ) ? 'no' : 'yes',
			'show_popular_category' => $this->get_setting( 'show_popular_category' ) ? 'yes' : 'no'
		];

		if ( directorist_is_multi_directory_enabled() ) {
			$directory = $this->get_setting( 'directory' );

			if ( ! empty( $directory ) ) {
				$args['directory_type'] = is_array( $directory ) ? implode( ',', $directory ) : $directory;
			}
			
			if ( ! empty( $this->get_setting( 'default_directory' ) ) ) {
				$args['default_directory_type'] = $this->get_setting( 'default_directory' );
			}
		}

		echo "<div {$this->render_attributes( '_root' )}>"; 
			Utils::do_shortcode( 'directorist_search_listing', $args );
		echo '</div>';
	}
}
