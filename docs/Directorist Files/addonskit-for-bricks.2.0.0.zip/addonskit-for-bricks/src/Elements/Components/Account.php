<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WpWax\AKFB\Support\Utils;

class Accounts extends BaseElement {

    public $name = 'directorist-account';

    public function get_label() {
        return esc_html__( 'Accounts', 'addonskit-for-bricks' );
    }

    public function get_keywords() {
        return ['sign in', 'login', 'account'];
    }

	public function set_control_groups() {
		
		$this->control_groups['button'] = [
			'title' => esc_html__( 'Button', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];
		
		$this->control_groups['button_style'] = [
			'title' => esc_html__( 'Button Style', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];
	}

    public function set_controls() {
        // Control for customizing the Login Button label
        $this->controls['btn_label'] = [
            'tab'         => 'content',
			'group'       => 'button',
            'label'       => esc_html__( 'Login Button Label', 'addonskit-for-bricks' ),
            'type'        => 'text',
            'default'     => esc_html__( 'Login', 'addonskit-for-bricks' ),
        ];

        // Control for enabling a dropdown menu in account management
        $this->controls['dropdown'] = [
            'tab'         => 'content',
			'group'       => 'button',
            'label'       => esc_html__( 'Enable Dropdown Menu', 'addonskit-for-bricks' ),
            'type'        => 'checkbox',
            'default'     => true,
            'inline'      => true,
            'small'       => true,
            'description' => esc_html__( 'Enable a dropdown menu for account management when the user is logged in.', 'addonskit-for-bricks' ),
        ];

		// Button Styles.
		$this->button_style_controls( 'login_button', 'button_style' );
    }

	protected function button_style_controls( $prefix, $group ) {
		$this->controls[$prefix . '_preview'] = [
			'tab'     => 'content',
			'group'   => $group,
			'label'   => esc_html__( 'Button Preview', 'addonskit-for-bricks' ),
			'type'    => 'checkbox',
			'default' => false,
			'inline'  => true,
			'small'   => true,
		];
		
		$this->controls[$prefix . '_color'] = [
			'tab'    => 'content',
			'group'  => $group,
			'label'  => esc_html__( 'Text Color', 'addonskit-for-bricks' ),
			'type'   => 'color',
			'inline' => true,
			'css'    => [
				[
					'property' => 'color',
					'selector' => '.wp-block-button__link.directorist-btn',
				]
			],
		];

		$this->controls[$prefix . '_background'] = [
			'tab'   => 'content',
			'group' => $group,
			// 'label' => esc_html__( 'Background Color', 'addonskit-for-bricks' ),
			'type'  => 'background',
			'css'   => [
				[
					'property' => 'background',
					'selector' => '.wp-block-button__link.directorist-btn',
				],
			],
			'exclude' => [
				  // 'color',
				'image',
				'parallax',
				'attachment',
				'position',
				'positionX',
				'positionY',
				'repeat',
				'size',
				'custom',
				'videoUrl',
				'videoScale',
				'blendMode'
			],
			'inline'  => false,
			'small'   => false,
			'popup' => false,
		];

		$this->controls[$prefix . '_border_color'] = [
			'tab'    => 'content',
			'group'  => $group,
			'label'  => esc_html__( 'Border Color', 'addonskit-for-bricks' ),
			'type'   => 'color',
			'inline' => true,
			'css'    => [
				[
					'property' => 'border-color',
					'selector' => '.wp-block-button__link.directorist-btn',
				]
			],
		];

		$this->controls[ $prefix . '_border'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Border', 'addonskit-for-bricks' ),
			'type'  => 'border',
			'css'   => [
				[
					'property' => 'border',
					'selector' => '.wp-block-button__link.directorist-btn',
				],
			],
			'inline' => true,
			'small'  => true,
		];
	}

    public function render() {
		if ( is_user_logged_in() && empty( $this->get_setting( 'login_button_preview' ) ) ) : ?>
			
			<div class="directorist-account-block-logged-mode">
				<?php
				// Display avatar image for the logged-in user.
				directorist_account_block_avatar_image();
	
				// Include dropdown menu if enabled.
				if ( $this->get_setting( 'dropdown' ) ) {
					include DIRECTORIST_BLOCK_TEMPLATE_PATH . '/navigation.php';
				}
				?>
			</div>
		
		<?php else : 
			include DIRECTORIST_BLOCK_TEMPLATE_PATH . '/account.php';
	
			$this->set_attribute( '_root', 'class', 'directorist-account-block-logout-mode' );
	
			// Output the container with dynamic attributes.
			echo '<div ' . $this->render_attributes( '_root' ) . '>'; ?>
			
				<button type="button" class="wp-block-button__link directorist-btn">
					<?php echo esc_html( $this->get_setting( 'btn_label' ) ); ?>
				</button>
			
			<?php
			echo '</div>';
		endif;
	}
	
}
