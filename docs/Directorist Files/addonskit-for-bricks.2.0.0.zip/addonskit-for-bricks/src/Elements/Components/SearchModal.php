<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class TopSearch extends BaseElement {

    public $name = 'directorist-search-modal';

    public function get_label() {
        return esc_html__( 'Search Modal', 'addonskit-for-bricks' );
    }

    public function get_keywords() {
        return ['search', 'search modal', 'popup search'];
    }

	public function set_control_groups() {
		
		$this->control_groups['button'] = [
			'title' => esc_html__( 'Button', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];
		
		$this->control_groups['button_style'] = [
			'title' => esc_html__( 'Button Style', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];
	}

    public function set_controls() {
        // Search Button Label control
        $this->controls['btn_label'] = [
			'tab'         => 'content',
			'label'       => esc_html__( 'Search Button Label', 'addonskit-for-bricks' ),
			'type'        => 'text',
			'group'       => 'button',
			'default'     => esc_html__( 'Search', 'addonskit-for-bricks' ),
			'description' => esc_html__( 'Leave this field empty to hide the search button label.', 'addonskit-for-bricks' ),
        ];

        // Icon display control
        $this->controls['icon'] = [
            'tab'         => 'content',
            'label'       => esc_html__( 'Display Icon', 'addonskit-for-bricks' ),
            'type'        => 'checkbox',
			'group'       => 'button',
            'default'     => true,
            'inline'      => true,
            'small'       => true,
            'description' => esc_html__( 'Check to show an icon on the search button.', 'addonskit-for-bricks' ),
        ];
		
		// Button Styles.
		$this->button_style_controls( 'search_button', 'button_style' );
    }

	protected function button_style_controls( $prefix, $group ) {
		$this->controls[$prefix . '_color'] = [
			'tab'    => 'content',
			'group'  => $group,
			'label'  => esc_html__( 'Text Color', 'addonskit-for-bricks' ),
			'type'   => 'color',
			'inline' => true,
			'css'    => [
				[
					'property' => 'color',
					'selector' => '.directorist-search-popup-block__button.directorist-btn',
				]
			],
		];

		$this->controls[$prefix . '_background'] = [
			'tab'   => 'content',
			'group' => $group,
			// 'label' => esc_html__( 'Background Color', 'addonskit-for-bricks' ),
			'type'  => 'background',
			'css'   => [
				[
					'property' => 'background',
					'selector' => '.directorist-search-popup-block__button.directorist-btn',
				],
			],
			'exclude' => [
				  // 'color',
				'image',
				'parallax',
				'attachment',
				'position',
				'positionX',
				'positionY',
				'repeat',
				'size',
				'custom',
				'videoUrl',
				'videoScale',
				'blendMode'
			],
			'inline'  => false,
			'small'   => false,
			'popup' => false,
		];

		$this->controls[$prefix . '_border_color'] = [
			'tab'    => 'content',
			'group'  => $group,
			'label'  => esc_html__( 'Border Color', 'addonskit-for-bricks' ),
			'type'   => 'color',
			'inline' => true,
			'css'    => [
				[
					'property' => 'border-color',
					'selector' => '.directorist-search-popup-block__button.directorist-btn',
				]
			],
		];

		$this->controls[ $prefix . '_border'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Border', 'addonskit-for-bricks' ),
			'type'  => 'border',
			'css'   => [
				[
					'property' => 'border',
					'selector' => '.directorist-search-popup-block__button.directorist-btn',
				],
			],
			'inline' => true,
			'small'  => true,
		];
	}

    public function render() {

		// Set attributes for the root container.
		$this->set_attribute( '_root', 'class', 'directorist-search-popup-block directorist-search-popup-bricks' );
	
		// Output the container with dynamic attributes.
		echo '<div ' . $this->render_attributes( '_root' ) . '>'; ?>
	
			<div class="directorist-search-popup-block__button directorist-btn">
				<?php
				// Display icon if enabled.
				if ( $this->get_setting( 'icon' ) ) {
					directorist_icon( 'fa fa-search' );
				}
	
				// Display button label with escaping for security.
				echo esc_html( $this->get_setting( 'btn_label' ) );
				?>
			</div>
	
			<?php 
			// Include the popup template.
			include_once DIRECTORIST_BLOCK_TEMPLATE_PATH . '/popup.php';
			
		echo '</div>'; ?>
	
		<style>
			.directorist-search-popup-bricks .directorist-search-popup-block__button {
				display: flex;
				align-items: center;
				gap: 5px;
			}
		</style>
		<?php
	}
	
}