<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WpWax\AKFB\Support\Utils;

class Dashboard extends BaseElement {

	public $name = 'directorist-dashboard';
	
	public function get_label() {
		return esc_html__( 'Dashboard', 'addonskit-for-bricks' );
	}

	public function get_keywords() {
		return ['dashboard', 'my account', 'account', 'profile'];
	}

	public function set_control_groups() {}

	public function set_controls() {}
	
	public function render() {
		echo "<div {$this->render_attributes( '_root' )}>";
			Utils::do_shortcode( 'directorist_user_dashboard' );
		echo '</div>';
	}
}
