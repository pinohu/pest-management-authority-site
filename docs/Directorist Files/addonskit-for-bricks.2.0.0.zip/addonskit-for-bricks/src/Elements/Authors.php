<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WpWax\AKFB\Support\Utils;

class Authors extends BaseElement {
	use Styles\Container;

	public $name = 'directorist-authors';
	
	public function get_label() {
		return __( 'Authors', 'addonskit-for-bricks' );
	}

	public function get_keywords() {
		return ['all authors', 'all users'];
	}

	public function set_control_groups() {
		$this->control_groups['nav'] = [
			'title' => esc_html__( 'Letter Navigation', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['nav_item'] = [
			'title' => esc_html__( 'Navigation Item', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['card'] = [
			'title' => esc_html__( 'Card', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['img'] = [
			'title' => esc_html__( 'Image', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['author'] = [
			'title' => esc_html__( 'Author', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['contact'] = [
			'title' => esc_html__( 'Contact', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['bio'] = [
			'title' => esc_html__( 'Bio', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['social'] = [
			'title' => esc_html__( 'Social Icons', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['button'] = [
			'title' => esc_html__( 'Button', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];
	}

	public function set_controls() {
		$this->set_nav_container_controls( 'nav', 'nav' );
		$this->set_nav_item_controls( 'nav_item', 'nav_item' );
		$this->set_card_controls( 'card', 'card' );
		$this->set_image_controls( 'img', 'img' );
		$this->set_author_controls( 'author', 'author' );
		$this->set_contact_controls( 'contact', 'contact' );
		$this->set_bio_controls( 'bio', 'bio' );
		$this->set_social_controls( 'social', 'social' );
		$this->set_button_controls( 'button', 'button' );
	}

	protected function set_nav_container_controls( $prefix, $group ) {
		$this->set_container_controls( $prefix, $group, '.directorist-authors__nav' );
	}

	protected function set_nav_item_controls( $prefix, $group ) {
		$this->controls[ $prefix . '_padding'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Padding', 'addonskit-for-bricks' ),
			'type'  => 'spacing',
			'css'   => [
				[
					'property' => 'padding',
					'selector' => '.directorist-authors__nav a',
				]
			],
		];

		$this->controls[ $prefix . '_border'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Border', 'addonskit-for-bricks' ),
			'type'  => 'border',
			'css'   => [
				[
					'property' => 'border',
					'selector' => '.directorist-authors__nav a',
				],
			],
			'inline' => true,
			'small'  => true,
		];

		$this->controls[$prefix . '_link_background'] = [ // Setting key
			'tab'   => 'content',
			'group' => $group,
			// 'label' => esc_html__( 'Item Background', 'addonskit-for-bricks' ),
			'type'  => 'background',
			'css'   => [
				[
					'property' => 'background',
					'selector' => '.directorist-authors__nav a',
				],
			],
			'exclude' => [
				  // 'color',
				'image',
				'parallax',
				'attachment',
				'position',
				'positionX',
				'positionY',
				'repeat',
				'size',
				'custom',
				'videoUrl',
				'videoScale',
				'blendMode'
			],
			'inline'  => false,
			'small'   => false,
			'popup' => false,
		];

		$this->controls[$prefix . '_typography'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Typography', 'addonskit-for-bricks' ),
			'type' => 'typography',
			'css' => [
				[
					'property' => 'typography',
					'selector' => '.directorist-authors__nav a',
				],
			],
			'inline' => true,
			'exclude' => [
				// 'color',
				// 'text-align',
				// 'text-decoration',
			//   'font-family',
			//   'font-weight',
			//   'text-transform',
			//   'font-size',
			//   'line-height',
			//   'letter-spacing',
			//   'text-shadow',
			],
			'popup' => true, // Default: true
		];
	}

	protected function set_card_controls( $prefix, $group ) {
		$this->set_container_controls( $prefix, $group, '.directorist-authors__card' );
	}

	protected function set_image_controls( $prefix, $group ) {
		$this->controls[$prefix . '_size'] = [
			'group' => $group,
			'label' => esc_html__( 'Image Size', 'addonskit-for-bricks' ),
			'type'  => 'number',
			'css'   => [
				[
					'property' => 'width',
					'selector' => '.directorist-authors__card__img img',
				],
				[
					'property' => 'height',
					'selector' => '.directorist-authors__card__img img',
				],
			],
			'units' => true,
		];

		$this->controls[ $prefix . '_padding'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Padding', 'addonskit-for-bricks' ),
			'type'  => 'spacing',
			'css'   => [
				[
					'property' => 'padding',
					'selector' => '.directorist-authors__card__img img',
				]
			],
		];

		$this->controls[ $prefix . '_border'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Border', 'addonskit-for-bricks' ),
			'type'  => 'border',
			'css'   => [
				[
					'property' => 'border',
					'selector' => '.directorist-authors__card__img img',
				],
			],
			'inline' => true,
			'small'  => true,
		];

		$this->controls[$prefix . '_boxshadow'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Box Shadow', 'addonskit-for-bricks' ),
			'type' => 'box-shadow',
			'css' => [
				[
				'property' => 'box-shadow',
				'selector' => '.directorist-authors__card__img img',
				],
			],
			'inline' => true,
			'small' => true,
		];
	}

	protected function set_author_controls( $prefix, $group ) {
		$this->controls[$prefix . '_typography'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Typography', 'addonskit-for-bricks' ),
			'type' => 'typography',
			'css' => [
				[
					'property' => 'typography',
					'selector' => '.directorist-authors__card h2',
				],
			],
			'inline' => true,
			'exclude' => [
				// 'color',
				// 'text-align',
				// 'text-decoration',
			//   'font-family',
			//   'font-weight',
			//   'text-transform',
			//   'font-size',
			//   'line-height',
			//   'letter-spacing',
			//   'text-shadow',
			],
			'popup' => true, // Default: true
		];
	}

	protected function set_contact_controls( $prefix, $group ) {
		$this->controls[$prefix . '_icon_size'] = [
			'group' => $group,
			'label' => esc_html__( 'Icon Size', 'addonskit-for-bricks' ),
			'type'  => 'number',
			'css'   => [
				[
					'property' => 'width',
					'selector' => '.directorist-authors__card__info-list li .directorist-icon-mask:after',
				],
				[
					'property' => 'height',
					'selector' => '.directorist-authors__card__info-list li .directorist-icon-mask:after',
				],
			],
			'units' => true,
		];

		$this->controls[$prefix . '_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'color',
					'selector' => '.directorist-authors__card__info-list li, .directorist-authors__card__info-list li a',
				],
				[
					'property' => 'background-color',
					'selector' => '.directorist-authors__card__info-list li .directorist-icon-mask:after',
				]
			],
		];

		$this->controls[$prefix . '_typography'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Typography', 'addonskit-for-bricks' ),
			'type' => 'typography',
			'css' => [
				[
					'property' => 'typography',
					'selector' => '.directorist-authors__card__info-list li',
				],
			],
			'inline' => true,
			'exclude' => [
				'color',
				// 'text-align',
				// 'text-decoration',
			//   'font-family',
			//   'font-weight',
			//   'text-transform',
			//   'font-size',
			//   'line-height',
			//   'letter-spacing',
			//   'text-shadow',
			],
			'popup' => true, // Default: true
		];
	}
	
	protected function set_bio_controls( $prefix, $group ) {
		$this->controls[$prefix . '_typography'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Typography', 'addonskit-for-bricks' ),
			'type' => 'typography',
			'css' => [
				[
					'property' => 'typography',
					'selector' => '.directorist-authors__card p',
				],
			],
			'inline' => true,
			'exclude' => [
				// 'color',
				// 'text-align',
				// 'text-decoration',
			//   'font-family',
			//   'font-weight',
			//   'text-transform',
			//   'font-size',
			//   'line-height',
			//   'letter-spacing',
			//   'text-shadow',
			],
			'popup' => true, // Default: true
		];
	}

	protected function set_social_controls( $prefix, $group ) {
		$this->controls[$prefix . '_size'] = [
			'group' => $group,
			'label' => esc_html__( 'Icon Size', 'addonskit-for-bricks' ),
			'type'  => 'number',
			'css'   => [
				[
					'property' => 'width',
					'selector' => '.directorist-author-social .directorist-icon-mask:after',
				],
				[
					'property' => 'height',
					'selector' => '.directorist-author-social .directorist-icon-mask:after',
				],
			],
			'units' => true,
		];

		$this->controls[$prefix . '_padding'] = [
			'group' => $group,
			'label' => esc_html__( 'Padding', 'addonskit-for-bricks' ),
			'type'  => 'number',
			'css'   => [
				[
					'property' => 'padding',
					'selector' => '.directorist-author-social-item a',
				],
			],
			'units' => true,
		];

		$this->controls[$prefix . '_spacing'] = [
			'group' => $group,
			'label' => esc_html__( 'Spacing', 'addonskit-for-bricks' ),
			'type'  => 'number',
			'css'   => [
				[
					'property' => 'gap',
					'selector' => '.directorist-author-social',
				],
			],
			'units' => true,
		];

		$this->controls[$prefix . '_icon_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Icon Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'background-color',
					'selector' => '.directorist-author-social-item a .directorist-icon-mask:after',
				],
			],
		];

		$this->controls[$prefix . '_icon_bg_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Background Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'background-color',
					'selector' => '.directorist-author-social-item a',
				]
			],
		];
	}

	protected function set_button_controls( $prefix, $group ) {
		$this->controls[ $prefix . '_padding'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Padding', 'addonskit-for-bricks' ),
			'type'  => 'spacing',
			'css'   => [
				[
					'property' => 'padding',
					'selector' => '.directorist-authors__card .directorist-btn',
				]
			],
		];

		$this->controls[ $prefix . '_border'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Border', 'addonskit-for-bricks' ),
			'type'  => 'border',
			'css'   => [
				[
					'property' => 'border',
					'selector' => '.directorist-authors__card .directorist-btn',
				],
			],
			'inline' => true,
			'small'  => true,
		];

		$this->controls[$prefix . '_boxshadow'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Box Shadow', 'addonskit-for-bricks' ),
			'type' => 'box-shadow',
			'css' => [
				[
				'property' => 'box-shadow',
				'selector' => '.directorist-authors__card .directorist-btn',
				],
			],
			'inline' => true,
			'small' => true,
		];

		$this->controls[$prefix . '_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'color',
					'selector' => '.directorist-authors__card .directorist-btn',
				],
			],
		];

		$this->controls[$prefix . '_bg_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Background Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'background-color',
					'selector' => '.directorist-authors__card .directorist-btn',
				]
			],
		];

		$this->controls[$prefix . '_typography'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Typography', 'addonskit-for-bricks' ),
			'type' => 'typography',
			'css' => [
				[
					'property' => 'typography',
					'selector' => '.directorist-authors__card .directorist-btn',
				],
			],
			'inline' => true,
			'exclude' => [
				'color',
				// 'text-align',
				// 'text-decoration',
			//   'font-family',
			//   'font-weight',
			//   'text-transform',
			//   'font-size',
			//   'line-height',
			//   'letter-spacing',
			//   'text-shadow',
			],
			'popup' => true, // Default: true
		];
	}

	public function render() {
		echo "<div {$this->render_attributes( '_root' )}>"; 
			Utils::do_shortcode( 'directorist_all_authors' );
		echo '</div>';
	}
}
