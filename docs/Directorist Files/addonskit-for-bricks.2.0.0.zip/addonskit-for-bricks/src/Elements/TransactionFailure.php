<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Bricks\Element;
use WpWax\AKFB\Support\Utils;

class TransactionFailure extends BaseElement {
	
	public $name = 'directorist-transaction-failure';
	
	public function get_label() {
		return esc_html__( 'Transaction Failure', 'addonskit-for-bricks' );
	}

	public function get_keywords() {
		return ['payment', 'transaction', 'fail', 'checkout'];
	}

	public function set_control_groups() {}

	public function set_controls() {}
	
	public function render() {
		echo "<div {$this->render_attributes( '_root' )}>";
			Utils::do_shortcode( 'directorist_transaction_failure' );
		echo '</div>';
	}
}
