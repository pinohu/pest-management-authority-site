<?php

namespace WpWax\AKFB\Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WpWax\AKFB\Support\Utils;

class AddListing extends BaseElement {
	
	public $name = 'directorist-add-listing';
	
	public function get_label() {
		return esc_html__( 'Add Listing Form', 'addonskit-for-bricks' );
	}

	public function get_keywords() {
		return ['add listing form', 'add-listing-form', 'form', 'add listing', 'submit listing'];
	}

	public function set_control_groups() {
		if ( directorist_is_multi_directory_enabled() ) {
			$this->control_groups['directory_menu_item'] = [
				'title' => esc_html__( 'Directory Menu', 'addonskit-for-bricks' ),
				'tab'   => 'content',
			];
		}

		$this->control_groups['form'] = [
			'title' => esc_html__( 'Form Container', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['form_steps'] = [
			'title' => esc_html__( 'Form Steps', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['form_section'] = [
			'title' => esc_html__( 'Form Section Header', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['form_fields'] = [
			'title' => esc_html__( 'Form Fields', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];

		$this->control_groups['form_buttons'] = [
			'title' => esc_html__( 'Form Buttons', 'addonskit-for-bricks' ),
			'tab'   => 'content',
		];
	}

	public function set_controls() {
		if ( directorist_is_multi_directory_enabled() ) {
			$this->controls['directory'] = [
				'tab'         => 'content',
				'label'       => __( 'Select Directories', 'addonskit-for-bricks' ),
				'type'        => 'select',
				'options'     => Utils::get_directories(),
				'inline'      => true,
				'placeholder' => esc_html__( 'Default to all', 'addonskit-for-bricks' ),
				'description' => esc_html__( 'Select one or more directories, or leave empty to show all.', 'addonskit-for-bricks' ),
				'multiple'    => true,
				'searchable'  => true,
				'clearable'   => true,
			];

			// Default styles will server the container
			// $this->set_container_controls( 'menu_container', 'directory_menu_container', '.directorist-add-listing-types' );

			$this->set_menu_item_controls( 'menu_item', 'directory_menu_item' );
			$this->set_form_controls( 'form', 'form' );
			$this->set_form_steps_controls( 'form_steps', 'form_steps' );
			$this->set_form_section_header_controls( 'form_section', 'form_section' );
			$this->set_form_fields_controls( 'form_fields', 'form_fields' );
			$this->set_form_buttons_controls( 'form_buttons', 'form_buttons' );
		}
	}

	protected function set_menu_item_controls( $prefix, $group ) {
		if ( directorist_is_multi_directory_enabled() ) {
			$this->controls[$prefix . '_preview_info'] = [
				'tab' => 'content',
				'group' => $group,
				'content' => esc_html__( 'Form Preview is enabled. Please disable form preview to view the directory menu.', 'addonskit-for-bricks' ),
				'type' => 'info',
				'required' => ['form_preview', '=', true],
			];
		}
		
		$this->controls[ $prefix . '_padding'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Padding', 'addonskit-for-bricks' ),
			'type'  => 'spacing',
			'css'   => [
				[
					'property' => 'padding',
					'selector' => '.directorist-add-listing-types__single__link',
				]
			],
		];

		$this->controls[$prefix . '_icon_size'] = [
			'group' => $group,
			'label' => esc_html__( 'Icon size', 'addonskit-for-bricks' ),
			'type'  => 'number',
			// 'units' => true,
			'css'   => [
				[
					'property' => 'height',
					'selector' => '.directorist-add-listing-types__single__link .directorist-icon-mask:after',
				],
				[
					'property' => 'width',
					'selector' => '.directorist-add-listing-types__single__link .directorist-icon-mask:after',
				],
			],
			'units' => true,
		];

		$this->controls[$prefix . '_icon_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Icon Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
				'property' => 'background-color',
				'selector' => '.directorist-add-listing-types__single__link .directorist-icon-mask:after',
				]
			],
		];

		$this->controls[$prefix . '_icon_background'] = [ // Setting key
			'tab'   => 'content',
			'group' => $group,
			// 'label' => esc_html__( 'Item Background', 'addonskit-for-bricks' ),
			'type'  => 'background',
			'css'   => [
				[
					'property' => 'background',
					'selector' => '.directorist-add-listing-types__single__link .directorist-icon-mask',
				],
			],
			'exclude' => [
				  // 'color',
				'image',
				'parallax',
				'attachment',
				'position',
				'positionX',
				'positionY',
				'repeat',
				'size',
				'custom',
				'videoUrl',
				'videoScale',
				'blendMode'
			],
			'inline'  => false,
			'small'   => false,
			'popup' => false,
		];

		$this->controls[$prefix . '_link_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Text Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'color',
					'selector' => '.directorist-add-listing-types__single__link',
				]
			],
		];

		$this->controls[$prefix . '_link_background'] = [ // Setting key
			'tab'   => 'content',
			'group' => $group,
			// 'label' => esc_html__( 'Item Background', 'addonskit-for-bricks' ),
			'type'  => 'background',
			'css'   => [
				[
					'property' => 'background',
					'selector' => '.directorist-add-listing-types__single__link',
				],
			],
			'exclude' => [
				  // 'color',
				'image',
				'parallax',
				'attachment',
				'position',
				'positionX',
				'positionY',
				'repeat',
				'size',
				'custom',
				'videoUrl',
				'videoScale',
				'blendMode'
			],
			'inline'  => false,
			'small'   => false,
			'popup' => false,
		];

		$this->controls[$prefix . '_typography'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Typography', 'addonskit-for-bricks' ),
			'type' => 'typography',
			'css' => [
				[
					'property' => 'typography',
					'selector' => '.directorist-add-listing-types__single__link',
				],
			],
			'inline' => true,
			// 'exclude' => [
			//   'font-family',
			//   'font-weight',
			//   'text-align',
			//   'text-transform',
			//   'font-size',
			//   'line-height',
			//   'letter-spacing',
			//   'color',
			//   'text-shadow',
			// ],
			'popup' => true, // Default: true
		];
	}

	protected function set_form_controls( $prefix, $group ) {
		if ( directorist_is_multi_directory_enabled() ) {
			$this->controls[ $prefix . '_preview' ] = [
				'tab'     => 'content',
				// 'group' => $group,
				'label'   => esc_html__( 'Display Form Preview', 'addonskit-for-bricks' ),
				'description'   => esc_html__( 'Use this to display the add listing form preview only when the directory menu is visible.', 'addonskit-for-bricks' ),
				'type'    => 'checkbox',
				'inline'  => true,
				'small'   => true,
			];
		}

		$this->controls[ $prefix . '_margin'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Margin', 'addonskit-for-bricks' ),
			'type'  => 'spacing',
			'css'   => [
				[
					'property' => 'margin',
					'selector' => '.directorist-add-listing-form .directorist-content-module',
				]
			],
		];

		$this->controls[ $prefix . '_padding'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Padding', 'addonskit-for-bricks' ),
			'type'  => 'spacing',
			'css'   => [
				[
					'property' => 'padding',
					'selector' => '.directorist-add-listing-form .directorist-content-module',
				]
			],
		];

		$this->controls[$prefix . '_background'] = [ // Setting key
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Background', 'addonskit-for-bricks' ),
			'type' => 'background',
			'css' => [
				[
					'property' => 'background',
					'selector' => '.directorist-add-listing-form .directorist-content-module',
				],
			],
			'exclude' => [
				// 'color',
				// 'image',
				// 'parallax',
				// 'attachment',
				// 'position',
				// 'positionX',
				// 'positionY',
				// 'repeat',
				// 'size',
				'custom',
				'videoUrl',
				'videoScale',
			],
			'inline' => true,
			'small' => true,
		];

		$this->controls[ $prefix . '_border'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Border', 'addonskit-for-bricks' ),
			'type'  => 'border',
			'css'   => [
				[
					'property' => 'border',
					'selector' => '.directorist-add-listing-form .directorist-content-module',
				],
			],
			'inline' => true,
			'small'  => true,
		];

		$this->controls[$prefix . '_boxshadow'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Box Shadow', 'addonskit-for-bricks' ),
			'type' => 'box-shadow',
			'css' => [
				[
				'property' => 'box-shadow',
				'selector' => '.directorist-add-listing-form .directorist-content-module',
				],
			],
			'inline' => true,
			'small' => true,
		];
	}

	protected function set_form_steps_controls( $prefix, $group ) {
		$this->controls[$prefix . '_item_gap'] = [
			'group' => $group,
			'label' => esc_html__( 'Step Item Gap', 'addonskit-for-bricks' ),
			'type'  => 'number',
			'css'   => [
				[
					'property' => 'gap',
					'selector' => '.multistep-wizard__nav',
				],
			],
			'units' => true,
		];

		$this->controls[$prefix . '_link_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Text Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'color',
					'selector' => '.multistep-wizard__nav__btn',
				],
				[
					'property' => 'background-color',
					'selector' => '.multistep-wizard__nav__btn i:after',
				]
			],
		];

		$this->controls[$prefix . '_link_background'] = [ // Setting key
			'tab'   => 'content',
			'group' => $group,
			// 'label' => esc_html__( 'Item Background', 'addonskit-for-bricks' ),
			'type'  => 'background',
			'css'   => [
				[
					'property' => 'background',
					'selector' => '.multistep-wizard__nav__btn',
				],
			],
			'exclude' => [
				  // 'color',
				'image',
				'parallax',
				'attachment',
				'position',
				'positionX',
				'positionY',
				'repeat',
				'size',
				'custom',
				'videoUrl',
				'videoScale',
				'blendMode'
			],
			'inline'  => false,
			'small'   => false,
			'popup' => false,
		];

		$this->controls[$prefix . '_typography'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Typography', 'addonskit-for-bricks' ),
			'type' => 'typography',
			'css' => [
				[
					'property' => 'typography',
					'selector' => '.multistep-wizard__nav__btn',
				],
			],
			'inline' => true,
			'exclude' => [
				'color',
				'text-align',
				'text-decoration',
			//   'font-family',
			//   'font-weight',
			//   'text-transform',
			//   'font-size',
			//   'line-height',
			//   'letter-spacing',
			//   'text-shadow',
			],
			'popup' => true, // Default: true
		];
	}

	protected function set_form_section_header_controls( $prefix, $group ) {
		$this->controls[$prefix . '_border'] = [
			'group' => $group,
			'label' => esc_html__( 'Border Width', 'addonskit-for-bricks' ),
			'type'  => 'number',
			'css'   => [
				[
					'property' => 'border-width',
					'selector' => '.directorist-content-module__contents',
				],
			],
			'units' => true,
		];

		$this->controls[$prefix . '_border_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Border Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'border-color',
					'selector' => '.directorist-content-module__contents',
				]
			],
		];

		$this->controls[$prefix . '_typography'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Typography', 'addonskit-for-bricks' ),
			'type' => 'typography',
			'css' => [
				[
					'property' => 'typography',
					'selector' => '.directorist-content-module__title h2',
				],
			],
			'inline' => true,
			'exclude' => [
				// 'color',
				'text-align',
				// 'text-decoration',
				// 'font-family',
				// 'font-weight',
				// 'text-transform',
				// 'font-size',
				// 'line-height',
				// 'letter-spacing',
				// 'text-shadow',
			],
			'popup' => true, // Default: true
		];
	}

	protected function set_form_fields_controls( $prefix, $group ) {
		$this->controls[$prefix . '_label_typography'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Label Typography', 'addonskit-for-bricks' ),
			'type' => 'typography',
			'css' => [
				[
					'property' => 'typography',
					'selector' => '.directorist-form-label',
				],
			],
			'inline' => true,
			'exclude' => [
				// 'color',
				// 'text-align',
				// 'text-decoration',
				// 'font-family',
				// 'font-weight',
				// 'text-transform',
				// 'font-size',
				// 'line-height',
				// 'letter-spacing',
				// 'text-shadow',
			],
			'popup' => true, // Default: true
		];

		$this->controls[$prefix . '_border'] = [
			'group' => $group,
			'label' => esc_html__( 'Border Width', 'addonskit-for-bricks' ),
			'type'  => 'number',
			'css'   => [
				[
					'property' => 'border-width',
					'selector' => '.directorist-form-group .directorist-form-element, .directorist-form-group .wp-editor-container',
				],
				[
					'property' => 'border-width',
					'selector' => '.directorist-form-group .select2-container--default .select2-selection',
				],
			],
			'units' => true,
		];

		$this->controls[$prefix . '_border_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Border Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'border-color',
					'selector' => '.directorist-form-group .directorist-form-element, .directorist-form-group .wp-editor-container',
				],
				[
					'property' => 'border-color',
					'selector' => '.directorist-form-group .select2-container--default .select2-selection',
				],
			],
		];
	}

	protected function set_form_buttons_controls( $prefix, $group ) {
		$this->controls[$prefix . '_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Text Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'color',
					'selector' => '.default-add-listing-bottom .directorist-btn.directorist-btn-primary',
				]
			],
		];

		$this->controls[$prefix . '_background'] = [ // Setting key
			'tab'   => 'content',
			'group' => $group,
			// 'label' => esc_html__( 'Item Background', 'addonskit-for-bricks' ),
			'type'  => 'background',
			'css'   => [
				[
					'property' => 'background',
					'selector' => '.default-add-listing-bottom .directorist-btn.directorist-btn-primary',
				],
			],
			'exclude' => [
				  // 'color',
				'image',
				'parallax',
				'attachment',
				'position',
				'positionX',
				'positionY',
				'repeat',
				'size',
				'custom',
				'videoUrl',
				'videoScale',
				'blendMode'
			],
			'inline'  => false,
			'small'   => false,
			'popup' => false,
		];

		$this->controls[$prefix . '_border_color'] = [
			'tab' => 'content',
			'group' => $group,
			'label' => esc_html__( 'Border Color', 'addonskit-for-bricks' ),
			'type' => 'color',
			'inline' => true,
			'css' => [
				[
					'property' => 'border-color',
					'selector' => '.default-add-listing-bottom .directorist-btn.directorist-btn-primary',
				]
			],
		];
	}

	public function enqueue_scripts() {
		wp_enqueue_script( 'directorist-select2-script' );
		wp_enqueue_script( 'directorist-add-listing' );
	}
	
	public function render() {
		$params = [];

		if ( directorist_is_multi_directory_enabled() && ! empty( $this->settings['directory'] ) ) {
			$directory                = $this->get_setting( 'directory' );
			$params['directory_type'] = is_array( $directory ) ? implode( ',', $directory ) : $directory;
		}

		if ( Utils::maybe_editor() && directorist_is_multi_directory_enabled() && $this->get_setting( 'form_preview' ) ) {
			$default_directory = directorist_get_directories( array( 
				'default_only' => true,
			) );

			$params['directory_type'] = $default_directory[0]->slug;
		}

		echo "<div {$this->render_attributes( '_root' )}>";
			Utils::do_shortcode( 'directorist_add_listing', $params );
		echo '</div>';
	}
}
