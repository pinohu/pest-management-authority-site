<?php

namespace WpWax\AKFB\Elements\Styles;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

trait Container {
	
	public function set_container_controls( $prefix, $group, $selector ) {
		$this->controls[ $prefix . '_margin'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Margin', 'addonskit-for-bricks' ),
			'type'  => 'spacing',
			'css'   => [
				[
					'property' => 'margin',
					'selector' => $selector,
				]
			],
		];

		$this->controls[ $prefix . '_padding'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Padding', 'addonskit-for-bricks' ),
			'type'  => 'spacing',
			'css'   => [
				[
					'property' => 'padding',
					'selector' => $selector,
				]
			],
		];
				
		$this->controls[$prefix . '_background'] = [ // Setting key
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Background', 'addonskit-for-bricks' ),
			'type'  => 'background',
			'css'   => [
				[
					'property' => 'background',
					'selector' => $selector,
				],
			],
			'exclude' => [
				  // 'color',
				// 'image',
				// 'parallax',
				// 'attachment',
				// 'position',
				// 'positionX',
				// 'positionY',
				// 'repeat',
				// 'size',
				'custom',
				'videoUrl',
				'videoScale',
			],
			'inline'  => true,
			'small'   => true,
			'default' => [],
		];
		
		$this->controls[$prefix . '_border'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Border', 'addonskit-for-bricks' ),
			'type'  => 'border',
			'css'   => [
				[
					'property' => 'border',
					'selector' => $selector,
				],
			],
			'inline'  => true,
			'small'   => true,
			'default' => [],
		];
		
		$this->controls[ $prefix . '_box_shadow'] = [
			'tab'   => 'content',
			'group' => $group,
			'label' => esc_html__( 'Box Shadow', 'addonskit-for-bricks' ),
			'type'  => 'box-shadow',
			'css'   => [
				[
					'property' => 'box-shadow',
					'selector' => $selector,
				],
			],
			'inline'  => true,
			'small'   => true,
			'default' => [],
		];
	}
	
}
