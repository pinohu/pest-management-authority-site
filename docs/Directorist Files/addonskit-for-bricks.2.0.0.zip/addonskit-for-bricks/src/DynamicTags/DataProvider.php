<?php
namespace WpWax\AKFB\DynamicTags;

use WpWax\AKFB\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DataProvider {

	public static function init() {
		add_filter( 'bricks/dynamic_data/register_providers', static function( $providers ) {
			require_once __DIR__ . '/Provider.php';

			$providers[] = 'listing';

			return $providers;
		} );

		// add_filter( 'bricks/dynamic_tags_list', array( $this, 'add_tags' ) );
		
		// add_filter( 'bricks/frontend/render_data', array( $this, 'render_tag' ), 10, 2 );
		// add_filter( 'bricks/dynamic_data/render_content', array( $this, 'render_tag' ), 10, 3 );
		// add_filter( 'bricks/dynamic_data/render_tag', array( $this, 'get_tag_value' ), 10, 3 );
	}

	// public function add_tags( $tags ) {
	// 	// TODO: add common tags
	// 	// review count, review rating, view count

	// 	// TODO: filter admin fields
	// 	$ignorable_fields = array(
	// 		'listing-type',
	// 		'location',
	// 		'tag',
	// 		'category',
	// 		'hide_contact_owner',
	// 		'social_info',
	// 		'map',
	// 	);

	// 	if ( directorist_is_multi_directory_enabled() ) {
	// 		/** translators: %s - Directory name */
	// 		$group = _x( '%s Listing', 'Tag group name', 'addonskit-for-bricks' );

	// 		$directories = directorist_get_directories( array(
	// 			'fields'  => 'id=>name',
	// 			'orderby' => 'term_id',
	// 			'order'   => 'asc',
	// 		) );

	// 		foreach ( $directories as $directory_id => $directory_name ) {
	// 			$fields = directorist_get_listing_form_fields( $directory_id );

	// 			foreach ( $fields as $key => $field ) {
	// 				if ( in_array( $key, $ignorable_fields, true ) ) {
	// 					continue;
	// 				}

	// 				$tags[] = $this->get_tag( $key, $field['label'], esc_html( sprintf( $group, $directory_name ) ) );
	// 			}
	// 		}
	// 	} else {
	// 		$group  = _x( 'Listing', 'Tag group name', 'addonskit-for-bricks' );
	// 		$fields = directorist_get_listing_form_fields( directorist_get_default_directory() );

	// 		foreach ( $fields as $key => $field ) {
	// 			if ( in_array( $key, $ignorable_fields, true ) ) {
	// 				continue;
	// 			}
				
	// 			$tags[] = $this->get_tag( $key, $field['label'], esc_html( $group ) );
	// 		}
	// 	}

	// 	return $tags;
	// }

	// protected function get_tag( $key, $label, $group ) {
	// 	return array(
	// 		'name'  => '{listing:' . $key . '}',
	// 		'label' => $label,
	// 		'group' => $group,
	// 	);
	// }

	// public function get_tag_value( $tag, $post, $context = 'text' ) {
	// 	if ( strpos( $tag, 'listing:' ) === false ) {
	// 		return $tag;
	// 	}
		
	// 	// Get argument
	// 	$key = str_replace( 'listing:', '', $tag );

	// 	$value = $this->get_field_value( $key, $post, $context );
	
	// 	return $value;
	// }

	// public function render_tag( $content, $post, $context = 'text' ) {
	// 	if ( strpos( $content, '{listing:' ) === false ) {
	// 		return $content;
	// 	}
			
	// 	// Regex to match listing: tag
	// 	preg_match_all( '/{(listing:[^}]+)}/', $content, $matches );

	// 	// Nothing grouped in the regex, return the original content
	// 	if ( empty( $matches[0] ) ) {
	// 		return $content;
	// 	}

	// 	foreach ( $matches[1] as $key => $match ) {
	// 		$tag     = $matches[0][ $key ];
	// 		$value   = $this->get_tag_value( $match, $post, $context );
	// 		$content = str_replace( $tag, $value, $content );
	// 	}

	// 	return $content;
	// }

	// protected function get_field_value( $key, $post, $context = 'text' ) {
	// 	if ( empty( $post ) || ! directorist_is_listing_post_type( $post->ID ) ) {
	// 		return;
	// 	}

	// 	$directory_id = (int) get_post_meta( $post->ID, '_directory_type', true );
	// 	$field         = directorist_get_listing_form_field( $directory_id, $key );

	// 	if ( empty( $field ) ) {
	// 		return;
	// 	}

	// 	$type   = empty( $field['type'] ) ? $field['widget_key'] : $field['type'];
	// 	$method = 'get_' . $type . '_field';

	// 	if ( ! method_exists( $this, $method ) ) {
	// 		return;
	// 	}

	// 	return $this->{$method}( $field, $post->ID, $context );
	// }

	// protected function get_text_field( $field, $listing_id, $context ) {
	// 	if ( $field['widget_key'] === 'title' ) {
	// 		return get_the_title( $listing_id );
	// 	}

	// 	return get_post_meta( $listing_id, '_' . $field['field_key'], true );
	// }

	// protected function get_tel_field( $field, $listing_id, $context ) {
	// 	return get_post_meta( $listing_id, '_' . $field['field_key'], true );
	// }

	// protected function get_email_field( $field, $listing_id, $context ) {
	// 	return get_post_meta( $listing_id, '_' . $field['field_key'], true );
	// }

	// protected function get_number_field( $field, $listing_id, $context ) {
	// 	return get_post_meta( $listing_id, '_' . $field['field_key'], true );
	// }

	// protected function get_date_field( $field, $listing_id, $context ) {
	// 	$value = get_post_meta( $listing_id, '_' . $field['field_key'], true );
		
	// 	if ( empty( $value ) ) {
	// 		return;
	// 	}

	// 	return date( get_option( 'date_format' ), strtotime( $value ) );
	// }

	// protected function get_time_field( $field, $listing_id, $context ) {
	// 	$value = get_post_meta( $listing_id, '_' . $field['field_key'], true );
		
	// 	if ( empty( $value ) ) {
	// 		return;
	// 	}

	// 	return date( get_option( 'time_format' ), strtotime( $value ) );
	// }

	// protected function get_textarea_field( $field, $listing_id, $context ) {
	// 	if ( $field['widget_key'] === 'excerpt' ) {
	// 		$value = get_the_excerpt( $listing_id );
	// 	}

	// 	if ( empty( $value ) ) {
	// 		$value = get_post_meta( $listing_id, '_' . $field['field_key'], true );
	// 	}

	// 	return esc_textarea( $value );
	// }

	// protected function get_wp_editor_field( $field, $listing_id, $context ) {
	// 	if ( $field['widget_key'] === 'description' ) {
	// 		$value = get_the_content( $listing_id );
	// 	}

	// 	if ( empty( $value ) ) {
	// 		$value = get_post_meta( $listing_id, '_' . $field['field_key'], true );
	// 	}

	// 	return wp_kses_post( $value );
	// }

	// protected function get_pricing_field( $field, $listing_id, $context ) {
	// 	return get_post_meta( $listing_id, '_price', true );
	// }

	// protected function get_color_field( $field, $listing_id, $context ) {
	// 	return get_post_meta( $listing_id, '_' . $field['field_key'], true );
	// }

	// protected function get_select_field( $field, $listing_id, $context ) {
	// 	$value = get_post_meta( $listing_id, '_' . $field['field_key'], true );
	// 	if ( empty( $value ) ) {
	// 		return;
	// 	}
		
	// 	return $this->get_value_from_options( $field, array( $value ) );
	// }

	// protected function get_checkbox_field( $field, $listing_id, $context ) {
	// 	$value = get_post_meta( $listing_id, '_' . $field['field_key'], true );
	// 	if ( empty( $value ) || ! is_array( $value ) ) {
	// 		return;
	// 	}
		
	// 	return $this->get_value_from_options( $field, $value );
	// }

	// protected function get_radio_field( $field, $listing_id, $context ) {
	// 	$value = get_post_meta( $listing_id, '_' . $field['field_key'], true );
	// 	if ( empty( $value ) ) {
	// 		return;
	// 	}
		
	// 	return $this->get_value_from_options( $field, array( $value ) );
	// }

	// protected function get_value_from_options( $field, $values ) {
	// 	if ( empty( $field['options'] ) || ! is_array( $field['options'] ) ) {
	// 		return;
	// 	}

	// 	$options = wp_list_pluck( $field['options'], 'option_label', 'option_value' );
	// 	$out     = '';

	// 	foreach ( $values as $value ) {
	// 		$out .= $options[ $value ] . ', ';
	// 	}

	// 	return rtrim( $out, ', ' );
	// }

	// protected function get_file_field( $field, $listing_id, $context ) {
	// 	$value = get_post_meta( $listing_id, '_' . $field['field_key'], true );
		
	// 	if ( empty( $value ) ) {
	// 		return;
	// 	}

	// 	return str_replace( '|||', '', $value );
	// }

	// protected function get_media_field( $field, $listing_id, $context ) {
	// 	$field_key = $field['field_key'];
	// 	$value    = array();

	// 	if ( $field_key === 'listing_img' ) {
	// 		$value = atbdp_get_listing_attachment_ids( $listing_id );
	// 	} else {
	// 		$value = get_post_meta( $listing_id, '_' . $field_key, true );
	// 		if ( ! empty( $value ) && is_array( $value ) ) {
	// 			$value = wp_parse_id_list( array_values( $value ) );
	// 		}
	// 	}

	// 	// if ( $context === 'image' ) {
	// 	// 	return $value;
	// 	// }

	// 	// file_put_contents(__DIR__ . '/data.txt', print_r( [$context, $listing_id, $value], 1 ) . "\n", FILE_APPEND );

	// 	// if ( $context === 'image' ) {
	// 	// 	return $value;
	// 	// }
		
	// 	return 151; //implode( ',', $value );
	// }
}
