<?php
namespace Bricks\Integrations\Dynamic_Data\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Bricks\Integrations\Dynamic_Data\Providers\Base as Provider_Base;

class Provider_Listing extends Provider_Base {

	static protected $ignorable_fields = [
		'listing-type',
		'location',
		'tag',
		'category',
		'hide_contact_owner',
		// 'social_info',
		'map',
	];

	static protected $builtin_fields = [
		'title',
		'description',
		'excerpt'
	];

	public static function load_me() {
		return true; // check directorist exists
	}

	public function register_tags() {
		$fields = self::get_fields();

		// $contexts = self::get_fields_by_context();

		foreach ( $fields as $field ) {
			$type = $field['type'];

			// if ( ! isset( $contexts[ $type ] ) ) {
			// 	continue;
			// }

			// foreach ( $contexts[ $type ] as $context ) {
			// 	$key = 'cmb2_' . $field['name'];

				// $name = self::CONTEXT_TEXT === $context ? $key : $key . '_' . $context;
				$name = 'listing_' . $field['directory'] . '_' . $field['name'];

				$this->tags[ $name ] = [
					'name'     => '{' . $name . '}',
					'label'    => $field['label'],
					'group'    => $field['group'],
					'field'    => $field,
					'provider' => $this->name,
				];

				// if ( self::CONTEXT_TEXT !== $context ) {
				// 	$this->tags[ $name ]['deprecated'] = 1;
				// }
			// }
		}
	}

	protected static function get_fields() {
		$fields_list = [];

		if ( directorist_is_multi_directory_enabled() ) {
			/** translators: %s - Directory name */
			$group = _x( '%s Listing', 'Tag group name', 'addonskit-for-bricks' );

			$directories = directorist_get_directories( array(
				'fields'  => 'id=>name',
				'orderby' => 'term_id',
				'order'   => 'asc',
			) );

			foreach ( $directories as $directory_id => $directory_name ) {
				$fields      = directorist_get_listing_form_fields( $directory_id );
				$fields_list = self::add_fields_to_list( $fields_list, $fields, esc_html( sprintf( $group, $directory_name ) ), $directory_id );
			}
		} else {
			$group        = _x( 'Listing', 'Tag group name', 'addonskit-for-bricks' );
			$directory_id = directorist_get_default_directory();
			$fields       = directorist_get_listing_form_fields( $directory_id );
			$fields_list  = self::add_fields_to_list( $fields_list, $fields, $group, $directory_id );
		}

		return $fields_list;
	}

	/**
	 * Helper function to map raw field object to internal format
	 *
	 * @param array $list Final list.
	 * @param array $fields raw.
	 *
	 * @return array
	 */
	public static function add_fields_to_list( $fields_list, $fields, $group, $directory ) {
		foreach ( $fields as $key => $field ) {
			if ( in_array( $key, self::$ignorable_fields, true ) ) {
				continue;
			}

			$new = [
				'label'     => isset( $field['label'] ) ? $field['label'] : $key,
				'name'      => $key,
				'type'      => isset( $field['type'] ) ? $field['type'] : $key,
				'group'     => $group,
				'directory' => $directory,
				'meta_key'  => isset( $field['field_key'] ) ? $field['field_key'] : $key,
			];

			if ( isset( $field['options'] ) ) {
				$new['options'] = $field['options'];
			}

			$fields_list[] = $new;
		}

		return $fields_list;
	}

	public function get_tag_value( $tag, $post, $args, $context ) {
		$post_id = isset( $post->ID ) ? $post->ID : '';
		$field   = $this->tags[ $tag ]['field'];
		$name    = $field['name'];
		$type = $field['type'];

		// STEP: Check for filter args
		$filters = $this->get_filters_from_args( $args );

		if ( in_array( $name, self::$builtin_fields, true ) ) {
			if ( $name === 'title' ) {
				$value = get_the_title( $post_id );
			} else if ( $name === 'description' ) {
				$value = \Bricks\Helpers::parse_editor_content( get_the_content( $post_id ) );
			} else if ( $name === 'excerpt' ) {
				$value = get_the_excerpt( $post_id );
			}
		} else {
			$value = get_post_meta( $post_id, '_' . $field['meta_key'], true );
		}

		if ( $type === 'media' ) {
			if ( $name === 'image_upload' ) {
				$value = atbdp_get_listing_attachment_ids( $post_id );
			} elseif ( is_array( $value ) ) {
				$value = wp_parse_id_list( array_values( $value ) );
			}
		}

		if ( $name === 'social_info' && ! empty( $value ) && is_array( $value ) ) {
			$new_value = '';
			foreach ( $value as $v ) {
				if ( $v['id'] === $filters['meta_key'] && ! empty( $v['url'] ) ) {
					$new_value = $v['url'];
					break;
				}
			}
			$value = $new_value;
		}

		// // STEP: Get the value
		// $value = 'file' == $field['type'] ?  : get_post_meta( $post_id, $field['name'], true );

		$value = ! is_array( $value ) ? [ $value ] : $value;

		

		// // Legacy from previous code (before Bricks 1.3.5)
		// $filters['separator'] = '<br>';

		// switch ( $field['type'] ) {
		// 	case 'file_list':
		// 		$filters['object_type'] = 'media';
		// 		$filters['link']        = true;
		// 		$value                  = ! empty( $value ) && is_array( $value ) ? array_keys( $value ) : [];
		// 		break;

		// 	case 'file':
		// 		$filters['object_type'] = 'media';
		// 		if ( empty( $filters['image'] ) ) {
		// 			$filters['link'] = true;
		// 		}
		// 		break;

		// 	case 'textarea':
		// 	case 'textarea_small':
		// 		$value = array_map( 'nl2br', $value );
		// 		break;

		// 	case 'textarea_code':
		// 		$theme_styles = \Bricks\Theme_Styles::$active_settings;
		// 		$classes      = isset( $theme_styles['code']['prettify'] ) ? 'prettyprint ' . $theme_styles['code']['prettify'] : '';

		// 		foreach ( $value as $key => $item ) {
		// 			$value[ $key ] = '<pre class="' . $classes . '"><code>' . $item . '</code></pre>';
		// 		}
		// 		break;

		// 	case 'text_date_timestamp':
		// 	case 'text_datetime_timestamp':
		// 	case 'text_datetime_timestamp_timezone':
		// 		$filters['object_type'] = 'date';

		// 		if ( ! isset( $filters['meta_key'] ) && strpos( $field['type'], 'datetime' ) ) {
		// 			$filters['meta_key'] = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
		// 		}
		// 		break;

		// 	case 'radio':
		// 	case 'radio_inline':
		// 	case 'select':
		// 	case 'multicheck':
		// 	case 'multicheck_inline':
		// 		foreach ( $value as $key => $item ) {
		// 			$item          = (array) $item;
		// 			$item          = array_intersect_key( $field['options'], array_fill_keys( $item, '' ) );
		// 			$value[ $key ] = implode( ', ', $item );
		// 		}
		// 		break;

		// 	case 'checkbox':
		// 		foreach ( $value as $key => $item ) {
		// 			$original_value = $item;
		// 			$item           = $original_value == 'on' ? esc_html__( 'Yes', 'addonskit-for-bricks' ) : esc_html__( 'No', 'addonskit-for-bricks' );

		// 			/**
		// 			 * NOTE: Undocumented
		// 			 */
		// 			$value[ $key ] = apply_filters( 'bricks/cmb2/checkbox_value', $item, $original_value, $field, $post );
		// 		}
		// 		break;

		// 	case 'wysiwyg':
		// 		$filters['separator'] = ' ';

		// 		foreach ( $value as $key => $item ) {
		// 			$value[ $key ] = \Bricks\Helpers::parse_editor_content( $item );
		// 		}
		// 		break;

		// 	case 'oembed':
		// 		if ( $context === 'text' ) {
		// 			$filters['separator']     = '';
		// 			$filters['skip_sanitize'] = true;

		// 			foreach ( $value as $key => $item ) {
		// 				$value[ $key ] = wp_oembed_get( esc_url( $item ) );
		// 			}
		// 		}
		// 		break;
		// }

		// STEP: Apply context (text, link, image, media)
		$value = $this->format_value_for_context( $value, $tag, $post_id, $filters, $context );

		return $value;
	}

	/**
	 * Get all fields supported and their contexts
	 *
	 * @return array
	 */
	private static function get_fields_by_context() {
		$fields = [
			// Note: Taxonomy fields are not saved as custom fields
			'text'                             => [ self::CONTEXT_TEXT ],
			'text_small'                       => [ self::CONTEXT_TEXT ],
			'text_medium'                      => [ self::CONTEXT_TEXT ],
			'text_email'                       => [ self::CONTEXT_TEXT, self::CONTEXT_LINK ],
			'text_url'                         => [ self::CONTEXT_TEXT, self::CONTEXT_LINK ],
			'text_money'                       => [ self::CONTEXT_TEXT ],
			'textarea'                         => [ self::CONTEXT_TEXT ],
			'textarea_small'                   => [ self::CONTEXT_TEXT ],
			'textarea_code'                    => [ self::CONTEXT_TEXT ],

			'text_time'                        => [ self::CONTEXT_TEXT ],
			'select_timezone'                  => [ self::CONTEXT_TEXT ],
			'text_date'                        => [ self::CONTEXT_TEXT ],
			'text_date_timestamp'              => [ self::CONTEXT_TEXT ],
			'text_datetime_timestamp'          => [ self::CONTEXT_TEXT ],
			'text_datetime_timestamp_timezone' => [ self::CONTEXT_TEXT ],

			'colorpicker'                      => [ self::CONTEXT_TEXT ],

			'radio'                            => [ self::CONTEXT_TEXT ],
			'radio_inline'                     => [ self::CONTEXT_TEXT ],
			'select'                           => [ self::CONTEXT_TEXT ],
			'checkbox'                         => [ self::CONTEXT_TEXT ],
			'multicheck'                       => [ self::CONTEXT_TEXT ],
			'multicheck_inline'                => [ self::CONTEXT_TEXT ],

			'wysiwyg'                          => [ self::CONTEXT_TEXT ],

			'file'                             => [ self::CONTEXT_TEXT, self::CONTEXT_LINK, self::CONTEXT_IMAGE, self::CONTEXT_VIDEO, self::CONTEXT_MEDIA ],
			'file_list'                        => [ self::CONTEXT_TEXT, self::CONTEXT_LINK, self::CONTEXT_IMAGE, self::CONTEXT_VIDEO, self::CONTEXT_MEDIA ],
			'oembed'                           => [ self::CONTEXT_TEXT, self::CONTEXT_LINK, self::CONTEXT_VIDEO, self::CONTEXT_MEDIA ],
		];

		return $fields;
	}
}
