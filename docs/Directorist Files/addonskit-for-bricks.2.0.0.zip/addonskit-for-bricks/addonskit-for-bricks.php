<?php
/**
 * Plugin Name: Addonskit for Bricks
 * Description: Custom elements for Bricks builder
 * Author: wpWax
 * Author URI: https://wpwax.com
 * Version: 2.0.0
 * License: GPL2
 * Requires PHP: 7.4
 * Text Domain: addonskit-for-bricks
 * Domain Path: /i18n/languages/
 *
 * Released under the GPL license
 * http://www.opensource.org/licenses/gpl-license.php
 *
 *
 * **********************************************************************
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * **********************************************************************
 */

// don't call the file directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AKFB_PLUGIN_FILE', __FILE__ );
define( 'AKFB_PLUGIN_DIR', __DIR__ );
define( 'AKFB_VERSION', '2.0.0' );
define( 'AKFB_REQUIRED_MIN_PHP_VERSION', '7.4.0' );

function akfb_is_supported_php() {
	return version_compare( PHP_VERSION, AKFB_REQUIRED_MIN_PHP_VERSION, '>=' );
}

function akfb_auto_deactivate() {
	if ( akfb_is_supported_php() ) {
		return;
	}

	deactivate_plugins( basename( AKFB_PLUGIN_FILE ) );

	$error = '<h1>' . __( 'An Error Occurred', 'addonskit-for-bricks' ) . '</h1>';
	$error .= '<h2>' . sprintf( __( 'Your installed PHP version is: %s', 'addonskit-for-bricks' ), PHP_VERSION ) . '</h2>';
	$error .= '<p>' . sprintf( __( '%s requires at least PHP version %s or greater. Please update your PHP version as per the instruction given by WordPress.', 'addonskit-for-bricks' ), '<strong>Addonskit for Bricks</strong>', '<strong>' . AKFB_REQUIRED_MIN_PHP_VERSION . '</strong>' );
	
	wp_die(
		wp_kses_post( $error ),
		esc_html__( 'Plugin Activation Error', 'addonskit-for-bricks' ),
		[
			'response'  => 200,
			'back_link' => true,
		]
	);
}

register_activation_hook( AKFB_PLUGIN_FILE, 'akfb_auto_deactivate' );

if ( ! akfb_is_supported_php() ) {
	return;
}

function akfb_is_plugin_installed( $basename ) {
	if ( ! function_exists( 'get_plugins' ) ) {
		include_once ABSPATH . '/wp-admin/includes/plugin.php';
	}

	$installed_plugins = get_plugins();

	return isset( $installed_plugins[ $basename ] );
}

function akfb_directorist_missing_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	$directorist_root = 'directorist/directorist-base.php';

	if ( akfb_is_plugin_installed( $directorist_root ) ) {
		$activation_url = wp_nonce_url( 'plugins.php?action=activate&amp;plugin=' . $directorist_root . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $directorist_root );
		$message        = sprintf( __( '%1$s requires %2$s plugin to be active. Please activate %2$s to continue.', 'addonskit-for-bricks' ), '<strong>Addonskit for Bricks</strong>', '<strong>Directorist</strong>' );
		$button_text    = __( 'Activate Directorist', 'addonskit-for-bricks' );
	} else {
		$activation_url = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=directorist' ), 'install-plugin_directorist' );
		$message        = sprintf( __( '%1$s requires %2$s plugin to be installed and activated. Please install %2$s to continue.', 'addonskit-for-bricks' ), '<strong>Addonskit for Bricks</strong>', '<strong>Directorist</strong>' );
		$button_text    = __( 'Install Directorist', 'addonskit-for-bricks' );
	}

	$button = '<p><a href="' . esc_url( $activation_url ) . '" class="button-primary">' . esc_html( $button_text ) . '</a></p>';

	printf( '<div class="error"><p style="font-size: 16px">%1$s</p>%2$s</div>', wp_kses_post( $message ), wp_kses_post( $button ) );
}

function akfb_directorist_required_version_notice() {
	$message = sprintf(
		__( '%1$s requires at least %2$s or greater but your installed version is %3$s.', 'addonskit-for-bricks' ),
		'<strong>Addonskit for Bricks</strong>',
		'<strong>Directorist 8.0</strong>',
		'<strong>Directorsit ' . ATBDP_VERSION . '</strong>'
	);

	printf( '<div class="error"><p style="font-size: 16px">%s</p></div>', wp_kses_post( $message ) );
}

function akfb_bricks_missing_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	$message = sprintf( __( '%1$s requires %2$s theme to be installed and activated. Please install and activate %2$s theme to continue.', 'addonskit-for-bricks' ), '<strong>Addonskit for Bricks</strong>', '<strong>Bricks</strong>' );

	printf( '<div class="error"><p style="font-size: 16px">%1$s</p></div>', wp_kses_post( $message ) );
}

function akfb_is_required_dependencies_installed() {
	if ( wp_get_theme()->get_template() !== 'bricks' ) {
		add_action( 'admin_notices', 'akfb_bricks_missing_notice' );
		return false;
	}

	if ( ! did_action( 'directorist_loaded' ) ) {
		add_action( 'admin_notices', 'akfb_directorist_missing_notice' );
		return false;
	}

	if ( ATBDP_VERSION < '8.0.0' ) {
		add_action( 'admin_notices', 'akfb_directorist_required_version_notice' );
		return false;
	}

	return true;
}

add_action( 'plugins_loaded', static function() {
	if ( ! akfb_is_required_dependencies_installed() ) {
		return;
	}

	require_once AKFB_PLUGIN_DIR . '/src/Plugin.php';

	\WpWax\AKFB\Plugin::instance();
}, 20 );
