<?php
/**
 * BuddyPress listing loader.
 * 
 * @package wpWax\Directorist\BuddyPress
 * @since Directorist\BuddyPress 1.0.0
 */
defined( 'ABSPATH' ) || die();

use wpWax\Directorist\BuddyPress\BP_Listings_Component;

/**
 * Set up the bp-listings component.
 */
function dbp_setup_listings_component() {
	buddypress()->listings = new BP_Listings_Component();
}
add_action( 'bp_loaded', 'dbp_setup_listings_component' );
