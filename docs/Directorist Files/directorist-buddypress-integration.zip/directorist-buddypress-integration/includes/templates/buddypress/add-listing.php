<?php
/**
 * BP profile add listing template.
 * 
 * @package Directorist_BuddyPress_Integration
 */

defined( 'ABSPATH' ) || die();
?>

<?php do_action( 'bp_before_member_' . bp_current_action() . '_content' ); ?>

<?php echo dbp_run_shortcode_callback( 'directorist_add_listing' ); ?>

<?php do_action( 'bp_after_member_' . bp_current_action() . '_content' ); ?>
