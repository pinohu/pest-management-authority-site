const wpPot = require('wp-pot');
 
wpPot({
  destFile: './languages/directorist-buddypress-integration.pot',
  domain: 'directorist-buddypress-integration',
  package: 'Directorist BuddyPress Integration',
  src: './**/*.php'
});