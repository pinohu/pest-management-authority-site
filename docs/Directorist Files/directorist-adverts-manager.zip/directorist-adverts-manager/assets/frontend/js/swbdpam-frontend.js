/**
 * @package  Directorist - Ads Manager
 */