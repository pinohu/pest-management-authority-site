/**
 * @package  Directorist - Ads Manager
 */


(function($){
    $(function(){
        // This id is textarea input field. Which made textarea input field to code editor
        if( $( '#swbdpam__custom-code' ).length ){
            var editorSettings = wp.codeEditor.defaultSettings ? _.clone( wp.codeEditor.defaultSettings ) : {};
            editorSettings.codemirror = _.extend(
                {},
                editorSettings.codemirror,
                {
                    indentUnit: 4,
                    tabSize: 4,
                }
            );
            var editor = wp.codeEditor.initialize( $( '#swbdpam__custom-code' ), editorSettings );
        }

    });
})(jQuery);


