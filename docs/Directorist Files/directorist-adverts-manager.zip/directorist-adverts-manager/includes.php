<?php
/**
 * @package  Directorist - Ads Manager
 */

if( ! class_exists( 'SWBDPAMIncludeClasses' ) ){
    /**
     * All classes includer class
     */
    class SWBDPAMIncludeClasses
    {   
        /**
         * This function include all classes
         * 
         * @return void
         */
        public static function includes()
        {
            $files = array(
                'Inc/Controller/Base/Enqueue',
                'Inc/Controller/Base/Activate',
                'Inc/Controller/Base/DynamicStyle',
                'Inc/Controller/Base/WidgetsHandler',
                'Inc/Controller/Base/HelperFunctions',
                'Inc/Controller/Base/ShortcodeHandler',
                'Inc/Controller/Base/ExtensionSettings',
                'Inc/Controller/Admin/AdsManagerCPT',
                'Inc/Controller/Admin/CustomWpListTable',
                'Inc/Controller/AdDisplayPages/PageAddListing',
                'Inc/Controller/AdDisplayPages/PageAllListings',
                'Inc/Controller/AdDisplayPages/PageAuthorListing',
                'Inc/Controller/AdDisplayPages/PageDashboard',
                'Inc/Controller/AdDisplayPages/PageSearchHome',
                'Inc/Controller/AdDisplayPages/PageSearchResult',
                'Inc/Controller/AdDisplayPages/PageAllCategories',
                'Inc/Controller/AdDisplayPages/PageSingleCategory',
                'Inc/Controller/AdDisplayPages/PageSingleListing',
                'Inc/Controller/AdDisplayPages/PageAllLocations',
                'Inc/Controller/AdDisplayPages/PageSingleLocation',
                'Inc/Controller/Widgets/WidgetAdsManager',
                'Inc/View/AdminCallbacks',
            );

            foreach( $files as $file ){
                $file_path = SWBDPAM_PLUGIN_DIR_PATH ."$file.php";
            
                if( file_exists( $file_path ) ){
                    require_once( $file_path ); 
                }
            }
        }

    }// End class

}