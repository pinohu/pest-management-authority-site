<?php
/**
 * @package  Directorist - Ads Manager
 */


if( ! class_exists( 'SWBDPAMWidgetsHandler' ) ){
    /**
     * Widget handler class
     */
    class SWBDPAMWidgetsHandler
    {
        /**
        * Class constructor
        * Call all hooks which we wanna triger
        */
        public function register()
        {
            // Directorist Ads Manager widgets register hook
            add_action( 'widgets_init', array( $this, 'register_ads_manager_widget' ) );
        }


        /**
         * Directorist Ads Manager widget register function
         */
        function register_ads_manager_widget()
        {
            // Include ads manager widget file 
            include SWBDPAM_PLUGIN_DIR_PATH.'Inc/Controller/Widgets/WidgetAdsManager.php';

            register_widget( 'SWBDPWidgetAdsManager' );     // This ID similar of class name
        }        

    }// End class
}