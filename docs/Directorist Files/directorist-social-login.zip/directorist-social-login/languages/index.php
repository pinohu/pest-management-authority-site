<?php
//silent is golder