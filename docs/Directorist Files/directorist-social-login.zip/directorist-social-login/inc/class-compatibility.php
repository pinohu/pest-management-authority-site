<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Directorist_Social_Login_Compatibility {

	public function __construct() {
		add_filter( 'wordfence_ls_require_captcha', '__return_false' );
	}
}

new Directorist_Social_Login_Compatibility();