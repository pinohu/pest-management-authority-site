<div class="directorist-search-popup-block__popup">
	<div class="directorist-search-popup-block__form-close">
		<?php directorist_icon( 'la times' );?>
	</div>
	<div class="dspb-container">
		<div class="dspb-row">
			<div class="directorist-search-popup-block__form">
				<?php echo do_shortcode( '[directorist_search_listing more_filters_button="no" show_title_subtitle="no" show_popular_category="no"]' ); ?>
			</div>
		</div>
	</div>
</div>