<?php return array('dependencies' => array(), 'version' => '7c8be7985e4326669d65');
