<?php
namespace SWBDP_2CHKT\Shortcodes;

class Authorize_Gateway_Checkout {
    public function render() {
        return swbdp_2chkt_load_template( 'directorist-authorize-gateway', '', 'return' );
    }
}