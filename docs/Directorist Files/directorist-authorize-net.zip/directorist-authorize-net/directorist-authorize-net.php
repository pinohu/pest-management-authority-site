<?php
/**
 * Directorist - Authorize.net
 *
 * @package           Directorist_Authorize_Net
 * @author            wpwax
 * @copyright         2019 wpwax or Company Name
 * @license           GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name:       Directorist - Authorize.net
 * Plugin URI:        https://directorist.com/product/directorist-authorize-net/
 * Description:       A checkout extension for directorist
 * Version:           2.2
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            wpwax
 * Author URI:        https://wpwax.com/
 * Text Domain:       directorist-authorize-net
 * License:           GPL v2 or later
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */


defined( 'ABSPATH' ) || exit;

// Setup The Consts.
if ( ! defined( 'SWBDP_2CHKT_PLUGIN_FILE' ) ) {
	define( 'SWBDP_2CHKT_PLUGIN_FILE', __FILE__ );
}

// plugin author url
if (!defined('ATBDP_AUTHOR_URL')) {
	define('ATBDP_AUTHOR_URL', 'https://directorist.com');
}

// post id from download post type (edd)
if (!defined('ATBDP_DIR_AUTHORIZE_POST_ID')) {
	define('ATBDP_DIR_AUTHORIZE_POST_ID', 52499);
}

// Include The Const Helpers.
$const_helper_file = plugin_dir_path( __FILE__ ) . '/helpers/const-helper.php';
require $const_helper_file;

$const_file = plugin_dir_path( __FILE__ ) . '/const.php';
require $const_file;

// Include The Helpers.
$helpers_file = SWBDP_2CHKT_PLUGIN_PATH . 'helpers/helpers.php';
require $helpers_file;

// Include The App.
$app = SWBDP_2CHKT_PLUGIN_PATH . 'app/base.php';

if (  directorist_is_plugin_active( 'directorist/directorist-base.php' ) && ! class_exists( 'Directorist_2Checkout' ) ) {
	include $app;
}

if (!class_exists('EDD_SL_Plugin_Updater')) {
	// load our custom updater if it doesn't already exist
	include(dirname(__FILE__) . '/inc/EDD_SL_Plugin_Updater.php');
}

add_action( 'admin_init', 'dir_authorize_net_update_controller' );

function dir_authorize_net_update_controller() {
	$data        = get_user_meta( get_current_user_id(), '_plugins_available_in_subscriptions', true );
	$license_key = ! empty( $data['directorist-authorize-net'] ) ? $data['directorist-authorize-net']['license'] : '';

	new EDD_SL_Plugin_Updater(ATBDP_AUTHOR_URL, __FILE__, array(
		'version' => get_plugin_data( __FILE__ )['Version'],        // current version number
		'license' => $license_key,    // license key (used get_option above to retrieve from DB)
		'item_id' => ATBDP_DIR_AUTHORIZE_POST_ID,    // id of this plugin
		'author' => 'AazzTech',    // author of this plugin
		'url' => home_url(),
		'beta' => false // set to true if you wish customers to receive update notifications of beta releases
	));
}