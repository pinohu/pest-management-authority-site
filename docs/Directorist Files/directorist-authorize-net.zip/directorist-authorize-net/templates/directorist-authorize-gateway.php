<div class="directorist-authorized-net-container">
    <div class="card-wrapper"></div>
<?php 
$order_id = !empty( $_GET['order_id'] ) ? sanitize_key( $_GET['order_id'] ) : '';
$c_position      = get_directorist_option('payment_currency_position');
$currency        = atbdp_get_payment_currency();
$symbol          = atbdp_currency_symbol($currency);
$before = ''; $after = '';
('after' == $c_position) ? $after = $symbol : $before = $symbol;
$amount = get_post_meta( $order_id, '_amount', true );
?>
    <div class="directorist-checout-card-form form-container active">
        <form id="test-checkout-form" action="#">
            <input placeholder="Card number" class="swbdp-form-controll" type="tel" name="number">
            <input placeholder="MM/YY" class="swbdp-form-controll" type="tel" name="expiry">
            <input placeholder="CVC" class="swbdp-form-controll" type="number" name="cvc">
            <input placeholder="Zip" class="swbdp-form-controll" type="text" name="zip">
            <input placeholder="Full name" class="swbdp-form-controll" type="text" name="name">
            <input placeholder="Country" class="swbdp-form-controll" type="text" name="country">
            <button type="submit" class="swbdp-btn swbdp-btn-primary swbdp-btn-block"><?php echo __( 'Pay', 'directorist-authorize-net' ). ' ' . $before . $amount . $after;?></button>
        </form>
        <div class="payment_notifier"></div>
    </div>
</div>