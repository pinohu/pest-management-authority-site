<?php

if ( ! defined( 'SWBDP_VERSION' ) ) {
	define( 'SWBDP_VERSION', swbdp_2chkt_get_version_from_file_content( SWBDP_2CHKT_PLUGIN_FILE ) );
}
if ( ! defined( 'SWBDP_2CHKT_LANG_PATH' ) ) {
	define( 'SWBDP_2CHKT_LANG_PATH', dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
if ( ! defined( 'SWBDP_2CHKT_PLUGIN_PATH' ) ) {
	define( 'SWBDP_2CHKT_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'SWBDP_2CHKT_PLUGIN_DIR_URI' ) ) {
	define( 'SWBDP_2CHKT_PLUGIN_DIR_URI', plugin_dir_url( __FILE__ ) );
}
if ( ! defined( 'SWBDP_2CHKT_ASSET_URI' ) ) {
	define( 'SWBDP_2CHKT_ASSET_URI', SWBDP_2CHKT_PLUGIN_DIR_URI . 'assets/' );
}
if ( ! defined( 'SWBDP_2CHKT_CSS_URI' ) ) {
	define( 'SWBDP_2CHKT_CSS_URI', SWBDP_2CHKT_ASSET_URI . 'css/' );
}
if ( ! defined( 'SWBDP_2CHKT_JS_URI' ) ) {
	define( 'SWBDP_2CHKT_JS_URI', SWBDP_2CHKT_ASSET_URI . 'js/' );
}
