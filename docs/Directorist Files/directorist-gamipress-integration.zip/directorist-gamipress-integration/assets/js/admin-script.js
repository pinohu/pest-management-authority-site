(function($) {
    'use strict';

    $(function() {

        $('.requirements-list').on( 'change', '.select-trigger-type', function() {
            // Setup vars
            var trigger_type = $(this).val();
            var rating_input = $(this).siblings('.gamipress-directorist-review-rating-wrap');
            var points_condition_selector = $(this).siblings('.select-points-condition');

            // Toggle variation field visibility
            if ( trigger_type === 'directorist_new_review' || trigger_type === 'directorist_get_review' ) {
                rating_input.show().find('input').css('width', '60px');
                points_condition_selector.show();
            } else {
                rating_input.hide();
            }
        });

        $('.requirements-list li').each(function() {
            // Setup vars
            var trigger_type = $(this).find('.select-trigger-type').val();
            var rating_input = $(this).find('.gamipress-directorist-review-rating-wrap');
            var points_condition_selector = $(this).find('.select-points-condition');

            if ( trigger_type === 'directorist_new_review' || trigger_type === 'directorist_get_review' ) {
                rating_input.show().find('input').css('width', '60px');
                points_condition_selector.show();
            } else {
                rating_input.hide();
            }
        });

        $('.requirements-list').on( 'update_requirement_data', '.requirement-row', function(e, requirement_details, requirement) {
            // Add the rating field
            if ( requirement_details.trigger_type === 'directorist_new_review' || requirement_details.trigger_type === 'directorist_get_review' ) {
                requirement_details.directorist_review_rating = requirement.find( '.gamipress-directorist-review-rating' ).val();
            }
        });
    });
})(jQuery);
