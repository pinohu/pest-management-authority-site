;(function($) {
    'use strict';

    $(function() {
        $('.directorist-gamipress-claim-discount').on('click', function(e) {
            e.preventDefault();
            var $button = $(this),
                $wrapper = $button.parent('.directorist-gamipress-redeem-points');

            $button.attr('disabled', true);

            $.get($button.data('url'))
                .done(function(response) {
                    if (!response.success) {
                        $wrapper.append( $('<p class="directorist-gamipress-alert"/>').html(response.data));
                    } else {
                        $button.remove();
                        $wrapper.append($('<p/>').html(response.data));
                    }
                    $button.attr('disabled', false);
                })
                .fail(function(response) {
                    console.log( response );
                    $button.attr('disabled', false);
                });
        });
    });
}(jQuery));
