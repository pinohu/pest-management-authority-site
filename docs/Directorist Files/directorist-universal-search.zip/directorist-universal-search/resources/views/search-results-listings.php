<?php
/**
 * Search Results Listings Template
 *
 * Displays listing results for a specific directory type
 * with configured display settings and pagination.
 *
 * @package Directorist_Universal_Search
 */

namespace DirectoristUS\App\Views;

defined( 'ABSPATH' ) || exit;

use Directorist\Directorist_Listings;

// Define listing display configuration
$listing_config = [
    'directory_type'    => $data->slug,
    'listings_per_page' => 3,
    'columns'           => 3,
    'show_pagination'   => false,
];

// Initialize and render listings
$listings = new Directorist_Listings( $listing_config );

if ( $listings->query_results->total ) {
    $listings->archive_view_template();
}