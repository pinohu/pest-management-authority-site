<?php
/**
 * Search Form Wrapper Template
 *
 * Provides the outer structure for the universal search form
 * with responsive grid layout.
 *
 * @package Directorist_Universal_Search
 */

defined( 'ABSPATH' ) || exit;
?>

<div class="dir-universal-search__listings directorist-w-100">
    <div class="directorist-row directorist-justify-content-center">
        <div class="directorist-col-6 directorist-all-listing-col">
            <?php include_once dirname( __FILE__ ) . '/search-form.php'; ?>
        </div>
    </div>
</div>