<?php
/**
 * Search Results Categories Template
 *
 * Displays matched categories for a specific directory type
 * with category count and view more option.
 *
 * @package Directorist_Universal_Search
 */

use DirectoristUS\App\Repositories\ListingsRepository;

defined( 'ABSPATH' ) || exit;

if ( empty( $results['total_categories_found'] ) ) {
    return;
}

$category_page          = directorist_us_get_all_categories_page( $data->slug );
$max_categories_to_show = 5;
?>

<div class="directorist-container">
    <div class="directorist-row">
        <div class="directorist-col-12">
            <h2 class="dir-universal-search__match-categories-title">
                <?php esc_html_e( 'Matched Categories', 'directorist-universal-search' ); ?>
            </h2>

            <div class="dir-universal-search__match-wrapper">
                <ul class="dir-universal-search__match-categories">
                    <?php 
                    foreach ( array_slice( $results['categories'], 0, $max_categories_to_show ) as $category ) :
                        if ( ! in_array( $data->slug, (array) $category['directory_slug'] ) ) {
                            continue;
                        }

                        $listings = new ListingsRepository();
                        $listing  = new \WP_Query(
                            $listings->get_query_args( 
                                '', 
                                0, 
                                $data->slug, 
                                $category['term_slug'] 
                            ) 
                        );
                        ?>
                        <li>
                            <a href="<?php echo esc_url( $category['url'] ); ?>">
                                <?php echo wp_kses_post( $category['icon'] ); ?>
                                <?php echo esc_html( $category['title'] ); ?>
                                (<?php echo esc_html( $listing->found_posts ); ?>)
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>

                <?php if ( $category_page && ( $results['total_categories_found'] > $max_categories_to_show ) ) : ?>
                    <a href="<?php echo esc_url( directorist_us_get_all_categories_page( $data->slug ) ); ?>" 
                       class="dir-universal-search__match-view-more">
                        <?php esc_html_e( 'View more', 'directorist-universal-search' ); ?>
                        <svg xmlns="http://www.w3.org/2000/svg" 
                             width="16" 
                             height="16" 
                             viewBox="0 0 16 16" 
                             fill="none">
                            <path fill-rule="evenodd" 
                                  clip-rule="evenodd"
                                  d="M8.95778 2.88346C8.6685 3.17274 8.6685 3.64175 8.95778 3.93103L12.1377 7.11095H2.07415C1.66506 7.11095 1.33341 7.44259 1.33341 7.85169C1.33341 8.26079 1.66506 8.59243 2.07415 8.59243H12.1377L8.95778 11.7724C8.6685 12.0616 8.6685 12.5306 8.95778 12.8199C9.24706 13.1092 9.71607 13.1092 10.0053 12.8199L14.4498 8.37547C14.7391 8.08619 14.7391 7.61718 14.4498 7.32791L10.0053 2.88346C9.71607 2.59418 9.24706 2.59418 8.95778 2.88346Z"
                                  fill="currentColor" />
                        </svg>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>