<?php
/**
 * Search Results Header Template
 *
 * Displays the header section of search results including:
 * - Directory type name
 * - Results count
 * - View all results link (if applicable)
 *
 * @package Directorist_Universal_Search
 */

defined( 'ABSPATH' ) || exit;

$has_result_page = get_directorist_option( 'search_result_page' );
$view_all_url    = '';

if ( $has_result_page && ( $results['total_listings_found'] > 3 ) ) {
    $view_all_url = directorist_us_get_search_result_page(
        $search_query,
        $data->slug,
        ATBDP_Permalink::get_search_result_page_link()
    );
}
?>

<div class="directorist-container">
    <div class="directorist-row">
        <div class="directorist-col-12">
            <header class="dir-universal-search__listing-header" role="banner">
                <div class="dir-universal-search__listing-header-left">
                    <h2 class="dir-universal-search__listing-header-title">
                        <span class="directory-type">
                            <?php echo esc_html( $data->name ); ?>
                        </span>
                    </h2>

                    <?php if ( $search_query ) : ?>
                        <div class="dir-universal-search__listing-result-found" 
                             aria-live="polite">
                            <strong>
                                <?php 
                                echo esc_html( $results['total_results_found'] ) . ' ' . __( 'results', 'directorist-universal-search' ); 
                                ?>
                            </strong>
                        </div>
                    <?php endif; ?>
                </div>
                
                <?php if ( $view_all_url ) : ?>
                    <div class="dir-universal-search__listing-header-right">
                        <a href="<?php echo esc_url( $view_all_url ); ?>"
                           class="dir-universal-search__listing-view-results"
                           aria-label="<?php esc_attr_e( 'View all search results', 'directorist-universal-search' ); ?>">
                            <span class="view-results-text">
                                <?php esc_html_e( 'View all results', 'directorist-universal-search' ); ?>
                            </span>
                            <span class="view-results-icon" aria-hidden="true">
                                <?php directorist_icon( 'las la-arrow-right' ); ?>
                            </span>
                        </a>
                    </div>
                <?php endif; ?>
            </header>
        </div>
    </div>
</div>