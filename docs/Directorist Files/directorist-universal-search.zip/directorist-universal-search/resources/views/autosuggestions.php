<?php
/**
 * Autosuggestions Dropdown Template
 *
 * Displays search suggestions including:
 * - Popular listings
 * - Categories
 * - View all results button
 *
 * @package Directorist_Universal_Search
 */

defined( 'ABSPATH' ) || exit;
?>

<div class="dir-universal-search__dropdown" id="dir-universal-search__dropdown">
    <div class="dir-universal-search__wrapper">
        <div class="dir-universal-search__no-results" style="display: none;">
            <?php esc_html_e( 'No Results Found', 'directorist-universal-search' ); ?>
        </div>

        <div class="dir-universal-search__category-contents">
            <!-- Popular Listings Section -->
            <div class="dir-universal-search__category" 
                 id="dir-universal-search__category-popular-listing">
                <div class="dir-universal-search__category-title">
                    <?php esc_html_e( 'Popular Listings', 'directorist-universal-search' ); ?>
                    <span class="result-count">
                        (<?php esc_html_e( '0 results', 'directorist-universal-search' ); ?>)
                    </span>
                </div>
                <ul class="dir-universal-search__category-items" 
                    id="dir-universal-search__popular-listing"></ul>
            </div>

            <sub class="dir-universal-search__cross-border" style="display: none;"></sub>

            <!-- Categories Section -->
            <div class="dir-universal-search__category" 
                 id="dir-universal-search__category-budapest-categories">
                <div class="dir-universal-search__category-title">
                    <strong></strong>
                    <?php esc_html_e( 'Categories', 'directorist-universal-search' ); ?>
                    <span class="result-count">
                        (<?php esc_html_e( '0 results', 'directorist-universal-search' ); ?>)
                    </span>
                </div>
                <ul class="dir-universal-search__category-items" 
                    id="dir-universal-search__budapest-categories"></ul>
            </div>
        </div>
    </div>

    <button type="button" class="dir-universal-search__view-all-search">
        <?php esc_html_e( 'View all results', 'directorist-universal-search' ); ?>
        <?php directorist_icon( 'las la-arrow-right' ); ?>
    </button>
</div>
