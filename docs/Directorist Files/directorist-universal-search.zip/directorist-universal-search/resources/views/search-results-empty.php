<?php
/**
 * Empty Search Results Template
 *
 * Displays a message and image when no search results are found.
 *
 * @package Directorist_Universal_Search
 */

defined( 'ABSPATH' ) || exit;

// Asset URLs
$no_listing_image = plugin_dir_url( dirname( __DIR__, 1 ) ) . 'assets/img/no_listing_found.svg';
?>

<div class="dir-universal-search__no-listing">
    <img src="<?php echo esc_url( $no_listing_image ); ?>" 
         alt="<?php esc_attr_e( 'No listings found', 'directorist-universal-search' ); ?>">

    <div class="dir-universal-search__no-listing-message">
        <?php esc_html_e( 'No Results Found', 'directorist-universal-search' ); ?>
    </div>
</div>