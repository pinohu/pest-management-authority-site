<?php
/**
 * Template for displaying search results
 *
 * This template displays search results grouped by directory types.
 * Each directory type's results include:
 * - Header with directory type information
 * - Listing results
 * - Category results
 *
 * @package Directorist_Universal_Search
 * @since 1.0.0
 */

defined( 'ABSPATH' ) || exit;

$directory_types = directorist_get_directories( array(
    'orderby'    => 'date',
    'order'      => 'ASC',
) );
?>

<div class="dir-universal-search__group-wrapper directorist-w-100">
    <div class="directorist-container">
        <div class="directorist-row">
            <div class="directorist-col-12">
                <?php
                foreach ( $directory_types as $data ) :
                    // Skip if specific directory type is selected and doesn't match
                    if ( $directory_type && ( $directory_type !== $data->slug ) ) {
                        continue;
                    }
                    
                    $results = $results_repo->get_results_found( $data->slug, $search_query );

                    // Skip if no results found for this directory type
                    if ( empty( $results['total_results_found'] ) ) {
                        continue;
                    }
                    ?>
                    <div class="dir-universal-search__group-item">
                        <?php
                        // Display directory type header
                        include dirname( __FILE__ ) . '/search-results-header.php';
                        
                        // Display listing results
                        include dirname( __FILE__ ) . '/search-results-listings.php';

                        // Display category results
                        include dirname( __FILE__ ) . '/search-results-categories.php'; 
                        ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>