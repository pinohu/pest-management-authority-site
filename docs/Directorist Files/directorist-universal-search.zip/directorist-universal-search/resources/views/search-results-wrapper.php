<?php
defined( 'ABSPATH' ) || exit;

// Prepare CSS classes
$wrapper_classes = [
    'dir-universal-search__listings',
    'universal-search-result',
    'directorist-w-100',
];

if ( empty( $directory_type ) ) {
    $wrapper_classes[] = 'dir-universal-search__active-all-type';
}
?>

<div class="<?php echo esc_attr( implode( ' ', $wrapper_classes ) ); ?>">
    <div class="directorist-container">
        <div class="directorist-row directorist-justify-content-center">
            <div class="directorist-col-8 directorist-all-listing-col">
                <?php 
                // Display search query and results status
                if ( $search_query ) {
                    include dirname( __FILE__ ) . '/search-results-status.php';
                }

                // Display search form
                include dirname( __FILE__ ) . '/search-form.php';

                // Display directory types
                directorist_us_get_all_directory_types(); 
                ?>
            </div>
        </div>
    </div>

    <?php 
    // Display search results
    include dirname( __FILE__ ) . '/search-results.php';
    
    // Display no results message if needed
    if ( empty( $total_data_found ) ) {
        include dirname( __FILE__ ) . '/search-results-empty.php';
    } 
    ?>
</div>