<?php
defined( 'ABSPATH' ) || exit;

$form_data = [
    'action'      => $search_action_url,
    'placeholder' => $atts['placeholder'] ?? '',
    'button_text' => $atts['button_text'] ?? __( 'Search', 'directorist-universal-search' ),
    'query'       => $search_query ?? '',
];
?>

<div class="dir-universal-search__form-wrapper">
    <form action="<?php echo esc_url( $form_data['action'] ); ?>" 
          class="directorist-universal-search__form" 
          method="GET">
        
        <div class="dir-universal-search__icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M9.16666 3.33341C5.945 3.33341 3.33332 5.94509 3.33332 9.16675C3.33332 12.3884 5.945 15.0001 9.16666 15.0001C10.7383 15.0001 12.1647 14.3786 13.2136 13.3679C13.2356 13.3394 13.2596 13.312 13.2857 13.2858C13.3119 13.2597 13.3393 13.2357 13.3678 13.2137C14.3785 12.1648 15 10.7384 15 9.16675C15 5.94509 12.3883 3.33341 9.16666 3.33341ZM15.0266 13.8482C16.0529 12.5651 16.6667 10.9376 16.6667 9.16675C16.6667 5.02461 13.3088 1.66675 9.16666 1.66675C5.02452 1.66675 1.66666 5.02461 1.66666 9.16675C1.66666 13.3089 5.02452 16.6667 9.16666 16.6667C10.9375 16.6667 12.565 16.053 13.8481 15.0267L16.9107 18.0893C17.2362 18.4148 17.7638 18.4148 18.0892 18.0893C18.4147 17.7639 18.4147 17.2363 18.0892 16.9108L15.0266 13.8482Z" fill="#383F47"/>
            </svg>
        </div>

        <input type="text" 
               name="q" 
               value="<?php echo esc_attr( $form_data['query'] ); ?>"
               placeholder="<?php echo esc_attr( $form_data['placeholder'] ); ?>"
               class="dir-universal-search__input"
               aria-label="<?php esc_attr_e( 'Search', 'directorist-universal-search' ); ?>" 
               autocomplete="off" 
               required>

        <button type="submit" class="dir-universal-search__button">
            <?php echo esc_html( $form_data['button_text'] ); ?>
        </button>
    </form>

    <?php 
    /**
     * Renders the universal search form with autosuggestion functionality.
     * 
     * This template displays a search form with:
     * - Search input field with placeholder
     * - Search icon
     * - Submit button
     * - Autosuggestion dropdown (included from separate template)
     * 
     * @since 1.0.0
     * @see autosuggestions.php For the autosuggestion dropdown implementation
     */

    include dirname( __FILE__ ) . '/autosuggestions.php';
    ?>

</div>