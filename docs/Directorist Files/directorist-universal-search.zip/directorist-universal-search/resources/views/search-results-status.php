<?php
defined( 'ABSPATH' ) || exit;

$header_text = $total_data_found 
    ? esc_html__( 'Search Results for', 'directorist-universal-search' )
    : esc_html__( 'No Results Found for', 'directorist-universal-search' );

$results_text = sprintf(
    esc_html__( '%s results found', 'directorist-universal-search' ),
    esc_html( $total_data_found )
);
?>

<div class="dir-universal-search__top-header">
    <h1 class="dir-universal-search__top-header-title">
        <?php 
        echo esc_html( $header_text ); 
        ?>
        <strong>"<?php echo esc_html( $search_query ); ?>"</strong>
    </h1>

    <?php if ( $total_data_found ) : ?>
        <div class="dir-universal-search__result-found">
            <?php echo esc_html( $results_text ); ?>
        </div>
    <?php endif; ?>
</div>