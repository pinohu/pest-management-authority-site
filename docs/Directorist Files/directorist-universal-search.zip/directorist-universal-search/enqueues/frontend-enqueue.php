<?php

use DirectoristUS\WpMVC\Enqueue\Enqueue;

defined( 'ABSPATH' ) || exit;

wp_register_script( 'directorist-universal-search' , false );
wp_enqueue_script( 'directorist-universal-search' );
wp_localize_script( 'directorist-universal-search', 'directorist_universal_search_localization', directorist_us_frontend_localizations() );


Enqueue::script( 'wpmvc-app-script', 'build/js/app' );
Enqueue::style( 'wpmvc-app-style', 'build/css/app' );