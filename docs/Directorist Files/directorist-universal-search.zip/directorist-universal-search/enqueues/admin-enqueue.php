<?php

use DirectoristUS\WpMVC\Enqueue\Enqueue;

defined( 'ABSPATH' ) || exit;

// Enqueue::script( 'wpmvc-app-script', 'build/js/app' );
// Enqueue::style( 'wpmvc-app-style', 'build/css/app' );
