<?php
defined( 'ABSPATH' ) || exit;
// use DirectoristUS\App\Http\Controllers\UserController;
// use DirectoristUS\WpMVC\Routing\Ajax;

// Ajax::get( 'user/{id}', [UserController::class, 'index'], ['admin'] );
