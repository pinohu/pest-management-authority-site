<?php
defined( 'ABSPATH' ) || exit;

use DirectoristUS\App\Http\Controllers\UniversalSearchController;
use DirectoristUS\WpMVC\Routing\Route;

Route::get( 'search', [ UniversalSearchController::class, 'index' ] );