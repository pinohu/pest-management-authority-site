<?php
/**
 * Plugin Name:       Directorist - Universal Search
 * Description:       This is an add-on for Directorist Plugin. Enhance directorist search-form by using this plugin.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Tested up to:      6.2
 * Author:            WpWax
 * Author URI:        http://wpwax.com/
 * License:           GPL v3 or later
 * License URI:       http://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain:       directorist-universal-search
 * Domain Path:       /languages
 * Requires Plugins:  directorist
 */

defined( 'ABSPATH' ) || exit;

use DirectoristUS\App\Setup\Activation;
use DirectoristUS\WpMVC\App;

// Load composer autoloader
require_once __DIR__ . '/vendor/vendor-src/autoload.php';
// Load helper functions
require_once __DIR__ . '/app/Helpers/helper.php';

final class DirectoristUS
{
    public static DirectoristUS $instance;

    public static function instance(): DirectoristUS {
        if ( empty( self::$instance ) ) {
            self::$instance = new self;
        }
        return self::$instance;
    }

    public function load() {
        register_activation_hook(
            __FILE__, function() {
                $activation = new Activation();
                $activation->create_pages();
                $activation->setup_pages();
            } 
        );
        
        $app_instance = App::instance();
        
        $app_instance->boot( __FILE__, __DIR__ );
        
        add_action(
            'plugins_loaded', function () use ( $app_instance ): void {

                do_action( 'directorist_us_before_load' );

                $app_instance->load();

                do_action( 'directorist_us_after_load' );
            }
        );
    }
}

DirectoristUS::instance()->load();
