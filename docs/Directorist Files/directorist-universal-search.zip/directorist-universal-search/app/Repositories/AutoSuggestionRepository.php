<?php

namespace DirectoristUS\App\Repositories;

defined( "ABSPATH" ) || exit;

use DirectoristUS\App\Repositories\ListingsRepository;
use DirectoristUS\App\Repositories\TaxonomiesRepository;

class AutoSuggestionRepository {
    protected ListingsRepository $listings_repository;

    protected TaxonomiesRepository $taxonomies_repository;

    public function __construct( ListingsRepository $listings_repository, TaxonomiesRepository $taxonomies_repository ) {
        $this->listings_repository   = $listings_repository;
        $this->taxonomies_repository = $taxonomies_repository;
    }

    /**
     * Get search suggestions for listings and categories.
     *
     * @param string $search_term The keyword to search for.
     * @return array
     */
    public function get_search_suggestions( string $search_term ): array {
        if ( empty( $search_term ) ) {
            return [];
        }

        // Fetch matching listings
        $listings = $this->listings_repository->get_listings_by_search_term( $search_term );

        // Fetch matching categories
        $categories = $this->taxonomies_repository->get_categories_by_search_term( $search_term );

        // Structure response
        return [
            'listings'   => $listings,
            'categories' => $categories,
        ];
    }
}
