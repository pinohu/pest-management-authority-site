<?php

namespace DirectoristUS\App\Repositories;

defined( "ABSPATH" ) || exit;

class ResultsRepository {
    private const CATEGORY_LIMIT = 5;
    private const LISTING_LIMIT  = 3;

    private TaxonomiesRepository $taxonomies_repository;

    private ListingsRepository $listings_repository;

    public function __construct( ListingsRepository $listings_repository, TaxonomiesRepository $taxonomies_repository ) {
        $this->taxonomies_repository = $taxonomies_repository;
        $this->listings_repository   = $listings_repository;
    }

    public function get_total_data( $directory_type, $search_query ): int {
        $total_data_found = 0;

        foreach ( directorist_get_directories() as $data ) {
            if ( $directory_type && ( $directory_type !== $data->slug ) ) {
                continue;
            }
        
            $results              = $this->get_results_found( $data->slug, $search_query );
            $total_data_found += $results['total_results_found'];
        }

        return $total_data_found;
    }

    public function get_results_found( $directory_slug, $search_query = '' ): array {
        $listing_data    = $this->listings_repository->get_listings_data( $directory_slug );
        $categories_data = $this->taxonomies_repository->get_categories_by_directory( 
            sanitize_text_field( $search_query ), 
            sanitize_text_field( $directory_slug ) 
        );

        $categories = [];
        foreach ( $categories_data['categories'] as $category ) {
            if ( ! in_array( $directory_slug, $category['directory_slug'] ) ) {
                continue;
            }
            $categories[] = $category;
        }

        $total_categories_found = count( $categories );
        $total_listings_found   = $listing_data->query_results->total;
        $total_results_found    = $total_listings_found + $total_categories_found;

        return [
            'categories'             => $categories,
            'total_categories_found' => $total_categories_found,
            'total_listings_found'   => $total_listings_found,
            'total_results_found'    => $total_results_found,
        ];
    }
}