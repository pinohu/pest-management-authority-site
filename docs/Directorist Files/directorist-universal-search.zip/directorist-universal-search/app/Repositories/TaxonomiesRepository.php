<?php

namespace DirectoristUS\App\Repositories;

defined( "ABSPATH" ) || exit;

use WP_Query;
use ATBDP_Permalink;
use WP_Term_Query;
use WP_Term;

class TaxonomiesRepository {
    private const DEFAULT_ICON = 'las la-tags';

    private ListingsRepository $listings_repository;
    
    public function __construct( ListingsRepository $listings_repository ) {
        $this->listings_repository = $listings_repository;
    }
    
    public function get_query_args( string $search_term = '', string $directory_type = '', int $limit = 0 ): array {
        $args = [
            'taxonomy'   => ATBDP_CATEGORY,
            'hide_empty' => true,
            'fields'     => 'all',
        ];

        if ( $limit > 0 ) {
            $args['number'] = $limit;
        }
        
        if ( ! empty( $search_term ) ) {
            $args['name__like'] = $search_term;
        }

        if ( ! empty( $directory_type ) ) {
            $args['tax_query'] = [
                [
                    'taxonomy' => ATBDP_DIRECTORY_TYPE,
                    'field'    => 'slug',
                    'terms'    => $directory_type,
                ],
            ];
        }

        return $args;
    }

    private function filter_terms_by_directory( array $terms, string $directory_type ): array {
        if ( empty( $directory_type ) ) {
            return $terms;
        }

        return array_filter(
            $terms, function ( $term ) use ( $directory_type ) {
                $directory_ids = $this->get_directory_ids( $term );
                return $this->has_matching_directory( $directory_ids, $directory_type );
            }
        );
    }

    private function get_directory_ids( WP_Term $term ): array {
        $directory_ids = get_term_meta( $term->term_id, '_directory_type', true ) ?: [];
        return is_array( $directory_ids ) ? $directory_ids : [$directory_ids];
    }

    private function has_matching_directory( array $directory_ids, string $directory_type ): bool {
        foreach ( $directory_ids as $dir_id ) {
            $dir = get_term_by( 'id', $dir_id, ATBDP_DIRECTORY_TYPE );
            if ( $dir && $dir->slug === $directory_type ) {
                return true;
            }
        }
        return false;
    }

    private function filter_directory_ids_with_posts( array $directory_ids, WP_Term $term ): array {
        return array_filter(
            $directory_ids, function( $id ) use ( $term ) {
                return ! empty(
                    get_posts(
                        [
                            'post_type'      => ATBDP_POST_TYPE,
                            'tax_query'      => [
                                ['taxonomy' => ATBDP_DIRECTORY_TYPE, 'field' => 'id', 'terms' => $id],
                                ['taxonomy' => ATBDP_CATEGORY, 'field' => 'slug', 'terms' => $term->slug],
                            ],
                            'posts_per_page' => 1,
                            'fields'         => 'ids',
                            'no_found_rows'  => true,
                        ]
                    )
                );
            }
        );
    }

    private function get_directory_info( array $directory_ids ): array {
        $names = [];
        $slugs = [];

        foreach ( $directory_ids as $dir_id ) {
            $dir = get_term_by( 'id', $dir_id, ATBDP_DIRECTORY_TYPE );
            if ( $dir ) {
                $names[] = esc_html( $dir->name );
                $slugs[] = esc_html( $dir->slug );
            }
        }

        return ['names' => $names, 'slugs' => $slugs];
    }

    private function format_directory_list( array $directory_name ): string {
        if ( empty( $directory_name ) ) {
            return '';
        }

        $items = array_map(
            function ( $name ) {
                return $name;
            }, $directory_name
        );

        return '<ul><li>' . implode( '</li><li>', $items ) . '</li></ul>';
    }

    private function format_category_data( WP_Term $term, $directory_id ): array {
        $icon = directorist_icon(
            get_term_meta( $term->term_id, 'category_icon', true ) ?: self::DEFAULT_ICON,
            false
        );
    
        $directory = get_term_by( 'id', $directory_id, ATBDP_DIRECTORY_TYPE );
        $listings  = $this->listings_repository->get_query_args( '', 0, $directory->slug, $term->slug );
        $listing   = new WP_Query( $listings );
        
        return [
            'title'          => $term->name,
            'url'            => ATBDP_Permalink::atbdp_get_category_page( $term, $directory->slug ),
            'listings_found' => sprintf(
                _n( '%d listing', '%d listings', $listing->found_posts, 'directorist-universal-search' ),
                $listing->found_posts
            ),
            'directory_type' => $directory->slug,
            'directory_name' => $directory->name,
            'icon'           => $icon,
            'term_id'        => $term->term_id,
            'term_count'     => $term->count,
            'term_name'      => $term->name,
            'term_slug'      => $term->slug,
        ];
    }    
    
    private function format_category_data_results( WP_Term $term, array $directory_info, $directory_type ): array {
        $icon = directorist_icon(
            get_term_meta( $term->term_id, '_category_icon', true ) ?: self::DEFAULT_ICON, 
            false
        );
        
        return [
            'title'          => $term->name,
            'url'            => ATBDP_Permalink::atbdp_get_category_page( $term, $directory_type ),
            'listings_found' => sprintf(
                _n( '%d listing', '%d listings', $term->count, 'directorist-universal-search' ),
                $term->count
            ),
            'directory_type' => $this->format_directory_list( $directory_info['names'] ),
            'icon'           => $icon,
            'directory_slug' => $directory_info['slugs'],
            'directory_name' => $directory_info['names'],
            'term_id'        => $term->term_id,
            'term_count'     => $term->count,
            'term_name'      => $term->name,
            'term_slug'      => $term->slug,
        ];
    }

    public function get_categories_by_search_term( string $search_term = '', string $directory_type = '', int $limit = 0 ): array {
        $query = new WP_Term_Query( $this->get_query_args( $search_term, $directory_type, $limit ) );
        $terms = $query->get_terms();

        if ( empty( $terms ) ) {
            return $this->get_empty_response();
        }
        
        $terms      = $this->filter_terms_by_directory( $terms, $directory_type );
        $categories = [];
    
        foreach ( $terms as $term ) {
            $directory_ids = $this->get_directory_ids( $term );
            $directory_ids = $this->filter_directory_ids_with_posts( $directory_ids, $term );
    
            foreach ( $directory_ids as $directory_id ) {
                $categories[] = $this->format_category_data( $term, $directory_id );
            }
        }

        return [
            'total_categories_found' => sprintf(
                _n( '%d category', '%d categories', count( $categories ), 'directorist-universal-search' ),
                count( $categories )
            ),
            'categories'             => array_slice( $categories, 0, 3 ),
        ];
    }    
    
    public function get_categories_by_directory( string $search_term = '', string $directory_type = '', int $limit = 0 ): array {
        $query = new WP_Term_Query( $this->get_query_args( $search_term, $directory_type, $limit ) );
        $terms = $query->get_terms();

        if ( empty( $terms ) ) {
            return $this->get_empty_response();
        }

        $terms = $this->filter_terms_by_directory( $terms, $directory_type );

        $categories = array_map(
            function ( $term ) use ( $directory_type ) {
                $directory_ids  = $this->get_directory_ids( $term );
                $directory_ids  = $this->filter_directory_ids_with_posts( $directory_ids, $term );
                $directory_info = $this->get_directory_info( $directory_ids );
            
                return $this->format_category_data_results( $term, $directory_info, $directory_type );
            }, $terms
        );

        if ( empty( $categories ) ) {
            return $this->get_empty_response();
        }

        return [
            'total_categories_found' => sprintf(
                _n( '%d category', '%d categories', count( $categories ), 'directorist-universal-search' ),
                count( $categories )
            ),
            'categories'             => $categories,
        ];
    }

    private function get_empty_response(): array {
        return [
            'total_categories_found' => sprintf(
                _n( '%d category', '%d categories', 0, 'directorist-universal-search' ),
                0
            ),
            'categories'             => [],
            'categories_by_type'     => [],
        ];
    }

    private function group_categories_by_directory( array $categories ): array {
        $grouped = [];
        
        foreach ( $categories as $category ) {
            if ( ! empty( $category['directory_slug'] ) && is_array( $category['directory_slug'] ) ) {
                foreach ( $category['directory_slug'] as $slug ) {
                    $grouped[$slug]   = $grouped[$slug] ?? [];
                    $grouped[$slug][] = $category;
                }
            }
        }

        return $grouped;
    }
}