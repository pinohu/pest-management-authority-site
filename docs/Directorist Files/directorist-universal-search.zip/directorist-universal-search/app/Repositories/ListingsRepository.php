<?php

namespace DirectoristUS\App\Repositories;

defined( "ABSPATH" ) || exit;

use Directorist\Directorist_Listings;

use Directorist\Helper;
use WP_Query;
use WP_Term;

class ListingsRepository {
    private const DEFAULT_LIMIT = 3;

    public function get_query_args( string $search_term = '', int $limit = self::DEFAULT_LIMIT, string $directory_type = '', $term = '' ): array {
        $args = [
            'post_type'      => ATBDP_POST_TYPE,
            'post_status'    => 'publish',
            'posts_per_page' => $limit,
            'no_found_rows'  => false,
        ];

        if ( ! empty( $search_term ) ) {
            $args['s']       = $search_term;
            $args['orderby'] = 'relevance';
        }

        $tax_query = [];

        if ( ! empty( $directory_type ) ) {
            $tax_query[] = [
                'taxonomy' => ATBDP_DIRECTORY_TYPE,
                'field'    => 'slug',
                'terms'    => $directory_type,
            ];
        }

        if ( ! empty( $term ) ) {
            $tax_query[] = [
                'taxonomy' => ATBDP_CATEGORY,
                'field'    => 'slug',
                'terms'    => $term,
            ];
        }

        if ( ! empty( $tax_query ) ) {
            $args['tax_query'] = $tax_query;
        }

        return $args;
    }

    private function get_directory_data( int $post_id ): ?WP_Term {
        $directory_id = get_post_meta( $post_id, '_directory_type', true );
        $directory_id = directorist_is_multi_directory_enabled() ? $directory_id : directorist_get_default_directory();
        return  get_term_by( 'id', $directory_id, ATBDP_DIRECTORY_TYPE );
    }

    private function get_listing_media( WP_Term $directory ): array {
        $icon_meta     = directorist_get_directory_meta( $directory->term_id, 'general_config' );
        $default_image = Helper::default_preview_image_src( $directory );
        $image_id      = directorist_get_listing_preview_image( get_the_ID() );

        return [
            'icon'      => directorist_icon( $icon_meta['icon'] ?? 'fas fa-home', false ),
            'thumbnail' => atbdp_get_image_source( $image_id, 'medium' ) ?: $default_image,
        ];
    }

    private function format_listing_data( WP_Term $directory, array $media ): array {
        return [
            'title'          => get_the_title(),
            'url'            => get_permalink(),
            'thumbnail'      => $media['thumbnail'],
            'directory_type' => $directory->name,
            'icon'           => $media['icon'],
        ];
    }

    public function get_listings_by_search_term( string $search_term, int $limit = self::DEFAULT_LIMIT ): array {
        $query    = new WP_Query( $this->get_query_args( $search_term, $limit ) );
        $listings = [];

        while ( $query->have_posts() ) {
            $query->the_post();
            $directory = $this->get_directory_data( get_the_ID() );
            
            if ( empty( $directory ) ) {
                continue;
            }

            $media      = $this->get_listing_media( $directory );
            $listings[] = $this->format_listing_data( $directory, $media );
        }

        wp_reset_postdata();

        return [
            'total_listings_found' => sprintf( __( '%s results', 'directorist-universal-search' ), $query->found_posts ),
            'listings'             => $listings,
        ];
    }

    public function get_listings_with_type_by_search_term( string $search_term, string $directory_type = '', int $limit = self::DEFAULT_LIMIT ): array {

        // $query = $this->get_query_builder()
        //     ->where( 'post_type', ATBDP_POST_TYPE )
        //     ->where( 'post_status', 'publish' )
        //     ->where(
        //         function( $query ) use ( $search_term ) {
        //             $query->where_like( 'post_title', '%' . $search_term . '%' )
        //             ->or_where_like( 'post_content', '%' . $search_term . '%' );
        //         }
        //     );

        // $count_query = clone $query;
        // $db_listings = $query->limit( $limit )->get();
        // $total = $count_query->count();

        $query = new WP_Query( $this->get_query_args( $search_term, -1, $directory_type ) );
        
        if ( ! $query->have_posts() ) {
            return [
                'total_items'      => 0,
                'listings_by_type' => [],
            ];
        }

        $listings_by_type = [];

        while ( $query->have_posts() ) {
            $query->the_post();
            $directory = $this->get_directory_data( get_the_ID() );

            if ( empty( $directory ) ) {
                continue;
            }

            $media        = $this->get_listing_media( $directory );
            $listing_data = $this->format_listing_data( $directory, $media );

            if ( ! isset( $listings_by_type[$directory->slug] ) ) {
                $listings_by_type[$directory->slug] = [
                    'directory_slug' => $directory->slug,
                    'icon'           => $media['icon'],
                    'listings'       => [],
                    'total'          => 0
                ];
            }

            if ( count( $listings_by_type[$directory->slug]['listings'] ) < $limit ) {
                $listings_by_type[$directory->slug]['listings'][] = $listing_data;
            }
            $listings_by_type[$directory->slug]['total']++;
        }

        wp_reset_postdata();

        return [
            'total_listings_found' => sprintf( __( '%s results', 'directorist-universal-search' ), $query->found_posts ),
            'listings_by_type'     => $listings_by_type,
        ];
    }

    /**
     * Get listings data for a specific directory type
     *
     * @param object|array $directory_data Directory type data containing slug
     * @return Directorist_Listings
     */
    public function get_listings_data( $directory_slug ): Directorist_Listings {
        $directory_slug = $directory_slug ? ['directory_type' => $directory_slug] : '';
        
        return new Directorist_Listings( $directory_slug );
    }
}