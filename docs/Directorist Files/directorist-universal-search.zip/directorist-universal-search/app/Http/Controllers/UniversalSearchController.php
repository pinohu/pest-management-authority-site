<?php

namespace DirectoristUS\App\Http\Controllers;

defined( "ABSPATH" ) || exit;

use DirectoristUS\App\Repositories\AutoSuggestionRepository;
use DirectoristUS\WpMVC\Routing\Response;
use DirectoristUS\WpMVC\RequestValidator\Validator;
use WP_REST_Request;

class UniversalSearchController {
    protected $repository;

    public function __construct( AutoSuggestionRepository $repository ) {
        $this->repository = $repository;
    }

    /**
     * Handle the search request and return suggestions
     *
     * @param Validator $validator Request validator instance
     * @param WP_REST_Request $request WordPress REST request object
     * @return array Response containing search results
     * 
     * @throws \Exception If validation fails
     */
    public function index( Validator $validator, WP_REST_Request $request ): array {
        // Validate the search query parameter
        $validator->validate(
            [
                "s" => "required|string|min:3"
            ]
        );

        // Get the search term from the request
        $search_term = sanitize_text_field( $request->get_param( "s" ) );

        // Fetch search suggestions from AutoSuggestionRepository
        $results = $this->repository->get_search_suggestions( $search_term );

        return Response::send(
            [
                "query"  => $search_term,
                "items"  => $results,
                "status" => "success",
            ]
        );
    }
}
