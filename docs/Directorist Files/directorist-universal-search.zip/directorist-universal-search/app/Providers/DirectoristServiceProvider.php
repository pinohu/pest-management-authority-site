<?php

namespace DirectoristUS\App\Providers;

defined( "ABSPATH" ) || exit;

use DirectoristUS\WpMVC\Contracts\Provider;
use WpMVC\Helpers\Helpers;

class DirectoristServiceProvider implements Provider {
    public function boot() {
        add_filter( 'directorist_get_directory_type_nav_url', [$this, 'directorist_get_directory_type_nav_url'], 10, 3 );
    }

    public function directorist_get_directory_type_nav_url( $url, $type, $base_url ) {
        $is_universal_page = get_directorist_option( 'universal_search_result_page' );

        if ( is_page( $is_universal_page ) && $type === 'all' ) {
            $url = remove_query_arg( 'directory_type', $base_url );
        }

        return $url;
    }
}