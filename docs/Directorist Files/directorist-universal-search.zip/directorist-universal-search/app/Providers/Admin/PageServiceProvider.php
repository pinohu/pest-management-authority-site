<?php

namespace DirectoristUS\App\Providers\Admin;

defined( "ABSPATH" ) || exit;

use DirectoristUS\WpMVC\Contracts\Provider;

class PageServiceProvider implements Provider {
    public function boot() {
        add_filter( 'display_post_states', [$this, 'display_universal_search_post_state'], 10, 2 );
    }

    /**
     * Add post state for Universal Search Results page
     *
     * @param array $post_states Array of post states
     * @param \WP_Post $post Current post object
     * @return array Modified post states
     */
    public function display_universal_search_post_state( array $post_states, \WP_Post $post ): array { 
        $page_id = (int) get_directorist_option( 'universal_search_result_page' );

        if ( empty( $page_id ) || $page_id !== $post->ID ) {
            return $post_states;
        }

        $post_states['universal_search_result_page'] = __( 'Directorist Universal Search Results', 'directorist-universal-search' );
        
        return $post_states;
    }
}