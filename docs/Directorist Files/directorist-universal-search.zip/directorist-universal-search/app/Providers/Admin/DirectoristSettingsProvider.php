<?php

namespace DirectoristUS\App\Providers\Admin;

defined( "ABSPATH" ) || exit;

use DirectoristUS\WpMVC\Contracts\Provider;

class DirectoristSettingsProvider implements Provider {
    public function boot() {
        add_filter( 'atbdp_pages_settings_fields', [$this, 'atbdp_pages_settings_fields'] );
        add_filter( 'atbdp_listing_type_settings_field_list', [$this, 'atbdp_listing_type_settings_field_list'] );
    }

    public function atbdp_pages_settings_fields( array $fields ): array {
        $fields[] = 'universal_search_result_page';
        return $fields;
    }

    public function atbdp_listing_type_settings_field_list( array $fields ): array {
        $fields['universal_search_result_page'] = [
            'label'             => __( 'Universal Search Result Page', 'directorist-universal-search' ),
            'type'              => 'select', 
            /* translators: %s is the shortcode wrapped in a colored div */
            'description'       => sprintf(
                __( 'Following shortcode must be in the selected page %s', 'directorist-universal-search' ), 
                '<div class="atbdp_shortcodes" style="color: #ff4500;">[directorist_universal_search_result]</div>'
            ),
            'value'             => atbdp_get_option( 'universal_search_result_page', 'atbdp_general' ),
            'showDefaultOption' => true,
            'options'           => ( new \ATBDP_Settings_Panel )->get_pages_vl_arrays()
        ];

        return $fields;
    }
}