<?php
namespace DirectoristUS\App\Providers;

use DirectoristUS\App\Repositories\ResultsRepository;

defined( "ABSPATH" ) || exit;

use DirectoristUS\WpMVC\Contracts\Provider;
use DirectoristUS\WpMVC\View\View;
use DirectoristUS\WpMVC\Helpers\Helpers;

class ShortcodeServiceProvider implements Provider
{
    /**
     * Register the shortcode.
     */
    public function boot() {
        add_shortcode( 'directorist_universal_search_form', [$this, 'render_search_form'] );
        add_shortcode( 'directorist_universal_search_result', [$this, 'render_search_result'] );
    }

    public function render_search_form( $atts ) {

        $atts = shortcode_atts(
            [
                'placeholder' => esc_html__( 'Search listings...', 'directorist-universal-search' ),
                'button_text' => esc_html__( 'Search', 'directorist-universal-search' ),
            ], $atts, 'directorist_universal_search_form'
        );

        $request           = Helpers::request();
        $search_query      = sanitize_text_field( (string) $request->get_param( 'q' ) );
        $search_action_url = directorist_us_get_result_page_link();

        return View::get(
            'search-form-wrapper', [
                'search_action_url' => $search_action_url,
                'search_query'      => $search_query,
                'atts'              => $atts,
            ]
        );
    }

    public function render_search_result( $atts ) {

        $atts = shortcode_atts(
            [
                'placeholder' => esc_html__( 'Search for listings...', 'directorist-universal-search' ),
                'button_text' => esc_html__( 'Search', 'directorist-universal-search' ),
            ], $atts, 'directorist_universal_search_result'
        );

        $request           = Helpers::request();
        $search_action_url = directorist_us_get_result_page_link();
        $search_query      = sanitize_text_field( (string) $request->get_param( 'q' ) );
        $directory_type    = sanitize_text_field( (string) $request->get_param( 'directory_type' ) );
        $directory_type    = ( 'all' === $directory_type ) ? '' : $directory_type;

        /**
         * @var ResultsRepository $results_repo
         */
        $results_repo = directorist_us_singleton( ResultsRepository::class );

        return View::get(
            'search-results-wrapper', [
                'atts'              => $atts,
                'search_action_url' => $search_action_url,
                'search_query'      => $search_query,
                'directory_type'    => $directory_type,
                'results_repo'      => $results_repo,
                'total_data_found'  => $results_repo->get_total_data( $directory_type, $search_query ),
            ]
        );
    }
}
