<?php

defined( 'ABSPATH' ) || exit;

use Directorist\Directorist_Listings;
use Directorist\Helper;
use DirectoristUS\WpMVC\View\View;
use DirectoristUS\WpMVC\App;
use DirectoristUS\DI\Container;

function directorist_us():App {
    return App::$instance;
}

function directorist_us_config( string $config_key ) {
    return directorist_us()::$config->get( $config_key );
}

function directorist_us_app_config( string $config_key ) {
    return directorist_us_config( "app.{$config_key}" );
}

function directorist_us_version() {
    return directorist_us_app_config( 'version' );
}

function directorist_us_container():Container {
    return directorist_us()::$container;
}

function directorist_us_singleton( string $class ) {
    return directorist_us_container()->get( $class );
}

function directorist_us_url( string $url = '' ) {
    return directorist_us()->get_url( $url );
}

function directorist_us_dir( string $dir = '' ) {
    return directorist_us()->get_dir( $dir );
}

if ( ! function_exists( 'directorist_us_frontend_localizations' ) ) {
    /**
     * Get frontend localization data
     *
     * @return array
     */
    function directorist_us_frontend_localizations(): array {
        return [
            'rest_url'   => get_rest_url( null, 'directorist-universal-search' ),
            'rest_nonce' => wp_create_nonce( 'wp_rest' ),
        ];
    }
}

if ( ! function_exists( 'directorist_us_get_result_page_link' ) ) {
    /**
     * Get universal search result page link
     *
     * @return string
     */
    function directorist_us_get_result_page_link(): string {
        $link    = home_url();
        $page_id = (int) get_directorist_option( 'universal_search_result_page' );

        if ( ! $page_id ) {
            return $link;
        }

        if ( function_exists( 'atbdp_required_polylang_url' ) && atbdp_required_polylang_url() && function_exists( 'pll_get_post' ) ) {
            $translated_id = pll_get_post( $page_id );
            return $translated_id ? get_permalink( $translated_id ) : $link;
        }

        return get_permalink( $page_id );
    }
}

if ( ! function_exists( 'directorist_us_get_all_categories_page' ) ) {
    /**
     * Get all categories page link
     *
     * @param string $directory_type
     * @return string
     */
    function directorist_us_get_all_categories_page( string $directory_type = 'all' ): string {
        $link    = home_url();
        $page_id = (int) get_directorist_option( 'all_categories_page' );

        if ( ! $page_id ) {
            return false;
        }

        if ( function_exists( 'atbdp_required_polylang_url' ) && atbdp_required_polylang_url() && function_exists( 'pll_get_post' ) ) {
            $translated_id = pll_get_post( $page_id );
            $link          = $translated_id ? get_permalink( $translated_id ) : $link;
        } else {
            $link = get_permalink( $page_id );
        }

        return add_query_arg( 'directory_type', $directory_type, $link );
    }
}

if ( ! function_exists( 'directorist_us_get_all_directory_types' ) ) {
    /**
     * Display all directory types navigation
     *
     * @return void
     */
    function directorist_us_get_all_directory_types(): void {
        $listings = new Directorist_Listings();
        
        if ( ! function_exists( 'directorist_is_multi_directory_enabled' ) ) {
            return;
        }

        if ( count( $listings->listing_types ) > 1 && directorist_is_multi_directory_enabled() ) {
            Helper::get_template(
                'archive/directory-type-nav', [
                    'listings'  => $listings,
                    'all_types' => true,
                ]
            );
        }
    }
}

if ( ! function_exists( 'directorist_us_get_search_result_page' ) ) {
    /**
     * Get search result page URL with query parameters
     *
     * @param string $search_query
     * @param string $directory_type
     * @param string $base_url
     * @return string
     */
    function directorist_us_get_search_result_page( string $search_query, string $directory_type, string $base_url ): string {
        return add_query_arg(
            [
                'directory_type' => $directory_type,
                'q'              => $search_query,
            ], $base_url 
        );
    }
}

if ( ! function_exists( 'directorist_us_form' ) ) {
    /**
     * Display universal search form
     *
     * @param string $search_action_url Form action URL
     * @param string $search_query Search query
     * @param array $atts Form attributes
     * @return void
     */
    function directorist_us_form( string $search_action_url, string $search_query, array $atts ): void {
        View::render(
            'search-form', [
                'search_action_url' => $search_action_url,
                'search_query'      => $search_query,
                'atts'              => $atts,
            ]
        );
    }
}