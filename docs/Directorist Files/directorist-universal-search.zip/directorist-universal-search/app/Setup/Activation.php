<?php

namespace DirectoristUS\App\Setup;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly

class Activation {
    public function create_pages() {
        $search_form        = get_page_by_path( 'universal-search-form' );
        $search_result_page = get_page_by_path( 'universal-search-results' );

        if ( ! $search_result_page ) {
            // Create the new page
            wp_insert_post(
                [
                    'post_title'   => 'Universal Search Results',
                    'post_name'    => 'universal-search-results',
                    'post_content' => '[directorist_universal_search_result button_text="Search" placeholder="Search listings..."]', // Add the shortcode
                    'post_status'  => 'publish',
                    'post_type'    => 'page',
                ]
            );
        }

        if ( ! $search_form ) {
            // Create the new page
            wp_insert_post(
                [
                    'post_title'   => 'Universal Search Form',
                    'post_name'    => 'universal-search-form',
                    'post_content' => '[directorist_universal_search_form button_text="Search" placeholder="Search listings..."]', // Add the shortcode
                    'post_status'  => 'publish',
                    'post_type'    => 'page',
                ]
            );
        }
    }
    
    public function setup_pages() {
        $search_result_page = get_page_by_path( 'universal-search-results' );
        $check_is_setup     = get_directorist_option( 'universal_search_result_page' );

        if ( $search_result_page && ! $check_is_setup ) {
            update_directorist_option( 'universal_search_result_page', $search_result_page->ID );
        }
    }
}