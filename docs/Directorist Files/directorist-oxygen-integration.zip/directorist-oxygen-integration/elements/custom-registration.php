<?php
/**
 * Custom registration element class.
 * 
 * @author wpWax
 */
namespace wpWax\Directorist\Oxygen;

defined( 'ABSPATH' ) || die();

class CustomRegistration extends Element {

	public function name() {
		return esc_html__( 'Registration', 'directorist-oxygen-integration' );
	}

	public function slug() {
		return 'directorist-custom-registration';
	}
}

new CustomRegistration();
