<?php
/**
 * User login element class.
 * 
 * @author wpWax
 */
namespace wpWax\Directorist\Oxygen;

defined( 'ABSPATH' ) || die();

class UserLogin extends Element {

	public function name() {
		return esc_html__( 'Login', 'directorist-oxygen-integration' );
	}

	public function slug() {
		return 'directorist-user-login';
	}
}

new UserLogin();
