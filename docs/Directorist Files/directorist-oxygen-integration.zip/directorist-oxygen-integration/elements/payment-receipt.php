<?php
/**
 * Payment receipt element class.
 * 
 * @author wpWax
 */
namespace wpWax\Directorist\Oxygen;

defined( 'ABSPATH' ) || die();

class PaymentReceipt extends Element {

	public function name() {
		return esc_html__( 'Payment Receipt', 'directorist-oxygen-integration' );
	}

	public function slug() {
		return 'directorist-payment-receipt';
	}
}

new PaymentReceipt();
