<?php
/**
 * User dashboard element class.
 * 
 * @author wpWax
 */
namespace wpWax\Directorist\Oxygen;

defined( 'ABSPATH' ) || die();

class UserDashboard extends Element {

	public function name() {
		return esc_html__( 'User Dashboard', 'directorist-oxygen-integration' );
	}

	public function slug() {
		return 'directorist-user-dashboard';
	}
}

new UserDashboard();
