<?php
/**
 * Checkout element class.
 * 
 * @author wpWax
 */
namespace wpWax\Directorist\Oxygen;

defined( 'ABSPATH' ) || die();

class Checkout extends Element {

	public function name() {
		return esc_html__( 'Cart / Checkout', 'directorist-oxygen-integration' );
	}

	public function slug() {
		return 'directorist-checkout';
	}
}

new Checkout();
