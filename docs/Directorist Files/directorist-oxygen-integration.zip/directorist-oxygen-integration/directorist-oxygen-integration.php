<?php
/**
 * Plugin Name: Directorist - Oxygen Integration
 * Plugin URI: https://directorist.com/product/directorist-oxygen-integration
 * Description: This is an add-on for Directorist Plugin. Oxygen builder support for Directorist.
 * Version: 2.0.0
 * Author: wpWax
 * Author URI: https://directorist.com/
 * License: GPLv2 or later
 * Text Domain: directorist-oxygen-integration
 * Domain Path: /languages
 */

/**
 * Directorist oxygen extension.
 * 
 * @package wpWax\Directorist\Oxygen
 */
namespace wpWax\Directorist\Oxygen;

defined( 'ABSPATH' ) || die();

// plugin author url
if (!defined('ATBDP_AUTHOR_URL')) {
	define('ATBDP_AUTHOR_URL', 'https://directorist.com');
}

// post id from download post type (edd)
if (!defined('ATBDP_OXEEl_POST_ID')) {
	define('ATBDP_OXEEl_POST_ID', 56997);
}

use CT_Toolbar;

/**
 * Initialize extension.
 *
 * @return void
 */

// add_action( 'admin_init', __NAMESPACE__ . '\OxyEl_update_controller' );

function OxyEl_update_controller() {
	$data = get_user_meta( get_current_user_id(), '_plugins_available_in_subscriptions', true );
	$license_key = ! empty( $data['directorist-oxygen-integration'] ) ? $data['directorist-oxygen-integration']['license'] : '';
	
	new \EDD_SL_Plugin_Updater(ATBDP_AUTHOR_URL, __FILE__, array(
		'version' => get_plugin_data( __FILE__ )['Version'],        // current version number
		'license' => $license_key,    // license key (used get_option above to retrieve from DB)
		'item_id' => ATBDP_OXEEl_POST_ID,    // id of this plugin
		'author' => 'AazzTech',    // author of this plugin
		'url' => home_url(),
		'beta' => false // set to true if you wish customers to receive update notifications of beta releases
	));
}

function extension_init() {
	if ( ! directorist_is_plugin_active( 'directorist/directorist-base.php' ) || ! class_exists( '\OxyEl' ) ) {
		return;
	}

	// Register +Add Directorist section
	add_action( 'oxygen_add_plus_sections',  __NAMESPACE__ . '\register_section' );

	// Register +Add Directorist subsections
	// oxygen_add_plus_{$id}_section_content
	add_action( 'oxygen_add_plus_directorist_category_section_content', __NAMESPACE__ . '\register_subsection' );

	add_action( 'ct_before_builder', __NAMESPACE__ . '\add_control_style' );

	load_controls();
	
	load_elements();

	add_filter( 'directorist_css_scripts', __NAMESPACE__ . '\remove_shortcode_restrictions_from_directorist_script' );

	// Remove directorist default single template hook.
	if ( class_exists( '\Directorist\Directorist_Template_Hooks', false ) ) {
		$template_hooks = \Directorist\Directorist_Template_Hooks::instance();
		remove_action( 'template_include', [ $template_hooks, 'single_template_path' ], 999 );
	}

	if ( ! class_exists( '\EDD_SL_Plugin_Updater' ) ) {
		include_once __DIR__ . '/inc/EDD_SL_Plugin_Updater.php';
	}
}
add_action( 'init', __NAMESPACE__ . '\extension_init', 20 );

/**
 * Include controls file.
 *
 * @return void
 */
function load_controls() {
	// Base element
	include_once 'class-control.php';
}

/**
 * Include elements file.
 *
 * @return void
 */
function load_elements() {
	// Base element
	include_once 'class-element.php';

	// elements without controls
	include_once 'elements/add-listing.php';
	include_once 'elements/checkout.php';
	include_once 'elements/custom-registration.php';
	include_once 'elements/payment-receipt.php';
	include_once 'elements/transaction-failure.php';
	include_once 'elements/user-dashboard.php';
	include_once 'elements/user-login.php';
	include_once 'elements/single-details.php';

	// elements with controls
	include_once 'elements/all-listing.php';
	include_once 'elements/category.php';
	include_once 'elements/location.php';
	include_once 'elements/tag.php';
	include_once 'elements/all-categories.php';
	include_once 'elements/all-locations.php';
	include_once 'elements/author-profile.php';
	include_once 'elements/search-listing.php';
	include_once 'elements/search-result.php';
}

/**
 * Register directorist section tab.
 *
 * @return void
 */
function register_section() {
	CT_Toolbar::oxygen_add_plus_accordion_section( 'directorist_category', __( 'Directorist', 'directorist-oxygen-integration' ) );
}

/**
 * Register directorist elemnents section hook.
 *
 * @return void
 */
function register_subsection() {
	/**
	 * Oxygen is creating this hook dynamically
	 * 
	 * button place value is being used to create this hook.
	 * eg. directorist::elements -> oxygen_add_plus_directorist_elements
	 * 
	 * @see \OxygenElementHelper /component-framework/api/oxygen.element-helper.class.php
	 */
	do_action( 'oxygen_add_plus_directorist_elements' );
}

function add_control_style() {
	?>
	<style>
		.select2-container--default .select2-search--dropdown .select2-search__field {
			background: transparent;
			border: none;
			outline: 0;
			box-shadow: none;
			-webkit-appearance: textfield;
		}
	</style>
	<?php
}

/**
 * Removes shortcode restrictions from Directorist script 
 * 
 * @param array
 * @return array
 */
function remove_shortcode_restrictions_from_directorist_script( $scripts ) {

	foreach ( $scripts as $script_key => $scripts_args ) {
		if ( ! isset( $scripts_args['shortcode'] ) ) continue;

		unset( $scripts[ $script_key ]['shortcode'] );
	}

	return $scripts;
}

if ( ! function_exists( 'directorist_is_plugin_active' ) ) {
    function directorist_is_plugin_active( $plugin ) {
        return in_array( $plugin, (array) get_option( 'active_plugins', array() ), true ) || directorist_is_plugin_active_for_network( $plugin );
    }
}

if ( ! function_exists( 'directorist_is_plugin_active_for_network' ) ) {
    function directorist_is_plugin_active_for_network( $plugin ) {
        if ( ! is_multisite() ) {
            return false;
        }
                
        $plugins = get_site_option( 'active_sitewide_plugins' );
        if ( isset( $plugins[ $plugin ] ) ) {
                return true;
        }

        return false;
    }
}