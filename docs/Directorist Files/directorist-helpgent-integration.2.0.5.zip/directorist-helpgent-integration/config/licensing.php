<?php

defined( 'ABSPATH' ) || exit;

return [
    'author'        => 'WpWax',
    'product_id'    => '188735',
    'licensing_api' => 'https://directorist.com',
];