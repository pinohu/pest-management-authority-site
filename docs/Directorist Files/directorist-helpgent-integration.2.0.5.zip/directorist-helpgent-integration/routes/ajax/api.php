<?php

use DHGI\App\Http\Controllers\UserController;
use DHGI\WpMVC\Routing\Ajax;

Ajax::get( 'user/{id}', [UserController::class, 'index'], ['admin'] );
