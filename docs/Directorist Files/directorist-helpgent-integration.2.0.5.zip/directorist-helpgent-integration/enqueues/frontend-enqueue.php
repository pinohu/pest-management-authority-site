<?php

use DHGI\WpMVC\Enqueue\Enqueue;

defined( 'ABSPATH' ) || exit;

$dependencies = [];

if ( function_exists( "helpgent_pro" ) ) {
    $dependencies[] = 'helpgent-pro/modules';
}

Enqueue::register_script( 'dhgi-listing-owner', 'build/js/app', $dependencies );
Enqueue::register_style( 'dhgi-listing-owner', 'build/css/app' );

Enqueue::script( 'dhgi-frontend', 'build/js/frontend' );
wp_localize_script( 'dhgi-frontend', 'dhgi_form_settings', dhgi_get_settings() );