<?php

use DHGI\WpMVC\Enqueue\Enqueue;

defined( 'ABSPATH' ) || exit;

if ( 'helpgent_page_helpgent' === get_current_screen()->id ) {
    Enqueue::script( 'dhgi-admin', 'build/js/admin' );
    wp_localize_script(
        'dhgi-admin', 'dghi_admin', [
            'directorist_settings_url' => admin_url( 'edit.php?post_type=at_biz_dir&page=atbdp-settings#extension_settings__helpgent_settings' ),
            'form_settings'            => dhgi_get_settings()
        ]
    );
}