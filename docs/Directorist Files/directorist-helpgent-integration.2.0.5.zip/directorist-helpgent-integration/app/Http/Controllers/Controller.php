<?php

namespace DHGI\App\Http\Controllers;

class Controller {}