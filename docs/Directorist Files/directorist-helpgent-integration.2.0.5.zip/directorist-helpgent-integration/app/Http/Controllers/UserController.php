<?php

namespace DHGI\App\Http\Controllers;

class UserController extends Controller
{
    public function index() {}
}