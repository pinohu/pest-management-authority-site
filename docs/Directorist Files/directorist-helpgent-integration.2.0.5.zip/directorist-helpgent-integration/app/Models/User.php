<?php

namespace DHGI\App\Models;

use DHGI\WpMVC\App;
use DHGI\WpMVC\Database\Eloquent\Model;
use DHGI\WpMVC\Database\Resolver;

class User extends Model {
    public static function get_table_name():string {
        return 'users';
    }

    public function resolver():Resolver {
        return App::$container->get( Resolver::class );
    }
}